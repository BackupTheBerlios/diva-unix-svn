package cas.impl;

import java.util.ArrayList;
import java.util.List;

import org.osgi.framework.BundleContext;

import tutorial.diva.cas.interfaces.IAddress;
import tutorial.diva.cas.interfaces.IInformationItem;

import eu.diva.osgi.component.DiVAComponent;
import eu.diva.osgi.component.DiVAComponentOSGi;

/**
* This file was generated using DiVA Studio.
* Visit http://www.ict-diva.eu/ for more details about DiVA.
*/
public class AddressDB implements tutorial.diva.cas.interfaces.IAddressDB, DiVAComponentOSGi{

	private String instanceName;
	
	public String getInstanceName() {
		return instanceName;
	}

	public void setInstanceName(String name) {
		this.instanceName = name;
	}

	public void start() {
		// TODO Auto-generated method stub
		
	}

	public void stop() {
		// TODO Auto-generated method stub
		
	}

 	/* The following (generated) code deal with binding and unbinding the ports of the component */


	/* End of generated code. You can now implement the business logic of the component
	 * (Quick Fix: Add Unimplemented Method)
	 */
	
	   List<IAddress> addressDB = new ArrayList<IAddress>();
	    /* (non-Javadoc)
		 * @see org.diva.runtime.cas.components.IAddressDB#addAddress(org.diva.runtime.cas.interfaces.items.IAddress)
		 */
	    public void addAddress(IAddress address){
	        this.addressDB.add(address);

	    }

	    /* (non-Javadoc)
		 * @see org.diva.runtime.cas.components.IAddressDB#searchAdressesInStandardsFields(java.lang.String)
		 */
	    public List<IAddress> searchAdressesInStandardsFields(String searchCritery){
	        // TODO Auto-generated method stub
	        return null;
	    }
	    
	    /* (non-Javadoc)
		 * @see org.diva.runtime.cas.components.IAddressDB#searchAdressesByPhonenumber(java.lang.String)
		 */
	    public List<IAddress> searchAdressesByPhonenumber(String phonenumber){
	        // TODO Auto-generated method stub
	        return null;
	    }

	    public List<IInformationItem> searchByTitle(String title){
	        // TODO Auto-generated method stub
	        return null;
	    }

	    BundleContext context;
		
		@Override
		public BundleContext getContext() {
			return context;
		}

		@Override
		public void setContext(BundleContext context) {
			this.context = context;
		}
} 
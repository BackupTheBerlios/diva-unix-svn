/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package tutorial.diva.cas.interfaces;


public interface IUserDescription{
    public String getUserName();
    public void setUserName(String name);
    
    public void setPassword(final String password);
    public boolean checkPassword(final String password);
    
    public String getWorkPhone();
    public void setWorkPhone(final String mobilePhone);

    public String getMobilePhone();
    public void setMobilePhone(final String mobilePhone);

}

/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package tutorial.diva.cas.interfaces;


public interface IAddress extends IInformationItem{
    public String getFirstName();
    public void setFirstName(final String familyName);
    
    
    public String getFamilyName();
    public void setFamilyName(final String familyName);
    
    public String getStreet();
    public void setStreet(final String street);

    
    public String getTown();
    public void setTown(final String town);

    public String getCountry();
    public void setCountry(final String town);
    
    public String getZIP();
    public void setZIP(final String zip);


    public String getWorkPhone();
    public void setWorkPhone(final String workPhone);

    public String getMobilePhone();
    public void setMobilePhone(final String mobilePhone);
    

    
}


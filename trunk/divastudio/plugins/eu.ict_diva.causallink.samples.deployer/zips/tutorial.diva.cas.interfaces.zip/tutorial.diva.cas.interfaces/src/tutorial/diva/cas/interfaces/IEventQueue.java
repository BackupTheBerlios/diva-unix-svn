/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package tutorial.diva.cas.interfaces;

public interface IEventQueue{
    
    public void putEvent(IEvent event);
    
    /**
     * Get next event from event queue. Event is not removed
     * @param user
     * @return the next event or <code>null</code>, if no event available
     */
    public IEvent getNext(IUserDescription user);

    /**
     * Get next event from event queue. Event is removed from queue
     * @param user
     * @return the next event or <code>null</code>, if no event available
     */

    public IEvent removeNext(IUserDescription user);
    
    public boolean remove(IEvent event);
    
    public int length(IUserDescription user);
}

package tutorial.diva.cas.interfaces;



public interface IUserInterface {
	public void display(String message);
	public String readInput();

}

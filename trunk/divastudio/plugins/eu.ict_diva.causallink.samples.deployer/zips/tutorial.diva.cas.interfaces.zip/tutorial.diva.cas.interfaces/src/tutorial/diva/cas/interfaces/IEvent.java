/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package tutorial.diva.cas.interfaces;



public interface IEvent{
    
    public IEventSource getEventSource();
    public void setEventSource(final IEventSource soucre);
    
    public String getEventText();
    public void setEventText(final  String text);
    
    
    public EventType getType();
    public void setType(final EventType type);
    
    public EventPriority getPriority();
    public void setPriority(final EventPriority priority);
    
    public IUserDescription getAddressedUser();
    public void setAddressedUser(final IUserDescription user);
    
    public IInformationItem getItem();
    public void setItem(final IInformationItem item);
    
    
}

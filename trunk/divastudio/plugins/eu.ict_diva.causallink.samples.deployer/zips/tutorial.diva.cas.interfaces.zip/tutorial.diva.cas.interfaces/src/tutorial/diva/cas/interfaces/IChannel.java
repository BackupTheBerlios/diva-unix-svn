package tutorial.diva.cas.interfaces;

public interface IChannel {
	public void encapsulate(String messsage, String rank);
}

/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package tutorial.diva.cas.interfaces;

import java.util.List;

/**
 * This interface represent any information item in the CRM database. 
 * 
 * An information item is any piece of information such as addresses, documents, appointments etc. Information items
 * can be linked to other information items through a concept named history. The history collects all information items
 * linked to a certain item in a chronological order (e.g., a customer history showing anything that happened with the 
 * customer such as appointments with customer, mails sent to, or received from, the customer, telephone calls made with 
 * the customer, documents etc.). However, a history is not only relevant in the context of a customer but also for a 
 * certain document, an appointment etc. 
 * 
 * The concept of history is bi-directional that is, if item x shows up in the history of item y, then item y is in the 
 * history of item x.
 * 
 * 
 * @author thomas.genssler (<a href="mailto:thomas.genssler@cas.de">thomas.genssler@cas.de</a>)
 * @version 0.1 (TODO Check type version number!)
 * @since TODO Enter project version number!
 */
public interface IInformationItem{
    public List<IInformationItem> getItemHistory();
    public void addToItemHistory(final IInformationItem item);
    public String getTitle();

}

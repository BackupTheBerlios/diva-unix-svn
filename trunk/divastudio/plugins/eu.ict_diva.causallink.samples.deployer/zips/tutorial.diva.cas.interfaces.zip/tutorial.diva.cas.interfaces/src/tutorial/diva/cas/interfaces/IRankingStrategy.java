/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package tutorial.diva.cas.interfaces;

import java.util.List;


/**
 * Rank information relevance 
 * 
 * @author thomas.genssler (<a href="mailto:thomas.genssler@cas.de">thomas.genssler@cas.de</a>)
 */
public interface IRankingStrategy{
    
    
    /**
     * Filter all relevant pieces of information out of a list of information items 
     * @param history
     * @param user
     * @param context
     * @return the filtered list of information. 
     */
    public List<IInformationItem> getRelevantEntries(List<IInformationItem> history, IUserDescription user, UserContext context);

    /**
     * Filter all relevant pieces of information out of a list of information items. Filter recursively 
     * all information items connected to a certain information item in the input list also.   
     * @param history
     * @param user
     * @param context
     * @return the filtered list of information
     */

    public List<IInformationItem> getRelevantEntriesRecursive(List<IInformationItem> history, IUserDescription user, UserContext context);
    
    public boolean rankEvent(final IEvent event);
    
    public boolean rankEvent(final String rank);
}

package tutorial.diva.cas.interfaces;


public interface ICalendar /*extends IComponent*/ {
	
	public void addAppointment(String name, String rank, String inXseconds);
	public void removeAppointment(String name);
	
/*	public void addAppointment(IAppointment appointment) throws AppointmentConflictAxception;
	public void addAppointments(List<IAppointment> appointments) throws AppointmentConflictAxception;
	public boolean checkAvailability(IAppointment appointment);
	
	public List<IAppointment> getAppointments(List<IUserDescription> users);
	public List<IAppointment> getAppointments(List<IUserDescription> users, Date start, Date end);
	public List<IAppointment> getAllAppointments();
	
	public List<IAppointment> findFreeSlots(List<IUserDescription> users, String event, String time, String type, String priority);
	
	public INotifier getNotifier();
	public void setNotifier(final INotifier notifier);
*/	
}

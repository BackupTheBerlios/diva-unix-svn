package tutorial.diva.cas.interfaces;


public interface ITelephony {

     
    public void send(String message, String rank);

}

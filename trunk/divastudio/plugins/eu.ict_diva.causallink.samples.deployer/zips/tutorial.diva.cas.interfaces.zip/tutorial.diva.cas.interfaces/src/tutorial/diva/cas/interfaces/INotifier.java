/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package tutorial.diva.cas.interfaces;



/**
 * Notify user about certain events such as escalations, new appointments in calendar, deadlines, new mails etc.
 * @author thomas.genssler (<a href="mailto:thomas.genssler@cas.de">thomas.genssler@cas.de</a>)
 */
public interface INotifier{
	
	public boolean notifyUser(final String msg, final String rank);
/*    public boolean notifyUser(final IUserDescription user, final String message);
    public boolean notifyUser(final IEvent e);
 */   
    //public Collection<IRankingStrategy> getRankingStrategies();
    /*public void removeRankingStrategy(final IRankingStrategy strategy);
    public void addRankingStrategy(final IRankingStrategy strategy);*/
}

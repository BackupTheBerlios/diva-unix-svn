package tutorial.diva.cas.interfaces;

import java.util.List;

public interface IAddressDB {
	public void addAddress(IAddress address);
	public List<IAddress> searchAdressesInStandardsFields(String searchCritery);
	public List<IAddress> searchAdressesByPhonenumber(String phonenumber);
	
}

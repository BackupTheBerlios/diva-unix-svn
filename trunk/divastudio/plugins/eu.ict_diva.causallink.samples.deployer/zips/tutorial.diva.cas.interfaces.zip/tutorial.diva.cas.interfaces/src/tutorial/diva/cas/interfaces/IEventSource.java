/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package tutorial.diva.cas.interfaces;

public interface IEventSource{
    public void registerListener(final IEventQueue listener);
    public void deregisterListener(final IEventQueue listener);
    public void fireEvent(IUserDescription user, IEvent event);
}

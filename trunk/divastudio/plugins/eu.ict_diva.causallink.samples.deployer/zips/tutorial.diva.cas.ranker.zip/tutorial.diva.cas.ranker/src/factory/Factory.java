package factory;

/**
* This file was generated using DiVA Studio.
* Visit http://www.ict-diva.eu/ for more details about DiVA.
*/
public class Factory implements eu.diva.factoryinstdiva.Factory<cas.impl.Ranker>{

	private static Factory fact = new Factory();

	public static Factory getFact() {
		return fact;
	}

	public static void setFact(Factory fact) {
		Factory.fact = fact;
	}

	public cas.impl.Ranker createComponent() {
		return new cas.impl.Ranker();
		
	}
	
	public cas.impl.Ranker createComponent(String implementingClass) {
		/*if (check(implementingClass))
			return new cas.impl.Ranker();//Return the right implementing class	
		else*/
			return createComponent();//return the default implementing class
	}

	public boolean check(String implementingClass) {
		try {
			Class<?> c = Class.forName(implementingClass);
			c.asSubclass(cas.impl.Ranker.class);
			return true;
		} catch (ClassNotFoundException e) {
			//e.printStackTrace();
		} catch (ClassCastException e){
			//e.printStackTrace();
		}		
		return false;
	}

}
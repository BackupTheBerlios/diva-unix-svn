package cas.impl;

import java.util.List;

import org.osgi.framework.BundleContext;

import tutorial.diva.cas.interfaces.IEvent;
import tutorial.diva.cas.interfaces.IInformationItem;
import tutorial.diva.cas.interfaces.IRankingStrategy;
import tutorial.diva.cas.interfaces.IUserDescription;
import tutorial.diva.cas.interfaces.UserContext;
import eu.diva.osgi.component.DiVAComponentOSGi;

/**
* This file was generated using DiVA Studio.
* Visit http://www.ict-diva.eu/ for more details about DiVA.
*/
public class Ranker implements IRankingStrategy, DiVAComponentOSGi{

 	/* The following (generated) code deal with binding and unbinding the ports of the component */

	private String instanceName;
	

	/* End of generated code. You can now implement the business logic of the component
	 * (Quick Fix: Add Unimplemented Method)
	 */
	
	
	   public List<IInformationItem> getRelevantEntries(
	            List<IInformationItem> history, IUserDescription user, UserContext context){
	        // TODO Auto-generated method stub
	        return history;
	    }

	    public List<IInformationItem> getRelevantEntriesRecursive(
	            List<IInformationItem> history, IUserDescription user, UserContext context){
	        // TODO Auto-generated method stub
	        return history;
	    }

	    public boolean rankEvent(IEvent event){
	        return true;
	    }
	    
	    public boolean rankEvent(String rank){
	    	return true;
	    }

		public String getInstanceName() {
			return instanceName;
		}

		public void setInstanceName(String name) {
			this.instanceName = name;			
		}

		public void start() {
			// TODO Auto-generated method stub
			
		}

		public void stop() {
			// TODO Auto-generated method stub
			
		}
	
		BundleContext context;
		
		@Override
		public BundleContext getContext() {
			return context;
		}

		@Override
		public void setContext(BundleContext context) {
			this.context = context;
		}	
	
} 


To run the CAS case study on OSGi (Equinox), just launch the runner/CAS_System.launch

You can either simulate context changes by loading context model (this will in turn call the reasoning component) or directly adapt the running system by loading a configuration.

To load a model:
- right click on the model
- copy the location (C:\...)
- paste this location in the text field on the reconfiguration GUI (*.art models in the configurations folder) or in the context GUI (*.xmi in the contexts folder) 

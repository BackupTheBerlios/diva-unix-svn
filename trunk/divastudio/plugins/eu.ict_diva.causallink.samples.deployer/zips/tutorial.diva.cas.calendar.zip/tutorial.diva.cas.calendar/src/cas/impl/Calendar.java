package cas.impl;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.osgi.framework.BundleContext;

import eu.diva.osgi.component.DiVAComponentOSGi;

/**
* This file was generated using DiVA Studio.
* Visit http://www.ict-diva.eu/ for more details about DiVA.
*/
public class Calendar implements tutorial.diva.cas.interfaces.ICalendar, DiVAComponentOSGi, ActionListener{

 	/* The following (generated) code deal with binding and unbinding the ports of the component */

	public void setOutputPorts(String id, String obj){
		System.out.println("COUCOU!");
		System.out.println(id);
		System.out.println(obj);
	}
	
	private tutorial.diva.cas.interfaces.INotifier notifier;

	public void setNotifier(tutorial.diva.cas.interfaces.INotifier server){
		notifier = server;
	}

	private String instanceName;

	/* End of generated code. You can now implement the business logic of the component
	 * (Quick Fix: Add Unimplemented Method)
	 */

    private Hashtable<String, TimerTask> appointments = new Hashtable<String, TimerTask>();

 
    //test
    public void setProperties(Dictionary<Object, Object> props){
    	//System.out.println(props.size());
    }
    
    private String testString;
    
    public void setTestString(String test){
    	//System.out.println("         setTestString("+test+")");
    	this.testString = test;
    }
    
    private float testFloat;
    
    public void setTestFloat(float test){
    	//System.out.println("         setTestFloat("+test+")");
    	this.testFloat = test;
    }
    
    private boolean testBoolean;
    
    public void setTestBoolean(boolean test){
    	//System.out.println("         setTestBoolean("+test+")");
    	this.testBoolean = test;
    }
    
    private char testCharacter;
    
    public void setTestCharacter(char test){
    	//System.out.println("         setTestCharacter("+test+")");
    	this.testCharacter = test;
    }
    
    private byte testByte;
    
    public void setTestByte(byte test){
    	//System.out.println("         setTestByte("+test+")");
    	this.testByte = test;
    }
    //end of test
    
    private JFrame frame; 
	private JTextField nameAppointment, rank, time;
	private JLabel nameLabel, rankLabel, timeLabel;
	private JButton submit;
	private JPanel top, bottom, namePanel, rankPanel, timePanel;

	public Calendar(){
		initComponents();
		layoutComponents();
		setActive(true);
		frame.setVisible(true);
	}
	
	private void initComponents() {
		top = new JPanel();
		bottom = new JPanel();
		
		namePanel = new JPanel();
		rankPanel = new JPanel();
		timePanel = new JPanel();
		
		nameAppointment = new JTextField("Hello Diva",20);
		nameAppointment.setEnabled(true);
		nameAppointment.setEditable(true);
		
		nameLabel = new JLabel("Appointment: ");
		
		rank = new JTextField("important",20);
		rank.setEnabled(true);
		rank.setEditable(true);
		
		rankLabel = new JLabel("Ranking    : ");
		
		time = new JTextField("5",20);
		time.setEnabled(true);
		time.setEditable(true);
		
		timeLabel = new JLabel("Time in s : ");
		
		submit = new JButton("submit");
		submit.addActionListener(this);

		frame = new JFrame("Calendar");
	}
	
	public void setActive(boolean active) {
		System.err.println(active);
		frame.setEnabled(active);
	}
	
	private void layoutComponents() {

		FlowLayout flowLayout = new FlowLayout();
		namePanel.setLayout(flowLayout);
		rankPanel.setLayout(flowLayout);
		timePanel.setLayout(flowLayout);
		
		namePanel.add(nameLabel);
		namePanel.add(nameAppointment);
		
		rankPanel.add(rankLabel);
		rankPanel.add(rank);
		
		timePanel.add(timeLabel);
		timePanel.add(time);
		
		GridLayout layout = new GridLayout(3,1);
		
		top.setLayout(layout);
		
		top.add(namePanel);
		top.add(rankPanel);
		top.add(timePanel);

		bottom.add(submit);

		frame.getContentPane().setLayout(new BorderLayout());
		frame.add(top, BorderLayout.NORTH);
		frame.add(bottom, BorderLayout.SOUTH);

		frame.setPreferredSize(new Dimension(400,200));
		frame.pack();
	}
    
	
	public void addAppointment(String name, String rank, String inXseconds) {
		int delay = Integer.parseInt(inXseconds);
		Timer timer = new Timer(name);
		TimerTask calendarTask = new CalendarTimerTask(name, rank); 
		timer.schedule(calendarTask, delay*1000);
		appointments.put(name, calendarTask);
	}

	
	public void removeAppointment(String name) {
		TimerTask calendarTask = appointments.get(name);
		if (calendarTask != null)
			calendarTask.cancel();
	}

	private class CalendarTimerTask extends TimerTask{
		
		private String name;
		private String rank;
		
		public CalendarTimerTask(String name, String rank){
			this.name = name;
			this.rank = rank;
		}
		
		@Override
		public void run() {
			notifier.notifyUser("Calendar Notification. "+name, rank);
		}
		
	}

	public void actionPerformed(ActionEvent arg0) {
		addAppointment(nameAppointment.getText(), rank.getText(), time.getText());
		nameAppointment.setText("Hello Diva");
		rank.setText("important");
		time.setText("5");
		
	}

	public String getInstanceName() {
		return instanceName;
	}

	public void setInstanceName(String name) {
		this.instanceName = name;
		
	}

	public void start() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		
	}

	BundleContext context;
	
	@Override
	public BundleContext getContext() {
		return context;
	}

	@Override
	public void setContext(BundleContext context) {
		this.context = context;
	}
} 
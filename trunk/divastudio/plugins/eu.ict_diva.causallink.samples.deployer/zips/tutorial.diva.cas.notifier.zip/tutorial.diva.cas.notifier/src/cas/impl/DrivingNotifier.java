/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package cas.impl;


/**
 * Notify user when user is driving and cannot read screen bor text messages. Messages are read through the phone. 
 * @author thomas.genssler (<a href="mailto:thomas.genssler@cas.de">thomas.genssler@cas.de</a>)
 */
public class DrivingNotifier extends Notifier{

    //protected IOutputDevice phone/* = new PhoneChannel()*/;
    
    
    
/*    public DrivingNotifier(){
        this.addRankingStrategy(new BandwidthLimitationRankingStrategy());
    }
*/
/*    public boolean notifyUser(final IUserDescription user, String message){
        
        output.writeDevice(message);
        return true;

    }
*/
    protected void doNotify(final String msg, final String rank){
    	super.doNotify("Driving. "+msg, rank);
    }
    
/*    public boolean notifyUser(final IEvent e){
        boolean result = rankEvent(e); 
        if(result){
            output.writeDevice(e.getEventText());
        }
        return true;
    }
*/
  
}

/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package cas.impl;


/**
 * Notify user when user is in meeting and cannot read screen or answer voice phone.
 * @author thomas.genssler (<a href="mailto:thomas.genssler@cas.de">thomas.genssler@cas.de</a>)
 */
public class MeetingNotifier extends Notifier{

    //protected IOutputDevice sms = new SMSChannel();
    
/*    public MeetingNotifier(){
        this.addRankingStrategy(new BandwidthLimitationRankingStrategy());
    }
*/    
/*    public boolean notifyUser(final IUserDescription user, String message){
        
        output.writeDevice(message);
        return true;
    }
*/  
    protected void doNotify(final String msg, final String rank){
    	super.doNotify("[inMeeting] "+msg, rank);
    }
    
/*    public boolean notifyUser(final IEvent e){
        boolean result = rankEvent(e); 
        if(result){
            output.writeDevice(e.getEventText());
        }
        return result;
    }
*/

}

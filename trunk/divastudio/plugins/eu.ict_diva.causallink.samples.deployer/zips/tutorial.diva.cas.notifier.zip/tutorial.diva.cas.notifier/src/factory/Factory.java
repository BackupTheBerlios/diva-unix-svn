package factory;

/**
 * This file was generated using DiVA Studio.
 * Visit http://www.ict-diva.eu/ for more details about DiVA.
 */
public class Factory implements eu.diva.factoryinstdiva.Factory<cas.impl.Notifier>{

	private static Factory fact = new Factory();

	public static Factory getFact() {
		return fact;
	}

	public static void setFact(Factory fact) {
		Factory.fact = fact;
	}

	public cas.impl.Notifier createComponent() {
		return new cas.impl.Notifier();

	}

	public cas.impl.Notifier createComponent(String implementingClass) {
		if (check(implementingClass)){
			if(implementingClass.equals("cas.impl.DrivingNotifier"))
				return new cas.impl.DrivingNotifier();
			else if(implementingClass.equals("cas.impl.OfficeNotifier"))
				return new cas.impl.OfficeNotifier();
			else if(implementingClass.equals("cas.impl.MeetingNotifier"))
				return new cas.impl.MeetingNotifier();
			else
				return createComponent();
		}
		else
			return createComponent();//return the default implementing class
	}

	public boolean check(String implementingClass) {
		try {
			Class<?> c = Class.forName(implementingClass);
			c.asSubclass(cas.impl.Notifier.class);
			return true;
		} catch (ClassNotFoundException e) {
			//e.printStackTrace();
		} catch (ClassCastException e){
			//e.printStackTrace();
		}		
		return false;
	}

}
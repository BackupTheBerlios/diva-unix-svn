package cas.impl;

import java.util.HashMap;

import org.osgi.framework.BundleContext;

import tutorial.diva.cas.interfaces.ICalendar;
import tutorial.diva.cas.interfaces.IChannel;
import tutorial.diva.cas.interfaces.INotifier;
import tutorial.diva.cas.interfaces.IRankingStrategy;
import eu.diva.osgi.component.DiVAComponentOSGi;

/**
* This file was generated using DiVA Studio.
* Visit http://www.ict-diva.eu/ for more details about DiVA.
*/
public class Notifier implements INotifier, DiVAComponentOSGi{

	//test
	
	private ICalendar calendarTest;
	
	public void setCalendarTest(ICalendar calendarTest){
		this.calendarTest = calendarTest;
	}
	
	
	/* The following (generated) code deal with binding and unbinding the ports of the component */

	private IChannel channel;
	
	private String instanceName;

	public Object getPortById(String s){
		return new String();
	}
	
	public void setChannel(IChannel server){
		channel = server;
	}

	private HashMap<String, IRankingStrategy> rankingStrategies = new HashMap<String, IRankingStrategy>();

	public void setRankingStrategies(String id, IRankingStrategy server){
		rankingStrategies.put(id, server);
	}

	public void unsetRankingStrategies(String id){
		rankingStrategies.remove(id);
	}

    public boolean notifyUser(final String msg, final String rank){
    	boolean result = true;
    	for (IRankingStrategy strategy : rankingStrategies.values()){
    		result &= strategy.rankEvent(rank);
    	}
    	
    	if (result)
    		doNotify(rank+". "+msg, rank);
    	return result;
    }
    
    protected void doNotify(final String msg, final String rank){
    	channel.encapsulate(msg, rank);
    }


	public String getInstanceName() {
		return instanceName;
	}

	public void setInstanceName(String name) {
		this.instanceName = name;
		
	}

	public void start() {
		// TODO Auto-generated method stub
		
	}

	public void stop() {
		// TODO Auto-generated method stub
		
	}

BundleContext context;
	
	@Override
	public BundleContext getContext() {
		return context;
	}

	@Override
	public void setContext(BundleContext context) {
		this.context = context;
	}

	/* End of generated code. You can now implement the business logic of the component
	 * (Quick Fix: Add Unimplemented Method)
	 */
} 
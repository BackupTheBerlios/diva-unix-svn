/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package cas.impl;

/**
 * 
 * Default notifier when user is in office working at his desk 
 * 
 * @author thomas.genssler (<a href="mailto:thomas.genssler@cas.de">thomas.genssler@cas.de</a>)
 */
public class OfficeNotifier extends Notifier{
    
    //protected GraphicConsole console = new GraphicConsole();
  
	   protected void doNotify(final String msg, final String rank){
	    	super.doNotify("[inOffice] "+msg, rank);
	    }
	
/*    public OfficeNotifier(){
        this.addRankingStrategy(new DefaultRankingStrategy());
    }
*/    
/*    public boolean notifyUser(final IUserDescription user, final String message){
        output.writeDevice(message);
        return true;
    }
    
 
    public boolean notifyUser(final IEvent e){
        output.writeDevice(e.getEventText());
        return true;
    }
*/    
}

/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package cas.impl;

import tutorial.diva.cas.interfaces.CallDirection;
import tutorial.diva.cas.interfaces.CallStatus;

/**
 * 
 * Use web telephony such as JahJah 
 * 
 * @author thomas.genssler (<a href="mailto:thomas.genssler@cas.de">thomas.genssler@cas.de</a>)
 * 
 */
public class WebTelephony extends Telephony{

    public CallStatus doCall(String phonenumber, CallDirection direction){
        
        // Do web telephony stuff
        
        return CallStatus.callAccepted;
    }
	
	public void send(String message, String rank) {
		notifier.notifyUser(" via the Web: "+message, rank);
	}  

}

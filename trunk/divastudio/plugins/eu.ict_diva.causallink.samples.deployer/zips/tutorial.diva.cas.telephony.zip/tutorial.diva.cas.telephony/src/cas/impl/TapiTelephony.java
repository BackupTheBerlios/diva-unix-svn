/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package cas.impl;


/**
 * Use locally available TAPI telephony
 * 
 * @author thomas.genssler (<a href="mailto:thomas.genssler@cas.de">thomas.genssler@cas.de</a>)
 */
public class TapiTelephony extends Telephony{

	/*    public CallStatus doCall(String phonenumber, CallDirection direction){

        // Do TAPI stuff

        return CallStatus.callAccepted;
    }
	 */
	
	public void send(String message, String rank) {
		if (message.startsWith("TAPI: "))
			notifier.notifyUser(" via TAPI: "+message, rank);	
	}

}

package cas.impl;

import org.osgi.framework.BundleContext;

import tutorial.diva.cas.interfaces.IAddressDB;
import tutorial.diva.cas.interfaces.INotifier;
import tutorial.diva.cas.interfaces.ITelephony;
import eu.diva.osgi.component.DiVAComponentOSGi;

/**
* This file was generated using DiVA Studio.
* Visit http://www.ict-diva.eu/ for more details about DiVA.
*/
public abstract class Telephony implements ITelephony, DiVAComponentOSGi{

 	/* The following (generated) code deal with binding and unbinding the ports of the component */

	private String instanceName;
	
	protected IAddressDB addressDB;

	public void setAddressDB(IAddressDB server){
		addressDB = server;
	}

	protected INotifier notifier;

	public void setNotifier(INotifier server){
		notifier = server;
	}

	@Override
	public void send(String message, String rank) {
		// TODO Auto-generated method stub
		
	}

	public String getInstanceName() {
		return instanceName;
	}
	

	public void setInstanceName(String name) {
		this.instanceName = name;
		
	}

	public void start() {
		// TODO Auto-generated method stub
		
	}

	public void stop() {
		// TODO Auto-generated method stub
		
	}

BundleContext context;
	
	@Override
	public BundleContext getContext() {
		return context;
	}

	@Override
	public void setContext(BundleContext context) {
		this.context = context;
	}

	/* End of generated code. You can now implement the business logic of the component
	 * (Quick Fix: Add Unimplemented Method)
	 */
} 
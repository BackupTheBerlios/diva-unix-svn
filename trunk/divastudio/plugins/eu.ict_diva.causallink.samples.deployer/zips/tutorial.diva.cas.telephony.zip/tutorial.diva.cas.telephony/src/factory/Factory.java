package factory;

import cas.impl.ForwardTelephony;
import cas.impl.SkypeTelephony;
import cas.impl.TapiTelephony;
import cas.impl.WebTelephony;

/**
* This file was generated using DiVA Studio.
* Visit http://www.ict-diva.eu/ for more details about DiVA.
*/
public class Factory implements eu.diva.factoryinstdiva.Factory<cas.impl.Telephony>{

	private static Factory fact = new Factory();

	public static Factory getFact() {
		return fact;
	}

	public static void setFact(Factory fact) {
		Factory.fact = fact;
	}

	public cas.impl.Telephony createComponent() {
		return new cas.impl.ForwardTelephony();
		
	}
	
	public cas.impl.Telephony createComponent(String implementingClass) {
		if (check(implementingClass)){
			if (implementingClass.equals("cas.impl.ForwardTelephony"))
				return new ForwardTelephony();
			else if (implementingClass.equals("cas.impl.SkypeTelephony"))
				return new SkypeTelephony();
			else if (implementingClass.equals("cas.impl.TapiTelephony"))
				return new TapiTelephony();
			else if (implementingClass.equals("cas.impl.WebTelephony"))
				return new WebTelephony();
		}
		return createComponent();//return the default implementing class
	}

	public boolean check(String implementingClass) {
		try {
			Class<?> c = Class.forName(implementingClass);
			c.asSubclass(cas.impl.Telephony.class);
			return true;
		} catch (ClassNotFoundException e) {
			//e.printStackTrace();
		} catch (ClassCastException e){
			//e.printStackTrace();
		}		
		return false;
	}

}
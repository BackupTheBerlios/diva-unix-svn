/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package cas.impl;



/**
 * Use Skype for telephony
 * 
 * @author thomas.genssler (<a href="mailto:thomas.genssler@cas.de">thomas.genssler@cas.de</a>)
 * 
 */
public class ForwardTelephony extends Telephony{

	/*    public CallStatus doCall(String phonenumber, CallDirection direction){

        // Do Skype stuff

        return CallStatus.callAccepted;
    }
	 */

	
	public void send(String message, String rank) {
			notifier.notifyUser(" {FORWARDED} "+message, rank);	
	}
}

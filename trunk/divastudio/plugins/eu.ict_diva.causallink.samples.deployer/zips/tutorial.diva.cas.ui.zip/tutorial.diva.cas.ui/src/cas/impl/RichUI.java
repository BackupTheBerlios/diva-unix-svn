package cas.impl;



import javax.swing.JOptionPane;


public class RichUI extends UserInterface {

    //protected GraphicConsole console/* = new GraphicConsole()*/;
	public void display(String message) {
	
		JOptionPane.showMessageDialog(null, message, "Info", JOptionPane.INFORMATION_MESSAGE);		
		
/*        Display display = new Display();
        
        Shell shell = new Shell(display);
        shell.setText("RichUI");

        Label label = new Label(shell, SWT.CENTER);
        label.setText(message);
        label.pack();

        shell.setSize(150, 50);
        shell.open ();
       
       while (!shell.isDisposed ()) {
            if (!display.readAndDispatch ()) display.sleep ();
        }
        //display.dispose ();
*/		

	}
	
	public String readInput(){
		return "";
    }
}

package factory;

/**
 * This file was generated using DiVA Studio.
 * Visit http://www.ict-diva.eu/ for more details about DiVA.
 */
public class Factory implements eu.diva.factoryinstdiva.Factory<cas.impl.UserInterface>{

	private static Factory fact = new Factory();

	public static Factory getFact() {
		return fact;
	}

	public static void setFact(Factory fact) {
		Factory.fact = fact;
	}

	public cas.impl.UserInterface createComponent() {
		return new cas.impl.ReducedUI();

	}

	public cas.impl.UserInterface createComponent(String implementingClass) {
		if (check(implementingClass)){
			if(implementingClass.equals("cas.impl.ReducedUI"))
				return new cas.impl.ReducedUI();
			else if(implementingClass.equals("cas.impl.RichUI"))
				return new cas.impl.RichUI();
			else if(implementingClass.equals("cas.impl.VoiceUI"))
				return new cas.impl.VoiceUI();
			else 
				createComponent();
		}
		return createComponent();
	}

	public boolean check(String implementingClass) {
		try {
			Class<?> c = Class.forName(implementingClass);
			c.asSubclass(cas.impl.UserInterface.class);
			return true;
		} catch (ClassNotFoundException e) {
			//e.printStackTrace();
		} catch (ClassCastException e){
			//e.printStackTrace();
		}		
		return false;
	}

}
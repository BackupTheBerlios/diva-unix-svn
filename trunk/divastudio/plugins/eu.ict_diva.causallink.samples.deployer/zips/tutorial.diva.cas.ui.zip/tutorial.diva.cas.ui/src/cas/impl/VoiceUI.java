/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package cas.impl;


/**
 * 
 * Read messages through voice interface  
 * 
 * @author thomas.genssler (<a href="mailto:thomas.genssler@cas.de">thomas.genssler@cas.de</a>)
 */
public class VoiceUI extends UserInterface{

    //protected PhoneChannel phone/* = new PhoneChannel()*/;
    
    public void display(String message){
        // read message via voice interface
		System.out.println("Synthetic Voice");
		System.out.println("---------------");
		System.out.println(message);
		System.out.println();
		
    }

    public String readInput(){
        return "";
    }

    
    
}

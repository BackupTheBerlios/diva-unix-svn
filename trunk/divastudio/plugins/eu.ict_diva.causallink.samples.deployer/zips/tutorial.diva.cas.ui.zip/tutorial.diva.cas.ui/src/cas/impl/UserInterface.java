package cas.impl;

import org.osgi.framework.BundleContext;

import tutorial.diva.cas.interfaces.IUserInterface;
import eu.diva.osgi.component.DiVAComponentOSGi;

/**
* This file was generated using DiVA Studio.
* Visit http://www.ict-diva.eu/ for more details about DiVA.
*/
public abstract class UserInterface implements IUserInterface, DiVAComponentOSGi{

	private String instanceName;

	public String getInstanceName() {
		return instanceName;
	}

	public void setInstanceName(String name) {
		this.instanceName = name;		
	}

	public void start() {
		// TODO Auto-generated method stub
		
	}

	public void stop() {
		// TODO Auto-generated method stub
		
	}

BundleContext context;
	
	@Override
	public BundleContext getContext() {
		return context;
	}

	@Override
	public void setContext(BundleContext context) {
		this.context = context;
	}
	
 	/* The following (generated) code deal with binding and unbinding the ports of the component */


	/* End of generated code. You can now implement the business logic of the component
	 * (Quick Fix: Add Unimplemented Method)
	 */
} 
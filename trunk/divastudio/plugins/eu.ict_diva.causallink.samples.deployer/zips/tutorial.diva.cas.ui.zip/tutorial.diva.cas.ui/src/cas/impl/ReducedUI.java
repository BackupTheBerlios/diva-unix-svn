package cas.impl;



public class ReducedUI extends UserInterface {

    //protected SmartPhone smartphone/* = new SmartPhone()*/;
    
	public void display(String message) {
		System.out.println("ReducedUI");
		System.out.println("---------");
		System.out.println(message);
		System.out.println();
	}
	public String readInput(){
	    return ""; 
	}
}

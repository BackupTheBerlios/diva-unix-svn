/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package cas.impl;


public class RichMessageChannel extends Channel{

	public void encapsulate(String message, String rank) {
		ui.display("New Rich Message: "+message);
		
	}

}

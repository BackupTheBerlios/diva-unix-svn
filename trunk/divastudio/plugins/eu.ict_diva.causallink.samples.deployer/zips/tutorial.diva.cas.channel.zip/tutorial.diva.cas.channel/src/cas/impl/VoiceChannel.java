/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package cas.impl;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.util.Hashtable;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;

import factory.Activator;
import fr.irisa.triskell.nabaztag.connector.NabConnector;
import fr.irisa.triskell.nabaztag.control.ControlCommandFactory;
import fr.irisa.triskell.nabaztag.messages.PreviewMessage;
import fr.irisa.triskell.utility.FileUtilities;


/**
 * Call user on phone and read 
 * TODO Describe the purpose of this class! 
 * 
 * @author thomas.genssler (<a href="mailto:thomas.genssler@cas.de">thomas.genssler@cas.de</a>)
 * @version 0.1 (TODO Check type version number!)
 * @since TODO Enter project version number!
 */
public class VoiceChannel extends Channel{

	private String localFile = null;

	private Hashtable<String, String> messagesFiles = new Hashtable<String, String>();
	
	private String downloadFolder;
	
	public void encapsulate(final String message, String rank) {
		ui.display("New Voice Message: "+message);

		final String newMessage = message.substring(message.lastIndexOf(".")+1,message.length());

		//System.err.println(newMessage);

		boolean isConnected = true;

		try {
			URL testURL = new URL("http://www.kermeta.org");
			testURL.getContent();
		} catch (MalformedURLException e1) {
			//should never happen, the URL is actually well formed.
			//e1.printStackTrace();
		} catch (IOException e) {
			//happens when not connected to the Internet
			if (e instanceof UnknownHostException)
				isConnected = false;
			//e.printStackTrace();
		}

		//System.out.println("isConnected? "+isConnected);
		final Thread getMP3thread = new Thread(
				new Runnable(){
					
					public void run() {
						try{
							fileDownload(generateMP3URL(newMessage), downloadFolder/*"./messages"*/);
						} catch (Exception e){

						}
					}
				});

		if (isConnected){
			getMP3thread.start();
		}

		playMP3(messagesFiles.get("messages/IncomingVoiceMessage.mp3"));
		//playMP3("C:/Documents and Settings/bmorin/Bureau/IncomingVoiceMessage.mp3");

		if(message.contains("Calendar Notification. ")){
			playMP3(messagesFiles.get("messages/YouHaveAnAppointmentRightNow.mp3"));
			//playMP3("C:/Documents and Settings/bmorin/Bureau/YouHaveAnAppointmentRightNow.mp3");
		}

		if (isConnected){
			if (rank.equals("important")){
				playMP3(messagesFiles.get("messages/ThisIsAnImportantMessage.mp3"));
				//playMP3("C:/Documents and Settings/bmorin/Bureau/ThisIsAnImportantMessage.mp3");
			}
			else if (rank.equals("critical")){
				playMP3(messagesFiles.get("messages/BeCarefulThisIsAnImportantMessage.mp3"));
				//playMP3("C:/Documents and Settings/bmorin/Bureau/BeCarefulThisIsAnImportantMessage.mp3");
			}

			Thread playGeneratedMP3 = new Thread(
					new Runnable(){
						
						public void run() {
							while(getMP3thread.isAlive()){
								//System.err.println("Text to Speech: waiting...");
							}
							if (localFile != null)
								playMP3(localFile);
							else
								System.err.println("Timeout: Cannot download MP3 file");
							localFile = null;
						}
					});

			playGeneratedMP3.start();
		}
	}

	private String generateMP3URL(String textToSay){
		NabConnector connector = new NabConnector("0013D38469BA","1237107579");

		String command = ControlCommandFactory.createPreviewCommand(
				ControlCommandFactory.PREVIEW_TTS_MP3, 
				"voice=US-Bethany&tts=" + textToSay.replace(" ", "+"));

		PreviewMessage response = (PreviewMessage)connector.send(command);		
		if (response != null)
			return response.getMp3Addr();
		else
			return null;
	}

	private void playMP3(String fileName){
		try{		File file = new File(fileName);
		AudioInputStream in = AudioSystem.getAudioInputStream(file);
		AudioFormat baseFormat = in.getFormat();
		AudioFormat decodedFormat = new AudioFormat(
				AudioFormat.Encoding.PCM_SIGNED,
				baseFormat.getSampleRate(), 16, baseFormat.getChannels(),
				baseFormat.getChannels() * 2, baseFormat.getSampleRate(),
				false);
		AudioInputStream din = AudioSystem.getAudioInputStream(decodedFormat, in);
		DataLine.Info info = new DataLine.Info(SourceDataLine.class, decodedFormat);
		SourceDataLine line = (SourceDataLine) AudioSystem.getLine(info);
		if(line != null) {
			line.open(decodedFormat);
			byte[] data = new byte[4096];
			// Start
			line.start();

			int nBytesRead;
			while ((nBytesRead = din.read(data, 0, data.length)) != -1) {	
				line.write(data, 0, nBytesRead);
			}
			// Stop
			line.drain();
			line.stop();
			line.close();
			din.close();

		}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	private void fileUrl(String fAddress, String localFileName, String destinationDir) {
		OutputStream outStream = null;
		URLConnection  uCon = null;

		InputStream is = null;
		try {
			URL Url;
			byte[] buf;
			int ByteRead,ByteWritten=0;
			Url= new URL(fAddress);
			outStream = new BufferedOutputStream(new
					FileOutputStream(destinationDir+"/"+localFileName));

			uCon = Url.openConnection();
			is = uCon.getInputStream();
			buf = new byte[1024];
			while ((ByteRead = is.read(buf)) != -1) {
				outStream.write(buf, 0, ByteRead);
				ByteWritten += ByteRead;
			}
			System.out.println("Downloaded Successfully.");
			System.out.println("File name:\""+localFileName+ "\"\nNo ofbytes :" + ByteWritten);
		}
		catch (java.io.FileNotFoundException e) {
			//e.printStackTrace();
		} catch (IOException e) {
			//e.printStackTrace();
		}
		finally {
			try {
				is.close();
				outStream.close();
			}
			catch (IOException e) {
				e.printStackTrace();
			}}}


	private String fileDownload(String fAddress, String destinationDir)
	{
		if (fAddress != null){
			int slashIndex =fAddress.lastIndexOf('/');
			int periodIndex =fAddress.lastIndexOf('.');

			String fileName=fAddress.substring(slashIndex + 1);

			if (periodIndex >=1 &&  slashIndex >= 0 && slashIndex < fAddress.length()-1)
			{
				fileUrl(fAddress,fileName,destinationDir);
				localFile = destinationDir+"/"+fileName;
				return destinationDir+"/"+fileName;
			}
			else
			{
				System.err.println("path or file name.");
				return null;
			}
		}
		else{
			return null;
		}
	}
	
	public void start() {
		downloadFolder = fr.irisa.triskell.utility.FileUtilities.createTempDir("downloadedMessages").getAbsolutePath();
		
		
		String[] fileNames = new String[]{
				"messages/BeCarefulThisIsAnImportantMessage.mp3", "messages/IncomingVoiceMessage.mp3",
				"messages/ThisIsAnImportantMessage.mp3", "messages/YouHaveAnAppointmentRightNow.mp3"
		};

		FileUtilities.createTempDir("messages");
		for(String message : fileNames) {
			try {
				File mp3 = FileUtilities.createTempFile(message);
				InputStream is = Activator.context.getBundle().getEntry(message).openStream();

				OutputStream os = new FileOutputStream(mp3);
				FileUtilities.copyFile(is, os);
				messagesFiles.put(message, mp3.getAbsolutePath());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}				
	}

}

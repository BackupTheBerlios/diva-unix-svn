/*
 * Created on 17.11.2008 by thomas.genssler
 *  
 * CHANGE HISTORY
 * ==============
 * - Compilation unit created on 17.11.2008 by thomas.genssler (mailto:thomas.genssler@cas.de)
 *
 */
package cas.impl;



/**
 * 
 * Use text message service (SMS) as output device 
 * @author thomas.genssler (<a href="mailto:thomas.genssler@cas.de">thomas.genssler@cas.de</a>)
 */
public class TextChannel extends Channel{

	public void encapsulate(String message, String rank) {
		ui.display("New SMS: "+message);
		
	}
}

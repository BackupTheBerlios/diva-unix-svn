package factory;

import cas.impl.Channel;
import cas.impl.RichMessageChannel;
import cas.impl.TextChannel;
import cas.impl.VoiceChannel;

/**
 * This file was generated using DiVA Studio.
 * Visit http://www.ict-diva.eu/ for more details about DiVA.
 */
public class Factory implements eu.diva.factoryinstdiva.Factory<Channel>{

	private static Factory fact = new Factory();

	public static Factory getFact() {
		return fact;
	}

	public static void setFact(Factory fact) {
		Factory.fact = fact;
	}

	public Channel createComponent() {
		return new TextChannel();

	}

	public Channel createComponent(String implementingClass) {
		if (check(implementingClass)){
			if(implementingClass.equals("cas.impl.RichMessageChannel"))
				return new RichMessageChannel();
			else if(implementingClass.equals("cas.impl.TextChannel"))
				return new TextChannel();
			else if(implementingClass.equals("cas.impl.VoiceChannel"))
				return new VoiceChannel();			
		}	
		return createComponent();
	}

	public boolean check(String implementingClass) {
		try {
			Class<?> c = Class.forName(implementingClass);
			c.asSubclass(Channel.class);
			return true;
		} catch (ClassNotFoundException e) {
			//e.printStackTrace();
		} catch (ClassCastException e){
			//e.printStackTrace();
		}		
		return false;
	}

}
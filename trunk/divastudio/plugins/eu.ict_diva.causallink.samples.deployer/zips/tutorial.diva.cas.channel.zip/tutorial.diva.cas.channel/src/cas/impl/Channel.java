package cas.impl;


import org.osgi.framework.BundleContext;

import tutorial.diva.cas.interfaces.IChannel;
import tutorial.diva.cas.interfaces.IUserInterface;
import eu.diva.osgi.component.DiVAComponentOSGi;

public abstract class Channel implements IChannel, DiVAComponentOSGi {

	protected tutorial.diva.cas.interfaces.IUserInterface ui;
	
	private String instanceName;
	
	public void setUi(IUserInterface ui){
		this.ui = ui;
	}
	
	public String getInstanceName() {
		return instanceName;
	}

	public void setInstanceName(String name) {
		this.instanceName = name;
	}

	public void start() {
		// TODO Auto-generated method stub
		
	}

	public void stop() {
		// TODO Auto-generated method stub
		
	}
	
BundleContext context;
	
	@Override
	public BundleContext getContext() {
		return context;
	}

	@Override
	public void setContext(BundleContext context) {
		this.context = context;
	}

}

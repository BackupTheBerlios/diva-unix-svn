package de.pure.diva.arf.alloy.sat;

public class AlloySATConstants {

  public static final int    ALLOY_SOLUTION_MAX_COUNT        = 0;
  public static final String ALLOY_SOLUTION_SEPERATOR        = "\n";
  public static final String ALLOY_SOLUTION_MEMBER_SEPERATOR = " ";

}

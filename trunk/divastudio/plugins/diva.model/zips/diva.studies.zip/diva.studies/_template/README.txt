This folder contains a sample dummy model which can be used as a starting point.
Just copy the _template.diva file wherever you want and start implementing your own model.
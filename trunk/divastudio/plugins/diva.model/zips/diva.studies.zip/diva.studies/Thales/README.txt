This folder contains the initial implementation of the crisis management scenario.
The model is not complete and probably contains mistakes.
Simulation works on this model but it does not mean much since the model is not complete
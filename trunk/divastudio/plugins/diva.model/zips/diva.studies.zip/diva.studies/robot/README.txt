This folder contains a robot example created by SINTEF.
The example is detailed in the ECMDA submission.
The model is a complete and include the simulation scenario described in the paper.
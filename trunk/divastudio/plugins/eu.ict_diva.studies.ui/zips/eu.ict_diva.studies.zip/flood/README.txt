This folder contains the flood prediction example model.
It has been described in a Models@runtime special issue paper.
The model is complete and includes some simple simulation.
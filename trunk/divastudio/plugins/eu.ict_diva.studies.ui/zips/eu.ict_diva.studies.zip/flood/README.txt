This folder contains the flood prediction example model which is been used as a kick-off example.
It has been described in the Models@runtime special issue paper.
The model is complete and includes some simple simulation.
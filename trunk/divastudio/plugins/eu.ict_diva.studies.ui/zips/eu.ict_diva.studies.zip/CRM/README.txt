This folder contains an example model of a CRM system.
The model is a complete small scenario and includes some simple simulation.
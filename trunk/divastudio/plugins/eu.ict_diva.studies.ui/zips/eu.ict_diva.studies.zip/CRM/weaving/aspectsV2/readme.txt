###########################
#SmartAdapters V2 for DiVA#
###########################

STEP1: Aspect Compilation
-------------------------

- Right click on each .smART file -> Compile Aspect

- Refresh the folder: one .drl file should be created for each aspect

STEP2: Aspect Weaving
---------------------

- Select all .drl files and an .art model. 

- Right click -> Weave Aspect

- Refresh the folder containing the base model, it should create a *woven.clean.art model that you can transform into artext
This folder contains the last version of the initial CAS case study scenario.

To run the runtime part of the CAS case study, you should:
  - deploy the runtime tools (File -> New -> Examples...)
  - deploy the runtime CAS samples (File -> New -> Examples...)
  
See the runtime CAS samples for more instructions. 


This folder contains the last version of the initial CAS case study scenario.
The model is a complete small scenario and includes some simple simulation.
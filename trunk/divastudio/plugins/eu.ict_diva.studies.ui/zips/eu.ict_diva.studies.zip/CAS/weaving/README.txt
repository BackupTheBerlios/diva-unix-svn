This folder contains the last version of the initial CAS case study scenario.

Before running the example, you should first deploy the weaving tools (File -> New -> Examples...)

It is organized as follows:
  -the aspects folder contains the aspect models. Each aspect is defined by :
    * an advice, which contains the elements to be integrated in a base model
    * a pointcut, which describes where the advice should be woven
    * a composition protocol, which describes how to integrate the advice into the pointcut
  -the base folder contains the base model
  -the build folder contains woven models
    * the test folder contains pre-generated configurations
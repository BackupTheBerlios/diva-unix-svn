###########################
#SmartAdapters V2 for DiVA#
###########################

STEP1: Aspect Compilation
-------------------------

- Right click on each .smART file -> Compile Aspect

- Refresh the folder: one .drl file should be created for each aspect

STEP2: Aspect Weaving
---------------------

- Select (in the right order) a .drl file and an .art model. 
For example: aspectsV2/01_drivingAspect.drl and base/baseModel.art

- Right click -> Weave Aspect

- Refresh the folder containing the base model, it should create a *woven.art model
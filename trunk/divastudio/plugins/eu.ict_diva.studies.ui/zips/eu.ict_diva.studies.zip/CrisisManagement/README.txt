This folder contains some initial implementation models of a crisis management scenario.
These models only cover part of the complete system and can be used as examples.
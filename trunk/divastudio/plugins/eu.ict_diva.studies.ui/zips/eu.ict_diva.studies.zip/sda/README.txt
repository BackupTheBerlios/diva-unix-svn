This folder contains the service discovery example.
This example was used in the models'08 and models@runtime'08 papers.
It works but it is a bit too small to really see the benefit of the property-based approach.
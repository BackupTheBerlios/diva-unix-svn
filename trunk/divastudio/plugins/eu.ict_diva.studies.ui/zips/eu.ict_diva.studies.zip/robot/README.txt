This folder contains a robot example.

The example is detailed in:

Franck Fleurey and Arnor Solberg. 
A Domain Specific Modeling Language supporting Specification, Simulation and Execution of Dynamic Adaptive Systems. 
In proceedings of the MoDELS/UML 2009 conference

The model is a complete and include the simulation scenario described in the paper.
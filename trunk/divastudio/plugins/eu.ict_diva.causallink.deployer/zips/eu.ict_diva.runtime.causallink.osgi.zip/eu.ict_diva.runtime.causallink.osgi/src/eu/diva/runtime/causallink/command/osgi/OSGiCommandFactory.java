package eu.diva.runtime.causallink.command.osgi;

import java.util.Map;

import org.apache.log4j.Logger;
import org.osgi.framework.Bundle;

import art.instance.ComponentInstance;
import eu.diva.osgi.component.DiVAComponent;
import eu.diva.runtime.command.AddBinding;
import eu.diva.runtime.command.AddComponent;
import eu.diva.runtime.command.AddNode;
import eu.diva.runtime.command.PlatformCommand;
import eu.diva.runtime.command.RemoveBinding;
import eu.diva.runtime.command.RemoveComponent;
import eu.diva.runtime.command.RemoveNode;
import eu.diva.runtime.command.StartComponent;
import eu.diva.runtime.command.StopComponent;
import eu.diva.runtime.command.UpdateAttribute;

public class OSGiCommandFactory 
{

	private static Logger logger = Logger.getLogger(OSGiCommandFactory.class);
	private Map<Bundle, ComponentInstance> map;
	private Map<DiVAComponent, ComponentInstance> map2;
	
	public void setMap(Map<Bundle, ComponentInstance> map) {
		this.map = map;
	}

	public void setMap2(Map<DiVAComponent, ComponentInstance> map2) {
		this.map2 = map2;
	}

	public OSGiCommand createFromReference( PlatformCommand reference )
	{
		OSGiCommand cmd = null;
		if( reference instanceof AddBinding )
		{
			cmd = new AddBindingOSGi((AddBinding)reference);
		}
		else if( reference instanceof AddComponent )
		{
			cmd = new AddComponentOSGi((AddComponent)reference);
			((AddComponentOSGi)cmd).setMap(map);
			((AddComponentOSGi)cmd).setMap2(map2);
		}
		else if( reference instanceof AddNode )
		{
			cmd = new AddNodeOSGi((AddNode)reference);
		}
		else if( reference instanceof RemoveBinding )
			cmd = new RemoveBindingOSGi((RemoveBinding)reference);
		else if( reference instanceof RemoveComponent )
		{
			cmd = new RemoveComponentOSGi((RemoveComponent)reference);
			((RemoveComponentOSGi)cmd).setMap(map);
			((RemoveComponentOSGi)cmd).setMap2(map2);
		}
		else if( reference instanceof RemoveNode )
		{
			cmd = new RemoveNodeOSGi((RemoveNode)reference);
		}
		else if( reference instanceof StartComponent )
		{
			cmd = new StartComponentOSGi((StartComponent)reference);
		}
		else if( reference instanceof StopComponent )
		{
			cmd = new StopComponentOSGi((StopComponent)reference);
		}
		else if( reference instanceof UpdateAttribute )
			cmd = new UpdateAttributeOSGi((UpdateAttribute)reference);
		else
			logger.warn("Not creating command from unknown cmd type: " + reference.getClass().getName());
		
		return cmd;
	}
	
}

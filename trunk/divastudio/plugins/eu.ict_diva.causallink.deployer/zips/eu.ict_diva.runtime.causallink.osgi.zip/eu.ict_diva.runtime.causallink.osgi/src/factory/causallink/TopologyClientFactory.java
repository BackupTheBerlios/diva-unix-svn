package factory.causallink;

import eu.diva.runtime.causallink.distribution.osgi.TopologyClientOSGi;
import eu.diva.runtime.distribution.TopologyClient;

public class TopologyClientFactory implements eu.diva.factoryinstdiva.Factory<TopologyClient>{

	private static TopologyClientFactory fact = new TopologyClientFactory();

	public static TopologyClientFactory getFact() {
		return fact;
	}

	public static void setFact(TopologyClientFactory fact) {
		TopologyClientFactory.fact = fact;
	}

	public static TopologyClientOSGi getComponent() {
		return new TopologyClientOSGi();
	}


	public TopologyClient createComponent() {
		return getComponent();

	}	


	public TopologyClient createComponent(String implementingClass) {
		return createComponent();
	}

	public boolean check(String implementingClass) {
		return false;
	}
}

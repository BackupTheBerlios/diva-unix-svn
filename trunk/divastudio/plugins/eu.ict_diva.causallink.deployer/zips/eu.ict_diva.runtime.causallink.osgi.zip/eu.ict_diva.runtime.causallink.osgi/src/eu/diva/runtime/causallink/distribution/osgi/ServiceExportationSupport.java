package eu.diva.runtime.causallink.distribution.osgi;

import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

/**
 * 
 * @author Vincent Girard-Reydet - ThereSIS, Thales Services SA
 */
public class ServiceExportationSupport
{
	public static final String COMPONENT_TYPE_NAME = "componentTypeName";
	public static final String PORT_NAME = "portName";
	public static final String INSTANCE_NAME = "instanceName";
	
	private BundleContext ctx;
	private Object cpt;
	private Map<String,ServiceRegistration> registrations = new HashMap<String,ServiceRegistration>();
	
	public ServiceExportationSupport( BundleContext context, Object component )
	{
		ctx = context;
		cpt = component;
	}
	
	public void exportService( String serviceName, Dictionary properties )
	{
		if( registrations.get(serviceName) != null )
			System.err.println("Service already registered: " + serviceName);
		else
		{
			registrations.put( serviceName, ctx.registerService(serviceName, cpt, properties));
		}
	}
	
	public void unexportService( String serviceName )
	{

		ServiceRegistration reg = registrations.remove(serviceName);
		if( reg == null )
			System.err.println("Service not registered: " + serviceName);
		else
			reg.unregister();
	}
}

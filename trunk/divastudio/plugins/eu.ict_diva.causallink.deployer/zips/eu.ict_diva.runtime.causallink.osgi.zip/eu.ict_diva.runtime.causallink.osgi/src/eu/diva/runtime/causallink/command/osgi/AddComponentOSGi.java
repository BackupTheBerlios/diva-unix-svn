package eu.diva.runtime.causallink.command.osgi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Dictionary;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.kermeta.osgi.factory.instance.service.GenerateInstanceService;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventAdmin;

import art.implem.OSGiComponent;
import art.implem.OSGiType;
import art.instance.ComponentInstance;
import art.type.AbstractPort;
import eu.diva.osgi.component.DiVAComponent;
import eu.diva.runtime.causallink.distribution.osgi.ServiceExportationSupport;
import eu.diva.runtime.causallink.osgi.Helper;
import eu.diva.runtime.command.AddComponent;

public class AddComponentOSGi extends AddComponent implements OSGiCommand{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7502659272996551174L;

	private static Logger logger = Logger.getLogger(AddComponentOSGi.class.getName());
	
	private static EventAdmin eventAdmin;
	private static GenerateInstanceService gis;
	private static BundleContext context;
	private static int period = 500;
	
	private transient Map<Bundle, ComponentInstance> map;
	private transient Map<DiVAComponent, ComponentInstance> map2;
	private transient Event e;
	private transient Event error;
	
	private String rootTopic;
	
	public AddComponentOSGi(AddComponent reference) {
		super();
		this.cpt = reference.getCpt();
		this.nodeName = reference.getNodeName();
		this.nodeUri = reference.getNodeUri();
		this.nodeId = reference.getNodeId();
	}
	
	public void setMap(Map<Bundle, ComponentInstance> map) {
		this.map = map;
	}

	public void setMap2(Map<DiVAComponent, ComponentInstance> map2) {
		this.map2 = map2;
	}

	public static void setEventAdmin(EventAdmin eventAdmin) {
		AddComponentOSGi.eventAdmin = eventAdmin;
	}


	public static void setGis(GenerateInstanceService gis) {
		AddComponentOSGi.gis = gis;
	}


	public static void setContext(BundleContext context) {
		AddComponentOSGi.context = context;
	}

	public void setRootTopic(String rootTopic) {
		this.rootTopic = rootTopic;
	}


	@Override
	public void setTopic(String topic) {
		rootTopic = topic;
	
	}

	@Override
	public void setHelper(Helper helper) {
		//this.helper = helper;
	}

	public int getAckPeriod(){
		return period;
	}


	public boolean check() {
		return cpt != null && map != null && gis != null && context != null && map2 != null /*&& qNames != null*/;
	}


	public boolean execute() {

		//TODO: Check (gis, EventAdmin, Context, runtime2model ) != null

		//int index = cpt.getType().getName().lastIndexOf(".");
		String name = cpt.getType().getName();//.substring(index+1, cpt.getType().getName().length());

		Dictionary<Object,Object> props = new Properties();
		props.put("component", cpt);
		props.put("command", this);
		//System.out.println("  "+rootTopic+"/addComponent/ok/"+cpt.getName());
		e = new Event(rootTopic+"/addComponent/ok/"+cpt.getName(), props);

		try {
			ServiceReference[] refs = context.getServiceReferences(
					eu.diva.factoryinstdiva.Factory.class.getName(), "(Factory="+cpt.getType().getName()+")");

			if(refs == null || refs.length == 0) {
				throw new AddComponentOSGiException("Factory not found for component: " + cpt.getType().getName());
			}
			else{
				if(cpt.getType().getImplem() == null || ((OSGiType)cpt.getType().getImplem()).getGenerateInstanceBundle()){
					logger.debug("Creating a component with an associated OSGi bundle");
					
					if(cpt.getImplem() == null) {
						throw new AddComponentOSGiException("Instance:" + cpt.getName() + " of component " + cpt.getType().getName() + " must have an implementation class specified in model.");
					}
					
					logger.trace("generateInstanceBundle("+cpt.getName()+", "+((OSGiComponent)cpt.getImplem()).getImplementingClass()+", "+name+", "+cpt.getType().getName()+");");
					List<String> services = new ArrayList<String>();
					for(AbstractPort port: cpt.getType().getPort() ) {
						if( "server".equals(port.getRole()))
							services.add(port.getService().getName());
					}
					Properties properties = new Properties();
					properties.put(GenerateInstanceService.INSTANCE_NAME, cpt.getName());
					properties.put(GenerateInstanceService.COMPONENT_TYPE_CLASS, ((OSGiComponent)cpt.getImplem()).getImplementingClass());
					properties.put(GenerateInstanceService.COMPONENT_TYPE_NAME, name);
					properties.put(GenerateInstanceService.BUNDLE_SYMBOLIC_NAME, cpt.getType().getName());
					properties.put(GenerateInstanceService.NODE_ID, nodeName);
					properties.put(GenerateInstanceService.SERVICE_INTERFACES, services.toArray(new String[0]));
					long id = gis.generateInstanceBundle(
							properties,
							true);

					Bundle b = context.getBundle(id);
					map.put(b, cpt);
					b.start();

					ServiceReference[] bundleRefs = b.getRegisteredServices();
					if( null == bundleRefs || bundleRefs.length == 0 )
						throw new AddComponentOSGiException("Service exportation support not found for component: " + cpt.getType().getName());
					ServiceExportationSupport ses = null;
					for( ServiceReference ref: bundleRefs )
					{
						final List<String> clazz = Arrays.asList((String[])ref.getProperty("objectClass"));
						if( clazz.contains(ServiceExportationSupport.class.getName()))
						{
							ses = (ServiceExportationSupport)context.getService(ref);
							
							for(AbstractPort p : cpt.getType().getPort()){
								if (p.getRole().equals("server")) {
									registerService(p, ses);
								}
							}
						}
					}
					eventAdmin.postEvent(e);
					return true;

				} else {
					logger.debug("Creating a component with NO associated OSGi bundle");

					ServiceReference ref = refs[0];
					eu.diva.factoryinstdiva.Factory<?> fact = (eu.diva.factoryinstdiva.Factory<?>) context.getService(ref);
					//cpt = ($ComponentTypeJavaClass$) fact.createComponent("$ComponentTypeJavaClass$");
					DiVAComponent divaCpt = (DiVAComponent) fact.createComponent(((OSGiComponent)cpt.getImplem()).getImplementingClass());
					divaCpt.setInstanceName(cpt.getName());
					map2.put(divaCpt,cpt);
					eventAdmin.postEvent(e);
					return true;
				}
			}

		} catch (Exception e) {
			error = new Event(rootTopic+"/addComponent/nok/"+cpt.getName(), props);
			eventAdmin.postEvent(error);
			logger.error("Exception", e);
			return false;
		}		
	}


	public boolean executeWithText() {
		return OSGiCommandPrinter.executeWithText(this);
	}

	/*public int getPriority(){
		return 4;
	}*/

	private class AddComponentOSGiException extends Exception{

		private static final long serialVersionUID = 7732923461132713913L;

		public AddComponentOSGiException(String string) {
			super(string);
		}
		
	}

	private void registerService( AbstractPort port, ServiceExportationSupport ses )
	{
		final Properties properties = new Properties();
		String protocol = port.getProtocol();
		String uri = port.getUri();
		if(uri!=null && protocol!=null &&!protocol.isEmpty())
		{
			// TODO: use a service instead, to let the user customize service exportation
			//       this service should be configurable as is done in Camel: the protocol
			//       is a selector for a factory of configuration
			// ex: myService.configure(port, properties) ==> appends correct config properties
			//     we can ship a default conf service that will configure CXF
			final StringBuilder b = new StringBuilder();
			b.append( nodeUri ).append('/');
			if( uri.isEmpty() )
				b.append(cpt.getType().getName())
				 .append('/').append(cpt.getName())
				 .append('/').append(port.getName());
			else
				b.append(port.getUri());			
			properties.put("service.exported.configs", "org.apache.cxf.ws");			
			properties.put("org.apache.cxf.ws.address", b.toString());			
			// CXF has a bug for now and supports only "*" filter
			//properties.put("service.exported.interfaces", port.getService().getName());
			properties.put("service.exported.interfaces", "*");
		}
		properties.put("nodeId", nodeName);
		properties.put("InstanceName", cpt.getName());
		properties.put("PortName", port.getName());
		ses.exportService(port.getService().getName(), properties);
	}
}

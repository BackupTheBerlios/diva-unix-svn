package factory.causallink;

import eu.diva.runtime.causallink.osgi.OSGiCommandProcessor;
import eu.diva.runtime.command.CommandProcessor;

public class CommandProcessorFactory 
	implements eu.diva.factoryinstdiva.Factory<CommandProcessor>
{

	private static CommandProcessorFactory fact = new CommandProcessorFactory();

	public static CommandProcessorFactory getFact() {
		return fact;
	}

	public static void setFact(CommandProcessorFactory fact) {
		CommandProcessorFactory.fact = fact;
	}

	public static CommandProcessor getComponent() {
		return new OSGiCommandProcessor();
	}


	public CommandProcessor createComponent() {
		return getComponent();

	}	

	public CommandProcessor createComponent(String implementingClass) {
		return createComponent();
	}

	public boolean check(String implementingClass) {
		return false;
	}
}

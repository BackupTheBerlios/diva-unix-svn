package eu.diva.runtime.causallink.osgi;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Dictionary;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventAdmin;

import art.instance.TransmissionBinding;
import eu.diva.runtime.command.PlatformCommand;

public class BindingMethod{

	private static Logger logger = Logger.getLogger(BindingMethod.class.getName());

	private static EventAdmin eventAdmin;

	private Object[] params;
	private Method bindingMethod;
	private Object client;
	private TransmissionBinding b;
	private int serverIndex;

	private Event e;
	private Event error;

	public static void setEventAdmin(EventAdmin eventAdmin){
		BindingMethod.eventAdmin = eventAdmin;
	}

	/**
	 * Invokes the binding method.
	 */
	public void invoke(){

		//TODO: Check EventAdmin != null

		try {

			logger.debug("Invoke: " + client + "." + bindingMethod.getName() + "(" + Arrays.toString(params) + ")");

			bindingMethod.invoke(client, params);
			eventAdmin.postEvent(e);
			//System.err.println(e);
		} catch (IllegalArgumentException e) {
			eventAdmin.postEvent(error);
			logger.error("invoke::IllegalArgumentException", e);
		} catch (IllegalAccessException e) {
			eventAdmin.postEvent(error);
			logger.error("invoke::IllegalAccessException", e);
		} catch (InvocationTargetException e) {
			eventAdmin.postEvent(error);
			logger.error("invoke::InvocationTargetException", e);
		}
	}

	/**
	 * Determine the binding method (setter) to call
	 * @param name: name of the setter
	 * @param client: the client object that should containing the setter. Cannot be null.
	 * @param server: the server object ie, the parameter of the setter. Could be null. 
	 * @param isCollection: tells if the setter sets a collection or a single reference.
	 * @param toUnset: tells if we call the setter to unset a reference (null or remove from collection) 
	 * @param id: cannot be null if isCollection. Allows to add a reference using id as index 
	 * @param b: the binding (from the ART metamodel) that corresponds to the binding method
	 * @param cmd
	 * @param rootTopic
	 * @throws Exception
	 */
	public BindingMethod(String name, Object client, Object server, boolean isCollection, boolean toUnset, String id, TransmissionBinding b, PlatformCommand cmd, String rootTopic) throws Exception{
		//System.out.println("BindingMethod "+name+", "+isCollection+", "+toUnset);
		this.b = b;
		//System.out.println("b=" + b);
		this.client = client;


		logger.debug("Name:"  + name + " client:"  +  client+ " server:"  +  server+ " isCollection:"  + isCollection+ " toUnset:"  +  toUnset+ " id:"  +  id + " TransmissionBinding:"  +  b + " PlatformCommand:"  +  cmd+ " rootTopic:"  +  rootTopic);

		Class<?> cl = client.getClass();
		String opName = setParams(toUnset, isCollection, name, id, server);

		findBindingMethod(cl, opName, toUnset, isCollection);

		if(bindingMethod == null) {
			throw new Exception ("Binding method not found: " + client.getClass().getName() + "::" + opName + "(" + Arrays.toString(params) + ")");
		}

		//updateParams(toUnset, isCollection);

		prepareNotification(toUnset, cmd, rootTopic);
	}

	private void prepareNotification(boolean toUnset, PlatformCommand cmd, String rootTopic){
		String root;
		if (toUnset){
			root = "unbinding";
		}
		else {
			root = "binding";
		}
		Dictionary<Object,Object> props = new Properties();
		props.put("command", cmd);
		if(b != null){
			props.put("binding", b);
			//System.out.println("BindingMethod.topic = "+rootTopic+"/"+root+"/ok/"+bindingMethod.getName()+"("+params.length+" parameters)");
			e = new Event(rootTopic+"/"+root+"/ok/"+bindingMethod.getName(), props);
			error = new Event(rootTopic+"/"+root+"/nok/"+bindingMethod.getName(), props);
		}
		else{
			e = new Event(rootTopic+"/setAttribute/ok"+bindingMethod.getName(), props);
			error = new Event(rootTopic+"/setAttribute/nok"+bindingMethod.getName(), props);
		}		
	}

	/*
	 * This method update the params
	 * if the server does not implement the interface
	 */
	private void updateParams(Method bm){
		if(serverIndex != -1){
			Class<?>[] parameterType = new Class<?>[1];
			parameterType[0] = String.class;

			Object[] idParam = new Object[1];
			idParam[0] = b.getServer().getName();

			Object o = params[serverIndex];
			StringBuffer sb = new StringBuffer();
			sb.append("bm=" + bm + "\n");
			sb.append("bm.getParameters=" + Arrays.toString(bm.getParameterTypes()) + "\n");
			sb.append("bm.getParameterTypes()[index].isInstance(o)=" + bm.getParameterTypes()[serverIndex].isInstance(o) + "\n");
			logger.debug(sb.toString());
						
			
			if (!bm.getParameterTypes()[serverIndex].isInstance(o)){
				try {
					Method getter = o.getClass().getMethod("getPortById", parameterType);
					logger.debug("idParam:" + idParam[0]);
					params[serverIndex] = getter.invoke(o, idParam);
				} catch (SecurityException e) {
					logger.error("updateParams::SecurityException", e);
				} catch (NoSuchMethodException e) {
					logger.error("updateParams::NoSuchMethodException", e);
				} catch (IllegalArgumentException e) {
					logger.error("updateParams::IllegalArgumentException", e);
				} catch (IllegalAccessException e) {
					logger.error("updateParams::IllegalAccessException", e);
				} catch (InvocationTargetException e) {
					logger.error("updateParams::InvocationTargetException", e);
				}
			}
		}		
	}

	private String setParams(boolean toUnset, boolean isCollection, String name, String id, Object server){
		serverIndex = -1;
		String opName;
		//Object[] params = null;
		if (toUnset || !isCollection){
			params = new Object[1];
		}
		else{
			params = new Object[2];
		}

		//set(null)
		if (toUnset && !isCollection){
			params[0] = null;
			opName = "set"+(name.substring(0, 1).toUpperCase()+name.substring(1));
		}
		//unset(id)
		else if (toUnset){
			params[0] = id;
			opName = "unset"+(name.substring(0, 1).toUpperCase()+name.substring(1));
		}
		//set(server)
		else if (!toUnset && !isCollection){
			params[0] = server;
			serverIndex = 0;
			opName = "set"+(name.substring(0, 1).toUpperCase()+name.substring(1));
		}
		//set(server,id)
		else{
			params[0] = id;
			params[1] = server;
			serverIndex = 1;
			opName = "set"+(name.substring(0, 1).toUpperCase()+name.substring(1));
		}

		return opName;
	}

	private void findBindingMethod(Class<?> cl, String opName, boolean toUnset, boolean isCollection){
		/**
		 * Looking for the right binding/setter method
		 */
		for (Method m : cl.getMethods()){
			logger.debug("findBindingMethod: " + opName + " <=> " + m.getName());
			if (m.getName().equals(opName)){
				if (m.getParameterTypes().length == params.length){
					Object[] tempParams = new Object[params.length];
					for(int i = 0; i < params.length; i++){
						tempParams[i] = params[i];
					}
					if(b != null) { //Attributes case
						updateParams(m);			
					}
					boolean checkTypeOfParams = true;
					for(int i = 0; i < params.length; i++){
						Class<?> type = m.getParameterTypes()[i];
						Object param = params[i];
						checkTypeOfParams = checkTypeOfParams && (type.isInstance(param) || param==null);
					}
					if (checkTypeOfParams){
						bindingMethod = m;
						break;
					}
					else{
						params = tempParams;
					}
				}
			}
		}		
	}
}

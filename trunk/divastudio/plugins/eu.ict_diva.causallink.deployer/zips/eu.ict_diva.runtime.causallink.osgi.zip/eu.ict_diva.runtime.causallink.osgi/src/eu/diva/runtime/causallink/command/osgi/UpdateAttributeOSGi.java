package eu.diva.runtime.causallink.command.osgi;


import java.awt.Color;
import java.util.Dictionary;
import java.util.Properties;

import art.DataType;
import art.instance.ComponentInstance;
import art.instance.DefaultEntry;
import art.instance.DictionaryValuedAttribute;
import art.instance.Entry;
import art.instance.OtherEntry;
import art.instance.ValuedAttribute;
import eu.diva.runtime.causallink.osgi.BindingMethod;
import eu.diva.runtime.causallink.osgi.Helper;
import eu.diva.runtime.command.UpdateAttribute;

public class UpdateAttributeOSGi extends UpdateAttribute implements OSGiCommand{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5939967403597575685L;
	private String rootTopic;
	private transient Helper helper;

	public UpdateAttributeOSGi( UpdateAttribute reference ) {
		super();
		this.va = reference.getVa();
		this.nodeId = reference.getNodeId();
	}
	
	public void setRootTopic(String rootTopic) {
		this.rootTopic = rootTopic;
	}

	public int getAckPeriod(){
		return 10;
	}

	public boolean check() {
		return va != null;
	}


	public boolean execute() {
		Object componentToSet = helper.getComponent((ComponentInstance)va.eContainer());

		if(componentToSet != null){
			if(va instanceof ValuedAttribute){
				return setBasicAttribute((ValuedAttribute)va, componentToSet);
			}
			else if(va instanceof DictionaryValuedAttribute){
				return setDictionary((DictionaryValuedAttribute)va, componentToSet);
			}
		}
		
		return true;
	}


	public boolean executeWithText() {
		return OSGiCommandPrinter.executeWithText(this);
	}

	/*public int getPriority(){
		return 3;
	}*/
	
	@Override
	public void setTopic(String topic) {
		rootTopic = topic;
	
	}

	@Override
	public void setHelper(Helper helper) {
		this.helper = helper;		
	}

	private Object getValue(String value, String type){
		if(type.equals("String")){
			return value;
		}
		else if(type.equals("Integer") || type.equals("int")){
			return Integer.parseInt(value);
		}
		else if(type.equals("Boolean") || type.equals("boolean")){
			return Boolean.parseBoolean(value);
		}
		else if(type.equals("Short") || type.equals("short")){
			return Short.parseShort(value);
		}
		else if(type.equals("Long") || type.equals("long")){
			return Long.parseLong(value);
		}
		else if(type.equals("Double") || type.equals("double")){
			return Double.parseDouble(value);
		}
		else if(type.equals("Float") || type.equals("float")){
			return Float.parseFloat(value);
		}
		else if(type.equals("Character") || type.equals("char")){
			return value.charAt(0);
		}
		else if(type.equals("Byte") || type.equals("byte")){
			return Byte.parseByte(value);
		}
		else if(type.equals("Color")){
			String[] colors = value.split(",");
			return new Color(Integer.parseInt(colors[0].trim()), Integer.parseInt(colors[1].trim()), Integer.parseInt(colors[2].trim()));
		}
		return null;
	}

	private void invokeBindingMethod(Object value, String name, Object componentToSet){
		boolean isCollection = false;
		String id = null;

		try {
			BindingMethod bMethod = new BindingMethod(name, componentToSet, value, isCollection, false, id, null, this, rootTopic);
			bMethod.invoke();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private boolean setDictionary(DictionaryValuedAttribute va,
			Object componentToSet) {
		Dictionary<Object, Object> value = createDictionary(va.getAttribute().getType(), va.getAttribute().getValueType());
		for(Entry entry :va.getEntries()){
			String key = null;
			if(entry instanceof DefaultEntry){
				key = ((DefaultEntry)entry).getKey().getKey();
			}
			else if(entry instanceof OtherEntry){
				key = ((OtherEntry)entry).getKey();
			}
			value.put(key, entry.getValue());
		}
		try{
			invokeBindingMethod(value, va.getAttribute().getName(), componentToSet);
			return true;
		}
		catch (Exception e){
			return false;
		}
	}

	private Dictionary<Object, Object> createDictionary(DataType type,
			DataType valueType) {
		return new Properties();
	}

	private boolean setBasicAttribute(ValuedAttribute va, Object componentToSet) {
		Object value = getValue(va.getValue(), va.getAttribute().getType().getName());
		try {
			invokeBindingMethod(value, va.getAttribute().getName(), componentToSet);
			return true;
		} catch (Exception e){
			return false;
		}
	}

}
package eu.diva.runtime.causallink.command.osgi;

import art.distrib.Node;
import art.instance.AttributeInstance;
import art.instance.Binding;
import art.instance.ComponentInstance;
import eu.diva.runtime.command.AddBinding;
import eu.diva.runtime.command.AddComponent;
import eu.diva.runtime.command.AddNode;
import eu.diva.runtime.command.CommandFactory;
import eu.diva.runtime.command.RemoveBinding;
import eu.diva.runtime.command.RemoveComponent;
import eu.diva.runtime.command.RemoveNode;
import eu.diva.runtime.command.StartComponent;
import eu.diva.runtime.command.StopComponent;
import eu.diva.runtime.command.UpdateAttribute;

public class FakeCommandFactory implements CommandFactory {
	
	@Override
	public AddBinding createAddBinding(Binding b) {
		return null;
	}

	@Override
	public AddComponent createAddComponent(ComponentInstance cpt) {
		return null;
	}

	@Override
	public RemoveBinding createRemoveBinding(Binding b) {
		return null;
	}

	@Override
	public RemoveComponent createRemoveComponent(ComponentInstance cpt) {
		return null;
	}

	@Override
	public StartComponent createStartComponent(ComponentInstance cpt) {
		return null;
	}

	@Override
	public StopComponent createStopComponent(ComponentInstance cpt) {
		return null;
	}

	@Override
	public UpdateAttribute createUpdateAttribute(AttributeInstance att) {
		return null;
	}

	@Override
	public AddNode createAddNode(Node n) {
		return null;
	}

	@Override
	public RemoveNode createRemoveNode(Node n) {
		return null;
	}

}

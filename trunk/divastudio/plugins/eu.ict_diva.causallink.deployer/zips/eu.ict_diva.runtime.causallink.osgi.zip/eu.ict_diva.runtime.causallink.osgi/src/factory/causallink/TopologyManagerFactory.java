package factory.causallink;

import eu.diva.runtime.causallink.distribution.osgi.TopologyManagerOSGi;
import eu.diva.runtime.distribution.TopologyManager;

public class TopologyManagerFactory implements eu.diva.factoryinstdiva.Factory<TopologyManager>{

	private static TopologyManagerFactory fact = new TopologyManagerFactory();

	public static TopologyManagerFactory getFact() {
		return fact;
	}

	public static void setFact(TopologyManagerFactory fact) {
		TopologyManagerFactory.fact = fact;
	}

	public static TopologyManagerOSGi getComponent() {
		return new TopologyManagerOSGi();
	}


	public TopologyManager createComponent() {
		return getComponent();

	}	


	public TopologyManager createComponent(String implementingClass) {
		return createComponent();
	}

	public boolean check(String implementingClass) {
		return false;
	}
}

package eu.diva.runtime.causallink.command.osgi;

import eu.diva.runtime.command.RemoveBinding;

public class NullRemoveBindingOSGi extends RemoveBindingOSGi {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6865533984006149367L;

	public NullRemoveBindingOSGi( RemoveBinding reference ) {
		super(reference);
	}
	
	@Override
	public boolean check() {
		return true;
	}

	@Override
	public boolean execute() {
		return true;
	}

	@Override
	public boolean executeWithText() {
		return true;
	}

}

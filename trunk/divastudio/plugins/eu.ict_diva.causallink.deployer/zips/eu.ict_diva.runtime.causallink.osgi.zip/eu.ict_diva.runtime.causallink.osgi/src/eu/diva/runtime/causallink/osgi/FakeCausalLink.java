package eu.diva.runtime.causallink.osgi;

import java.util.List;

import org.apache.log4j.Logger;
import org.osgi.framework.BundleContext;

import art.ArtFactory;
import art.impl.ArtFactoryImpl;
import eu.diva.divastudio.services.runtime.CausalLink;
import eu.diva.divastudio.services.runtime.IChecker;
import eu.diva.osgi.component.DiVAComponentOSGi;
import eu.diva.runtime.causallink.ConfigurationComparator;
import eu.diva.runtime.causallink.command.osgi.FakeCommandFactory;

/**
 * Fake causal link. It does not reconfigure any system.
 * It mainly serves to test the model comparison.
 * @author bmorin
 *
 */
public class FakeCausalLink implements DiVAComponentOSGi, CausalLink {

	private static Logger logger = Logger.getLogger(FakeCausalLink.class.getName());
	
	private String instanceName;

	//Causally connected models
	private art.System system; //the reference model
	private art.System updateModel;//a new model to switch to

	private IChecker checker;
	private ConfigurationComparator comparator;

	public FakeCausalLink() {
		comparator = new ConfigurationComparator();
		
		FakeCommandFactory cmdFactory = new FakeCommandFactory();
		comparator.setCommandFactory(cmdFactory);
		
		ArtFactory emfRuntimeFactory = new ArtFactoryImpl();

		system = emfRuntimeFactory.createSystem();

		/*CompositeInstance root = emfInstanceFactory.createCompositeInstance();
		ComponentType rootType = emfTypeFactory.createCompositeType();

		system.setRoot(root);
		root.setType(rootType);*/
	}

	public void setChecker(IChecker checker){
		this.checker = checker;
	}

	//private ServiceRegistration eventListenerReg;

	public void start() {
	}


	public void stop() {
	}

	public void initSystem() {
	}

	public void loadUpdateModel(art.System updateModel){
		logger.info("CausallinkOSGi::Loading an update model by passing the root model element itself: "+updateModel);
		this.updateModel = updateModel;
	}

	public void loadUpdateModel(String modelURI) throws Exception {
		this.updateModel = Helper.loadUpdateModel(modelURI);
	}

	/**
	 * Reconfigure the running system with the updateModel
	 */
	public int reconfigure(){
		if (checker.check(updateModel)){
			logger.info("CausallinkOSGi::Update model is valid");
			comparator.matchSystems(system, updateModel);
			/*
			 * Since there is no real reconfiguration,
			 * we assume that the reconfiguration is 
			 * successfull, ie:
			 */
			system = updateModel;
		}
		else{
			logger.warn("CausallinkOSGi::Update model is not valid");
		}
		return 1;
	}

	/**
	 * Loads a modified runtime model, analyzes this model and 
	 * modifies the platform
	 * @param updateModelPath: path of a modified runtime model
	 */

	public int  reconfigureByModelURI(String modelURI) {
		try {

			loadUpdateModel(modelURI);
			return reconfigure();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -4;
		}

	}

	@Override
	public String getInstanceName() {
		return instanceName;
	}


	@Override
	public void setInstanceName(String name) {
		this.instanceName = name;
	}

	private BundleContext context;
	
	@Override
	public BundleContext getContext() {
		return context;
	}

	@Override
	public void setContext(BundleContext context) {
		this.context = context;
	}

	@Override
	public List<String> getGroup(String qName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveModel(String modelURI) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int reconfigureInMemory(art.System system) {
		// TODO Auto-generated method stub
		return 0;
	}
}

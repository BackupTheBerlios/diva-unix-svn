package eu.diva.runtime.causallink.distribution.osgi;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Arrays;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleEvent;
import org.osgi.framework.BundleListener;
import org.osgi.framework.Constants;

import eu.diva.osgi.component.DiVAComponentOSGi;
import eu.diva.runtime.command.CommandProcessor;
import eu.diva.runtime.command.PlatformCommand;
import eu.diva.runtime.distribution.TopologyClient;
import eu.diva.runtime.distribution.TopologyManager;

/**
 * 
 * @author Vincent Girard-Reydet - ThereSIS, Thales Services SA
 *
 */
public class TopologyClientOSGi implements BundleListener, TopologyClient, DiVAComponentOSGi
{
	private final Logger logger = Logger.getLogger(TopologyClientOSGi.class);
	private CommandProcessor processor;
	// TODO - service tracking
	private TopologyManager manager;
	private BundleContext context;
	private Object instanceName;
	
	// Called by the topology manager to execute commands on this node
	public boolean sendCommand(PlatformCommand command)
	{
		try
		{
			CommandProcessor.ExecutionResult result =
				processor.executeCommands(Arrays.asList(command));
			return result.nbOkCommands == 1;
		}
		catch( Throwable t )
		{
			// Need to catch everything as the service does not export any exception
			logger.error("Error processing command " + command, t);
			return false;
		}
	}

	@Override
	public boolean execute(byte[] serializedCommand) {
		ByteArrayInputStream stream = new ByteArrayInputStream(serializedCommand);
		ObjectInputStream oi;
		try {
			oi = new ObjectInputStream(stream);
			PlatformCommand command = (PlatformCommand) oi.readObject();
			CommandProcessor.ExecutionResult result =
				processor.executeCommands(Arrays.asList(command));
			return result.nbOkCommands == 1;
		} catch (IOException e) {
			logger.error("Error opening input steam", e);
		} catch (ClassNotFoundException e) {
			logger.error("Error reading command", e);
		}
		catch( Throwable t )
		{
			// Need to catch everything as the service does not export any exception
			logger.error("Error processing command", t);
		}
		return false;
	}
	
	public void setProcessor(CommandProcessor processor) {
		this.processor = processor;
	}
	
	//
	// BundleListener interface
	//
	/**
	 * Observes the lifecycle events provided by the OSGi platform
	 * This allows to notify the manager of unexpected as well as expected platform events
	 * so that the model is kept synchronized.
	 */
	public void bundleChanged(BundleEvent event)
	{
		// TODO: instead of sending every event immediately,
		//       we could store the events and send them only on request,
		// This removes the back dependency on manager but reduces the responsiveness
		// of the system model updates.
		Bundle b = event.getBundle();

		if(!"diva.instance.Activator".equals(b.getHeaders().get(Constants.BUNDLE_ACTIVATOR)))
			return;
		Object raw = b.getHeaders().get("diva.qualifiedName");
		if( null == raw )
			return;
		final String qName = (String)raw;
		Properties props = new Properties();
		props.put(eu.diva.runtime.distribution.Constants.QUALIFIED_NAME,qName);
		if (event.getType()==BundleEvent.UNINSTALLED)
		{
			manager.notifyEvent(eu.diva.runtime.distribution.Constants.COMPONENT_REMOVED, props);
		}
		else if (event.getType()==BundleEvent.INSTALLED) {
			manager.notifyEvent(eu.diva.runtime.distribution.Constants.COMPONENT_ADDED, props);
		}
		else if (event.getType()==BundleEvent.STOPPED){
			manager.notifyEvent(eu.diva.runtime.distribution.Constants.COMPONENT_STOP, props);
		}
		else if (event.getType()==BundleEvent.STARTED){
			manager.notifyEvent(eu.diva.runtime.distribution.Constants.COMPONENT_START, props);
		}
	}

	@Override
	public BundleContext getContext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setContext(BundleContext context) {
		this.context = context;
	}

	@Override
	public String getInstanceName() {
		return null;
	}

	@Override
	public void setInstanceName(String name) {
		this.instanceName = name;
	}

	@Override
	public void start() {
		/*Properties props = new Properties();
		props.put("service.exported.interfaces", TopologyClient.class.getName());
		props.put("service.exported.configs", "org.apache.cxf.ws");
		props.put("nodeId", instanceName);
		context.registerService(TopologyManager.class.getName(), this, props);*/
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		
	}

}

package eu.diva.runtime.causallink.osgi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.kermeta.osgi.factory.instance.service.GenerateInstanceService;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleEvent;
import org.osgi.framework.Constants;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceEvent;
import org.osgi.framework.ServiceListener;
import org.osgi.framework.ServiceReference;
import org.osgi.framework.ServiceRegistration;

import art.instance.ComponentInstance;
import eu.diva.osgi.component.DiVAComponent;
import eu.diva.osgi.component.DiVAComponentOSGi;
import eu.diva.runtime.causallink.command.osgi.AddBindingOSGi;
import eu.diva.runtime.causallink.command.osgi.AddComponentOSGi;
import eu.diva.runtime.causallink.command.osgi.OSGiCommand;
import eu.diva.runtime.causallink.command.osgi.OSGiCommandFactory;
import eu.diva.runtime.command.CommandProcessor;
import eu.diva.runtime.command.PlatformCommand;

/**
 * OSGi implementation of the DiVA {@linkplain CommandProcessor} interface.
 * 
 * @author Vincent Girard-Reydet - Thales Services SA, ThereSIS
 * @author Brice Morin - IRISA Rennes / Equipe-Projet INRIA Triskell
 */
public class OSGiCommandProcessor implements DiVAComponentOSGi, CommandProcessor
{
	private static Logger logger = Logger.getLogger(OSGiCommandProcessor.class.getName());

	private String instanceName;
	private BundleContext context;
	
	private Map<Bundle, ComponentInstance> runtime2model;
	private Map<DiVAComponent, ComponentInstance> runtimeObject2model;
	private OSGiCommandFactory factory; // for commands configuration

	private GenerateInstanceService gis;
	private List<ServiceRegistration> regs;
	private Helper helper;

	public OSGiCommandProcessor() {
		helper = new Helper();
		regs = new ArrayList<ServiceRegistration>();
		runtime2model = Collections.synchronizedMap(new Hashtable<Bundle, ComponentInstance>());
		runtimeObject2model = Collections.synchronizedMap(new Hashtable<DiVAComponent, ComponentInstance>());
		factory = new OSGiCommandFactory();
		factory.setMap(runtime2model);
		factory.setMap2(runtimeObject2model);
	}

	//
	// CommandProcessor interface
	//
	
	@Override
	public ExecutionResult executeCommands(List<PlatformCommand> commands) {
		ExecutionResult result = new ExecutionResult();
		if(!checkServices()) {
			result.indexKoCommand = 0;
			logger.error("OSGiCommandProcessor::All services needed not present. Reconf aborted.");
		} else {
			logger.info("Starting Reconfiguration");
			// This will update the static references in the commands
			// received from network
			updateReferences();
			int i = 0;
			for(PlatformCommand command : commands) {
				OSGiCommand cmd = factory.createFromReference(command);
				cmd.setTopic(instanceName);
				cmd.setHelper(helper);

				if(cmd.executeWithText())
				{
					result.nbOkCommands++;
					i++;
					// This assumes that the client will perform the command acknowledgement
					// The client has to implement strategies to check that everything went correctly
				}
				else 
				{
					result.indexKoCommand = i;
					break;
				}
			}
		}

		generateReport(commands, result);

		logger.info("Reconfiguration done.");
		return result;
	}
	
	/**
	 * 
	 * @return the set of POJO components managed by this causal link
	 */
	public Set<DiVAComponent> getPOJOs() {
		return runtimeObject2model.keySet();
	}
	
	//
	// DiVAComponentOSGi interface
	//
	
	@Override
	public void start() {
		logger.info("Starting CommandProcessor[name:" + instanceName + "]");

		if(!instanceName.equals("root")){
			regs.add(context.registerService(CommandProcessor.class.getName(), this, null));
		}
		Helper.setContext(context);
		helper.setMap2(runtimeObject2model);

		getInstanceGenerator();
		updateReferences();
	}

	@Override
	public void stop() {
		for( ServiceRegistration reg : regs ){
			reg.unregister();
		}
	}

	@Override
	public BundleContext getContext() {
		return context;
	}

	@Override
	public void setContext(BundleContext context) {
		this.context = context;
	}

	@Override
	public String getInstanceName() {
		return instanceName;
	}

	@Override
	public void setInstanceName(String name) {
		this.instanceName = name;
	}

	//
	// Helpers
	//

	private void getInstanceGenerator() {
		/**
		 * getting the instance generator
		 */
		ServiceReference ref;
		ref = context.getServiceReference(GenerateInstanceService.class.getName());
		if(ref != null){
			gis = (GenerateInstanceService) context.getService(ref);
		}
		else {
			logger.warn("OSGiCommandProcessor::Couldn't find GenerateInstance service.");
		}
	
		/**
		 * Registering service listeners
		 */
	
		try {
			context.addServiceListener(new ServiceListener() {
				public void serviceChanged(ServiceEvent event) {
	
					//gets the service if local attribute is null
					if(OSGiCommandProcessor.this.gis == null && event.getType() == ServiceEvent.REGISTERED) {
	
						OSGiCommandProcessor.this.gis = (GenerateInstanceService)OSGiCommandProcessor.this.context.getService(event.getServiceReference());
						updateReferences();
						logger.info(OSGiCommandProcessor.this.context.getBundle().getSymbolicName() + ":: GenerateInstanceService service registered");
	
						// removes the reference if the service is unregistering
					} else if( OSGiCommandProcessor.this.gis != null && event.getType() == ServiceEvent.UNREGISTERING ){
	
						OSGiCommandProcessor.this.gis = null;
						updateReferences();
						logger.warn(OSGiCommandProcessor.this.context.getBundle().getSymbolicName() + ":: GenerateInstanceService service unregistered");
	
					}
				}
			}, "("+Constants.OBJECTCLASS+"=" + GenerateInstanceService.class.getName() + ")");
	
		} catch (InvalidSyntaxException e) {
			logger.error("InvalidSyntax", e);
		}
	}

	private void updateReferences() {
		AddComponentOSGi.setGis(gis);
		AddComponentOSGi.setContext(context);
		AddBindingOSGi.setContext(context);
	}

	private void generateReport(List<PlatformCommand> commands, ExecutionResult result) {
		logger.info("Reconfiguration Report");

		if (result.indexKoCommand == -1){
			logger.info("No command in error");
		} else {
			logger.warn("A command is in error: "+commands.get(result.indexKoCommand));
			StringBuffer commandListBuffer = new StringBuffer();
			commandListBuffer.append("The following commands have been ignored\n");
			for(int i = result.indexKoCommand+1; i < commands.size(); ++i) {				
				commandListBuffer.append(commands.get(i).toString() + "\n");
			}
			logger.warn(commandListBuffer.toString());
		}
		logger.info("End of Report");
	}

	private boolean checkServices() {
		return gis != null;
	}

	/**
	 * Observes the lifecycle events provided by the OSGi platform.
	 * This updates the model in case of unexpected events.
	 */
	public void bundleChanged(BundleEvent event) 
	{
		Bundle b = event.getBundle();

		if("diva.instance.Activator".equals(b.getHeaders().get("Bundle-Activator"))){

			if (event.getType()==BundleEvent.UNINSTALLED) {
				synchronized(runtime2model){
					ComponentInstance cpt = runtime2model.get(b);
					if(cpt != null) {
						runtime2model.remove(b);
						// TODO: update model in the causal link (remove component, 
						// remove dangling bindings)
					}
				}
			}
			else if (event.getType()==BundleEvent.STOPPED){
				synchronized(runtime2model){
					ComponentInstance cpt = runtime2model.get(b);
					if(cpt != null) {
						cpt.setState("OFF");
						cpt.getBinding().clear();
						// TODO: update model in the causal link (stop component, clear bindings
						//       and remove dangling bindings)
					}
				}
			}
			else if (event.getType()==BundleEvent.STARTED){
				ComponentInstance cpt = runtime2model.get(b);
				if(cpt!=null){
					cpt.setState("ON");
					// TODO: update model in the causal link
				}
			}
		}
	}

}

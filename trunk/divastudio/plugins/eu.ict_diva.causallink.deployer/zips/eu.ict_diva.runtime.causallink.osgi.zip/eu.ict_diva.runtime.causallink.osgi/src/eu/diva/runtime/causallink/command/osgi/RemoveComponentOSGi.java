package eu.diva.runtime.causallink.command.osgi;

import java.util.Dictionary;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleException;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventAdmin;

import art.implem.OSGiType;
import art.instance.ComponentInstance;
import eu.diva.osgi.component.DiVAComponent;
import eu.diva.runtime.causallink.osgi.Helper;
import eu.diva.runtime.command.RemoveComponent;

public class RemoveComponentOSGi extends RemoveComponent implements OSGiCommand{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3000872312097155665L;
	private static Logger logger = Logger.getLogger(RemoveComponentOSGi.class.getName());
	private static EventAdmin eventAdmin;
	
	private String rootTopic;
	private transient Map<Bundle, ComponentInstance> map;
	private transient Map<DiVAComponent, ComponentInstance> map2;

	public RemoveComponentOSGi( RemoveComponent reference ) {
		super();
		this.cpt = reference.getCpt();
		this.nodeId = reference.getNodeId();
	}

	public void setRootTopic(String rootTopic) {
		this.rootTopic = rootTopic;
	}

	public void setMap(Map<Bundle, ComponentInstance> map) {
		this.map = map;
	}

	public void setMap2(Map<DiVAComponent, ComponentInstance> map2) {
		this.map2 = map2;
	}

	private transient Event e;
	private transient Event error;

	public static void setEventAdmin(EventAdmin eventAdmin){
		RemoveComponentOSGi.eventAdmin = eventAdmin;
	}
	
	public boolean check() {
		return cpt != null && map != null && map2 != null;
	}


	public boolean execute() {



		//TODO: Check (runtime2model, EventAdmin) != null

		Dictionary<Object,Object> props = new Properties();
		props.put("component", cpt);
		props.put("command", this);
		e = new Event(rootTopic+"/removeComponent/ok/"+cpt.getName(), props);		

		if(cpt.getType().getImplem() == null || ((OSGiType)cpt.getType().getImplem()).getGenerateInstanceBundle()){
			logger.debug("Removing a component with an associated OSGi bundle");
			Bundle b = null;
			synchronized(map){
				for(Bundle bund : map.keySet()){
					if(bund.getSymbolicName().equals(cpt.getName())){
						b = (Bundle) bund;
						break;
					}
				}
			}

			/*		ServiceReference[] refs = null;
		try {
			refs = context.getAllServiceReferences(null,
					"(objectClass="+BundleManagement.class.getName()+")");
		} catch (InvalidSyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

		BundleManagement bundleManagement = (BundleManagement)context.getService(refs[0]);
		bundleManagement.uninstall(b.getBundleId());
			 */		
			try {
				if(b != null){
					b.uninstall();
					map.remove(b);
				}
			} catch (BundleException e1) {
				error = new Event(rootTopic+"/removeComponent/nok/"+cpt.getName(), props);
				eventAdmin.postEvent(error);
				logger.error("BundleException", e1);
				return false;
			}

		}

		else{
			//System.out.println("Removing a component with NO associated OSGi bundle");
			//DiVAComponent c = null;
			DiVAComponent divaCpt = null;
			synchronized(map2){
				for(DiVAComponent c2 : map2.keySet()){
					if(c2.getInstanceName().equals(cpt.getName())){
						divaCpt = c2;
						break;
					}
				}
			}
			if(divaCpt != null){
				map2.remove(divaCpt);
			}
		}

		eventAdmin.postEvent(e);
		return true;
	}


	public boolean executeWithText() {
		return OSGiCommandPrinter.executeWithText(this);
	}

	/*public int getPriority(){
		return 5;
	}*/


	@Override
	public void setTopic(String topic) {
		rootTopic = topic;

	}

	@Override
	public void setHelper(Helper helper) {
	}

	@Override
	public int getAckPeriod() {
		return 50;
	}
	
}

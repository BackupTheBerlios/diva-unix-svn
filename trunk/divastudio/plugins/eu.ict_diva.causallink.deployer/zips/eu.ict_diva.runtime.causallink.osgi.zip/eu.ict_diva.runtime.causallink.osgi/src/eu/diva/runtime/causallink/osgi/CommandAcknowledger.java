package eu.diva.runtime.causallink.osgi;

import java.util.Map;

import org.apache.log4j.Logger;

import art.NamedElement;
import art.distrib.Node;
import art.instance.ComponentInstance;
import art.instance.CompositeInstance;
import art.instance.TransmissionBinding;
import art.type.AbstractPort;

import eu.diva.runtime.command.AddBinding;
import eu.diva.runtime.command.AddComponent;
import eu.diva.runtime.command.AddNode;
import eu.diva.runtime.command.PlatformCommand;
import eu.diva.runtime.command.RemoveBinding;
import eu.diva.runtime.command.RemoveComponent;
import eu.diva.runtime.command.RemoveNode;
import eu.diva.runtime.command.StartComponent;
import eu.diva.runtime.command.StopComponent;
import eu.diva.runtime.command.UpdateAttribute;

public class CommandAcknowledger 
{
	private static Logger LOGGER = Logger.getLogger(CommandAcknowledger.class);
	private Map<String,NamedElement> qNames;

	public void setQnames(Map<String,NamedElement> qNames) {
		this.qNames = qNames;
	}
	
	/**
	 * Update the model of the running platform once a command
	 * has been acknowledged.
	 * @param command The acknowledged command to reflect
	 *                in the model
	 */
	public void ackCommand(PlatformCommand command)
	{
		if( command instanceof AddNode )
			ackAddNode((AddNode)command);
		else if( command instanceof AddComponent )
			ackAddComponent((AddComponent)command);
		else if( command instanceof AddBinding )
			ackAddBinding((AddBinding)command);
		else if( command instanceof StartComponent )
			ackStartComponent((StartComponent)command);
		else if( command instanceof UpdateAttribute )
			ackUpdateAttribute((UpdateAttribute)command);
		else if( command instanceof StopComponent )
			ackStopComponent((StopComponent)command);
		else if( command instanceof RemoveBinding )
			ackRemoveBinding((RemoveBinding)command);
		else if( command instanceof RemoveComponent )
			ackRemoveComponent((RemoveComponent)command);
		else if( command instanceof RemoveNode )
			ackRemoveNode((RemoveNode)command);
	}
	
	private void ackAddNode(AddNode cmd)
	{
		qNames.put(cmd.getNode().getName(), cmd.getNode());
	}
	private void ackAddComponent(AddComponent cmd)
	{
		ComponentInstance cpt = cmd.getCpt();
		qNames.put(cpt.getQualifiedName(), cpt);

		CompositeInstance parent = (CompositeInstance)cpt.getSuperComponent();
		if( null != parent )
		{
			parent.getSubComponent().add(cpt);
			return;
		}
		Node container = (Node)qNames.get(cmd.getNodeName());
		if( null == container )
		{
			LOGGER.error("No node " + cmd.getNodeName() + " in model, cannot ack command");
			return;
		}
		container.getComponents().add(cpt);
	}
	private void ackAddBinding(AddBinding cmd)
	{
		TransmissionBinding b = cmd.getB();
		ComponentInstance client = (ComponentInstance)qNames.get(((ComponentInstance)b.eContainer()).getQualifiedName());
		ComponentInstance server = (ComponentInstance)qNames.get(b.getServerInstance().getQualifiedName());
		AbstractPort serverPort = null;
		AbstractPort clientPort = null;
		
		for(AbstractPort p : client.getType().getPort()){
			if("client".equals(p.getRole()) && p.getName().equals(b.getClient().getName())){
				clientPort = p;
				break;
			}
		}
		for(AbstractPort p : server.getType().getPort()){
			if("server".equals(p.getRole()) && p.getName().equals(b.getServer().getName())){
				serverPort = p;
				break;
			}
		}
		b.setClient(clientPort);
		b.setServer(serverPort);
		b.setServerInstance(server);
		client.getBinding().add(b);
	}
	private void ackStartComponent(StartComponent cmd)
	{
		final String cptName = cmd.getCpt().getQualifiedName();
		ComponentInstance c = ((ComponentInstance)qNames.get(cptName));
		if( null == c )
			LOGGER.warn("No component " + cptName + " found in model, cannot ack command");
		else
			c.setState("ON");
	}
	private void ackUpdateAttribute(UpdateAttribute cmd)
	{
		// Nothing to do ?
	}
	private void ackStopComponent(StopComponent cmd)
	{
		final String cptName = cmd.getCpt().getQualifiedName();
		ComponentInstance c = ((ComponentInstance)qNames.get(cptName));
		if( null == c )
			LOGGER.warn("No component " + cptName + " found in model, cannot ack command");
		else
			c.setState("OFF");
	}
	private void ackRemoveNode(RemoveNode cmd)
	{
		qNames.remove(cmd.getNode().getName());
	}
	private void ackRemoveComponent(RemoveComponent cmd)
	{
		ComponentInstance cpt = cmd.getCpt();
		qNames.remove(cpt.getQualifiedName());

		CompositeInstance parent = (CompositeInstance)cpt.getSuperComponent();
		if( null != parent )
		{
			parent.getSubComponent().remove(cpt);
			return;
		}
		Node container = (Node)cpt.eContainer();
		if(container != null){//could have been removed if the event if received before executing the ack
			container.getComponents().remove(cpt);
		}
	}
	private void ackRemoveBinding(RemoveBinding cmd)
	{
		TransmissionBinding b = cmd.getB();
		ComponentInstance client = (ComponentInstance)b.eContainer();
		client.getBinding().remove(b);
	}

}

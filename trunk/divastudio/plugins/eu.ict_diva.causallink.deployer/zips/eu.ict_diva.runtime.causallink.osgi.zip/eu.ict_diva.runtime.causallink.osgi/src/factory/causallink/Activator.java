package factory.causallink;

import java.util.Properties;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

import eu.diva.factoryinstdiva.Factory;

public class Activator implements BundleActivator{

	//public static BundleContext context;
	
	public void start(BundleContext context) {
		//Activator.context = context;
		Properties props = new Properties();
		props.put("Factory", "CausalLink");
		context.registerService(
				Factory.class.getName(), factory.causallink.Factory.getFact(), props);
		props.put("Factory", "CommandProcessor");
		context.registerService(
				Factory.class.getName(), factory.causallink.CommandProcessorFactory.getFact(), props);
		props.put("Factory", "TopologyClient");
		context.registerService(
				Factory.class.getName(), factory.causallink.TopologyClientFactory.getFact(), props);
		props.put("Factory", "TopologyManager");
		context.registerService(
				Factory.class.getName(), factory.causallink.TopologyManagerFactory.getFact(), props);
	}

	
	public void stop(BundleContext context) {

	}

}

package eu.diva.runtime.causallink.command.osgi;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import org.apache.log4j.Logger;

public final class OSGiCommandPrinter {

	private OSGiCommandPrinter(){
		
	}
	
	private static Logger logger = Logger.getLogger(OSGiCommandPrinter.class.getName());
	
	public static boolean executeWithText(OSGiCommand cmd){
		StringBuffer buffer = new StringBuffer();
		buffer.append("-----------------------------");
		buffer.append("\n" + "#>Executing "+cmd.getClass().getSimpleName()+" (priority = "+cmd.getPriority()+") "+cmd);
		buffer.append("\n" + "#>  Parameters of the command:");
		for(Field f : cmd.getClass().getDeclaredFields()){
			if(f.getModifiers() == Modifier.PUBLIC && f.getModifiers() != Modifier.STATIC && f.getModifiers() != Modifier.FINAL){
				String info = null;
				Object get = null;
				try {
					get = f.get(cmd);
					info = get.toString();
				} catch (Exception e) {
					get = null;
					info = "";
				}
				buffer.append("\n" + "#>    -"+f.getName()+" ("+f.getType().getSimpleName()+"): "+info);
			}
		}
		logger.debug(buffer.toString());
		return cmd.execute();
	}
}

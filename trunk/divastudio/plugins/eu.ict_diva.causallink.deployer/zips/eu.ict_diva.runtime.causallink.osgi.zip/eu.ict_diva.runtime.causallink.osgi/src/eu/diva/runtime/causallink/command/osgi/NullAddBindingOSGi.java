package eu.diva.runtime.causallink.command.osgi;

import eu.diva.runtime.command.AddBinding;


public class NullAddBindingOSGi extends AddBindingOSGi{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8428332278379795279L;

	public NullAddBindingOSGi( AddBinding reference ) {
		super(reference);
	}
	
	@Override
	public boolean ack() {
		return true;
	}

	@Override
	public boolean check() {
		return true;
	}

	@Override
	public boolean execute() {
		return true;
	}

	@Override
	public boolean executeWithText() {
		return true;
	}
}

package eu.diva.runtime.causallink.command.osgi;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import art.instance.ComponentInstance;
import art.instance.TransmissionBinding;
import eu.diva.runtime.command.CommandComparator;
import eu.diva.runtime.command.PlatformCommand;

public class CommandPlanner {

	private static Logger logger = Logger.getLogger(CommandPlanner.class.getName());

	private SortedSet<PlatformCommand> cmd;

	public SortedSet<PlatformCommand> getCmd() {
		return cmd;
	}

	public void setCmd(SortedSet<PlatformCommand> cmd) {
		this.cmd = cmd;
	}

	private SortedSet<StartComponentOSGi> startCmd;
	private SortedSet<StopComponentOSGi> stopCmd;

	public CommandPlanner(){
		cmd = new TreeSet<PlatformCommand>(new CommandComparator());
	}

	public void plan(){		
		startCmd = new TreeSet<StartComponentOSGi>(new CommandComparator());
		stopCmd = new TreeSet<StopComponentOSGi>(new CommandComparator());

		for(PlatformCommand c : cmd){
			if(c instanceof StartComponentOSGi){
				startCmd.add((StartComponentOSGi)c);
			}
			else if (c instanceof StopComponentOSGi){
				stopCmd.add((StopComponentOSGi)c);
			}
		}

		List<ComponentInstance> cpts = new LinkedList<ComponentInstance>();
		for(StopComponentOSGi c : stopCmd){
			cpts.add(c.getCpt());
		}
		planStopCmd(cpts,0);


		cpts.clear();
		for(StartComponentOSGi c : startCmd){
			cpts.add(c.getCpt());
		}
		planStartCmd(cpts,0);
	}

	//TODO: faire comme pour les starts (casser les cycles)
	private void planStopCmd(List<ComponentInstance> cpts, float i) {
		//		List<ComponentInstance> cpts = new LinkedList<ComponentInstance>();

		HashMap<ComponentInstance,Float> stopLevels = new HashMap<ComponentInstance, Float>(); 

		/*		for(StopComponentOSGi c : stopCmd){
			cpts.add(c.cpt);
		}
		 */		
		//float i = 0;
		int prevSize = 0;
		float j = i;
		while(!(cpts.isEmpty() || cpts.size() == prevSize)){
			prevSize = cpts.size();
			for(ComponentInstance cpt : cpts){
				boolean isClient = false;
				for(TransmissionBinding b : cpt.getBinding()){
					isClient = cpts.contains(b.getServerInstance());
					if (isClient){
						break;
					}
				}	
				if(!isClient){
					stopLevels.put(cpt,j);
				}
			}
			j++;
			cpts.removeAll(stopLevels.keySet());
		}

		for(StopComponentOSGi c : stopCmd){
			if(stopLevels.get(c.getCpt()) != null){
				c.changePriority(stopLevels.get(c.getCpt())/(j+1));
			}
		}
	}

	private void planStartCmd(List<ComponentInstance> cpts, float i) {
		HashMap<ComponentInstance,Float> startLevels = new HashMap<ComponentInstance, Float>(); 

		int prevSize = 0;
		float j = i;
		while(!(cpts.isEmpty() || cpts.size() == prevSize)){
			prevSize = cpts.size();
			for(ComponentInstance cpt : cpts){
				boolean isClient = false;
				for(TransmissionBinding b : cpt.getBinding()){
					isClient = cpts.contains(b.getServerInstance());
					if (isClient){
						break;
					}
				}	
				if(!isClient){
					startLevels.put(cpt,j);
				}
			}
			j++;
			cpts.removeAll(startLevels.keySet());
		}

		//cycle is detected
		if(cpts.size() > 0 && cpts.size() == prevSize){
			planStartCmdWithCyle(cpts,j);
		}		

		for(StartComponentOSGi c : startCmd){
			if(startLevels.get(c.getCpt()) != null){
				c.changePriority((j - startLevels.get(c.getCpt()))/(j+1));
			}
		}
	}

	private void planStartCmdWithCyle(List<ComponentInstance> cpts, float i) {
		logger.warn("Cycle Detected!!!");

		ComponentInstance c = null;
		for(ComponentInstance cpt : cpts){
			if (cpt.isCycling()){
				c = cpt;
				break;
			}
		}
		if(c != null){
			logger.warn("  Removing "+c.getName());
		}
		cpts.remove(c);
		planStartCmd(cpts, i+1);
	}
}

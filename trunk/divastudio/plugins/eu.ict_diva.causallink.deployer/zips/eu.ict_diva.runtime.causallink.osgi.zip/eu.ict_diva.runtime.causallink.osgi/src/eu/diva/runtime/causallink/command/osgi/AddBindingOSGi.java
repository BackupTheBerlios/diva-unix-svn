package eu.diva.runtime.causallink.command.osgi;


import org.osgi.framework.BundleContext;

import art.type.Port;
import eu.diva.runtime.causallink.osgi.BindingMethod;
import eu.diva.runtime.causallink.osgi.Helper;
import eu.diva.runtime.command.AddBinding;

public class AddBindingOSGi extends AddBinding implements OSGiCommand{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6364834397911429737L;
	private static BundleContext context;
	private String rootTopic;
	private transient Helper helper;
	
	public AddBindingOSGi( AddBinding reference ) {
		super();
		this.b = reference.getB();
		this.container = reference.getContainer();
		this.nodeId = reference.getNodeId();
	}
	
	public void setRootTopic(String rootTopic) {
		this.rootTopic = rootTopic;
	}
	@Override
	public void setTopic(String topic) {
		rootTopic = topic;
	}
	@Override
	public void setHelper(Helper helper) {
		this.helper = helper;
	}
	
	public int getAckPeriod(){
		return 10;
	}
	
	public boolean ack() {
		return ack;
	}

	public static void setContext(BundleContext context){
		AddBindingOSGi.context = context;
	}

	public boolean check() {
		return b != null && context != null;
	}

	public boolean execute() {

		Object cpt = helper.getComponent(container);

		if(cpt!=null){//if null, cpt is stopped or not existing at runtime

			//Object server = helper.getComponent(b.getServerInstance());
			Object server = helper.getService(b.getServerInstance(), b.getServer());

			if(server != null){//if null, server is stopped or not existing at runime

				boolean isCollection = true; 
				
				if(b.getClient() instanceof Port){
					isCollection = ((((Port)b.getClient()).getUpper())>1) || ((((Port)b.getClient()).getUpper())<0);
				}
				String name = b.getClient().getName();
				String id = b.getId();

				
				try {
					BindingMethod bMethod = new BindingMethod(name, cpt, server, isCollection, false, id, b, this, rootTopic);
					bMethod.invoke();
					return true;
					
				} catch (Exception e) {
					e.printStackTrace();
					return false;
				}
				
			}
		}
		return true;
	}


	public boolean executeWithText() {
		return OSGiCommandPrinter.executeWithText(this);
	}

	/*public int getPriority(){
		return 2;
	}*/
}

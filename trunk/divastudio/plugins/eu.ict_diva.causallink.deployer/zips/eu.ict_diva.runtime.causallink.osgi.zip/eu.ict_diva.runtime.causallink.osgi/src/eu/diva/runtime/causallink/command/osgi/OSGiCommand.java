package eu.diva.runtime.causallink.command.osgi;

import eu.diva.runtime.causallink.osgi.Helper;

public interface OSGiCommand {
	public void setTopic(String topic);
	public void setHelper(Helper helper);

	// Duplicate from PlatformCommand
	public float  getPriority();	
	/**
	 * Checks the consistency of the command
	 */
	public boolean check();
	
	/**
	 * Executes the command i.e., a runtime adaptation
	 */
	public boolean execute();
	public boolean executeWithText();
	
	//public boolean ack(); // return ack;
	public int getAckPeriod(); // return 50
	
}

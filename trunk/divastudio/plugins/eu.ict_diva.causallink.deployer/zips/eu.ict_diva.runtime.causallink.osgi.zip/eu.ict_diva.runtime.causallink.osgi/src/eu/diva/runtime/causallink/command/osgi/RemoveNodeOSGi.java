package eu.diva.runtime.causallink.command.osgi;

import eu.diva.runtime.causallink.osgi.Helper;
import eu.diva.runtime.command.RemoveNode;

public class RemoveNodeOSGi extends RemoveNode implements OSGiCommand{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3000872312097155665L;


	public RemoveNodeOSGi( RemoveNode reference ) {
		super();
		this.node = reference.getNode();
		this.nodeId = reference.getNodeId();
	}
	
	public void setRootTopic(String rootTopic) {
	}

	public boolean check() {
		return node != null ;
	}


	public boolean execute() {
		return true;
	}


	public boolean executeWithText() {
		return OSGiCommandPrinter.executeWithText(this);
	}

	/*public int getPriority(){
		return 5;
	}*/

	@Override
	public void setTopic(String topic) {
	}

	@Override
	public void setHelper(Helper helper) {
	}

	@Override
	public int getAckPeriod() {
		return 50;
	}
	
}

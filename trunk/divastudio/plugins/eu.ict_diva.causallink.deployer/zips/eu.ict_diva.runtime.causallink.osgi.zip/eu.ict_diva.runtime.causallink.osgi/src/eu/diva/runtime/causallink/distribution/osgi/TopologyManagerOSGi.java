package eu.diva.runtime.causallink.distribution.osgi;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.osgi.framework.BundleContext;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceEvent;
import org.osgi.framework.ServiceListener;
import org.osgi.framework.ServiceReference;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventAdmin;
import org.osgi.util.tracker.ServiceTracker;

import eu.diva.osgi.component.DiVAComponentOSGi;
import eu.diva.runtime.causallink.osgi.OSGiCausalLink;
import eu.diva.runtime.command.CommandProcessor;
import eu.diva.runtime.command.PlatformCommand;
import eu.diva.runtime.distribution.Constants;
import eu.diva.runtime.distribution.TopologyClient;
import eu.diva.runtime.distribution.TopologyManager;

/**
 * Manages the topology of DiVA nodes and sends commands to the proper
 * target.
 * 
 * TODO: should be also in charge of creating nodes in the model when
 *       new nodes are detected. Should be in fact in charge of 
 *       updating model in the CausalLink
 * 
 * @author Vincent Girard-Reydet - ThereSIS, Thales Services SA
 */
public class TopologyManagerOSGi implements CommandProcessor, DiVAComponentOSGi, TopologyManager 
{
	private static Logger logger = Logger.getLogger(OSGiCausalLink.class.getName());

	private ServiceTracker clientsTracker;
	private Map<String,TopologyClient> clients = new HashMap<String,TopologyClient>();
	private EventAdmin eventAdmin;
	
	private BundleContext context;
	private String instanceName;
	
	@Override
	public ExecutionResult executeCommands(List<PlatformCommand> commands) {
		
		ExecutionResult result = new ExecutionResult();
		// TODO: this is really trivial for now. We must improve it.
		result.nbOkCommands = 0;
		for( PlatformCommand command: commands )
		{
			final TopologyClient client = clients.get(command.getNodeId());
			// Warning: test has side effects
			if (null == client || !sendCommand(client,command))
			{
				// TODO
				result.indexKoCommand = result.nbOkCommands;
				break;
			}
			++result.nbOkCommands;
		}
		
		return result;
	}
	
	// Used by TopologyClients to notify of unexpected platform events
	// such as a bundle disappearing
	public void notifyEvent( String eventType, Dictionary properties)
	{
		eventAdmin.postEvent(new Event(eventType, properties));
	}
	
	//
	// DiVAComponentOSGi interface
	//

	@Override
	public BundleContext getContext() {
		return context;
	}

	@Override
	public void setContext(BundleContext context) {
		this.context = context;
	}

	@Override
	public String getInstanceName() {
		return instanceName;
	}

	@Override
	public void setInstanceName(String name) {
		this.instanceName = name;
	}

	@Override
	public void start() {
		getEventAdmin();
		getTopologyClients();
		/*Properties props = new Properties();
		props.put("service.exported.interfaces", TopologyManager.class.getName());
		props.put("service.exported.configs", "org.apache.cxf.ws");			
		context.registerService(TopologyManager.class.getName(), this, props);*/
	}

	@Override
	public void stop() {
		if( null != clientsTracker )
			clientsTracker.close();
	}
	
	//
	// Private Helpers
	//
	
	private boolean sendCommand( TopologyClient client, PlatformCommand command ) {
		try {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			ObjectOutputStream s;
			s = new ObjectOutputStream(out);
			s.writeObject(command);
			return client.execute(out.toByteArray());
		} catch (IOException e) {
			logger.error("Error opening output stream",e);
		}
		return false;
	}
	
	private void getEventAdmin()
	{
		final ServiceReference ref = context.getServiceReference(EventAdmin.class.getName());
		if(ref != null){
			eventAdmin = (EventAdmin) context.getService(ref);
		}
		else{
			logger.warn("CausallinkOSGi::Couldn't find an EventAdmin service.");
		}		
		// Register a service listener so that we can handle the service disappearing
		try {
			context.addServiceListener(new ServiceListener() {
				public void serviceChanged(ServiceEvent event) {

					//gets the service if local attribute is null
					if(TopologyManagerOSGi.this.eventAdmin == null && event.getType() == ServiceEvent.REGISTERED) {

						TopologyManagerOSGi.this.eventAdmin = (EventAdmin)TopologyManagerOSGi.this.context.getService(event.getServiceReference());
						logger.info(TopologyManagerOSGi.this.context.getBundle().getSymbolicName() + ":: EventAdmin service registered");

						// removes the reference if the service is unregistering
					} else if( TopologyManagerOSGi.this.eventAdmin != null && event.getType() == ServiceEvent.UNREGISTERING ){

						TopologyManagerOSGi.this.eventAdmin = null;
						logger.warn(TopologyManagerOSGi.this.context.getBundle().getSymbolicName() + ":: EventAdmin service unregistered");
					}
				}
			}, "(objectClass=" + EventAdmin.class.getName() + ")");
		} catch (InvalidSyntaxException e) {
			logger.error("InvalidSyntax", e);
		}
	}

	private void getTopologyClients()
	{
	    clientsTracker = new ServiceTracker(context, TopologyClient.class.getName(), null) {
	        @Override
	        public Object addingService(ServiceReference reference) {
	            Object svc = context.getService(reference);
	            clients.put((String)reference.getProperty("nodeId"), (TopologyClient)svc);
	        	// Post an event so that the CausalLink can update the model
	            Properties props = new Properties();
	            props.put(Constants.QUALIFIED_NAME, (String)reference.getProperty("nodeId"));
	            eventAdmin.postEvent(new Event(Constants.NODE_ADDED,props));
	            return svc;
	        }
	        @Override
	        public void removedService(ServiceReference reference, Object service) {	        	
	        	clients.remove(reference.getProperty("nodeId"));
	        	context.ungetService(reference);
	        	// Post an event so that the CausalLink can update the model
	            Properties props = new Properties();
	            props.put(Constants.QUALIFIED_NAME, (String)reference.getProperty("nodeId"));
	            eventAdmin.postEvent(new Event(Constants.NODE_REMOVED,props));
	        }	        
	    };
	    clientsTracker.open();		
	}
	
}

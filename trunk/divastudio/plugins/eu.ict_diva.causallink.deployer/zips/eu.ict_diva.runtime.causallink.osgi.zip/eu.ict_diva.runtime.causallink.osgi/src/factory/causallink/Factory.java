package factory.causallink;

import eu.diva.divastudio.services.runtime.CausalLink;
import eu.diva.runtime.causallink.osgi.FakeCausalLink;
import eu.diva.runtime.causallink.osgi.OSGiCausalLink;

public class Factory implements eu.diva.factoryinstdiva.Factory<CausalLink>
{

	private static Factory fact = new Factory();

	public static Factory getFact() {
		return fact;
	}

	public static void setFact(Factory fact) {
		Factory.fact = fact;
	}

	public static OSGiCausalLink getComponent() {
		return new OSGiCausalLink();
	}


	public CausalLink createComponent() {
		return getComponent();

	}	


	public CausalLink createComponent(String implementingClass) {
		if(implementingClass.equals("eu.diva.runtime.causallink.osgi.FakeCausalLink")){
			return new FakeCausalLink();
		}
		return createComponent();
	}

	public boolean check(String implementingClass) {
		return false;
	}
}

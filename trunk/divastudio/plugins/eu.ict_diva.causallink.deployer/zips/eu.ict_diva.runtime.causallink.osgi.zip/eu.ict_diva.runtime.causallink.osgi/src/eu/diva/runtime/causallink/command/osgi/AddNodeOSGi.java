package eu.diva.runtime.causallink.command.osgi;

import org.osgi.framework.BundleContext;

import eu.diva.runtime.causallink.osgi.Helper;
import eu.diva.runtime.command.AddNode;

public class AddNodeOSGi extends AddNode implements OSGiCommand{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7502659272996551174L;
	private static int period = 500;

	public AddNodeOSGi( AddNode reference ) {
		super();
		this.node = reference.getNode();
		this.nodeId = reference.getNodeId();
	}
	
	public static void setContext(BundleContext context) {
	}

	public void setRootTopic(String rootTopic)
	{
	}

	public int getAckPeriod(){
		return period;
	}


	public boolean check() {
		return node != null /*&& qNames != null*/;
	}


	public boolean execute() {
		// TODO: check if there's something to do
		return true;
	}

	public boolean executeWithText() {
		return OSGiCommandPrinter.executeWithText(this);
	}

	/*public int getPriority(){
		return 4;
	}*/

	@Override
	public void setTopic(String topic) {
	}
	
	@Override
	public void setHelper(Helper helper) {
	}
}

package eu.diva.runtime.causallink.command.osgi;

import java.util.Dictionary;
import java.util.Properties;

import org.osgi.service.event.Event;
import org.osgi.service.event.EventAdmin;

import art.instance.ComponentInstance;
import eu.diva.runtime.causallink.osgi.Helper;
import eu.diva.runtime.command.StopComponent;

public class StopComponentOSGi extends StopComponent implements OSGiCommand{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4495329691782333486L;
	private static EventAdmin eventAdmin;
	private static int period = 150;

	private transient Helper helper;
	private transient Event e;
	private transient Event error;
	
	private String rootTopic;

	public StopComponentOSGi( StopComponent reference ) {
		super();
		this.cpt = reference.getCpt();
		this.nodeId = reference.getNodeId();
	}
	
	public static void setEventAdmin(EventAdmin eventAdmin) {
		StopComponentOSGi.eventAdmin = eventAdmin;
	}

	public void setCpt(ComponentInstance cpt) {
		this.cpt = cpt;
	}

	public void setRootTopic(String rootTopic) {
		this.rootTopic = rootTopic;
	}


	public int getAckPeriod(){
		return period;
	}


	public boolean check() {
		return cpt != null;
	}

	public boolean execute() {
		
		//TODO: Check EventAdmin != null
		
		Dictionary<Object,Object> props = new Properties();
		props.put("component", cpt);
		props.put("command", this);
		e = new Event(rootTopic+"/stopComponent/ok/"+cpt.getName(), props);

		try {
			helper.stopComponent(cpt);
			eventAdmin.postEvent(e);
			return true;

		} catch (Exception e) {
			error = new Event(rootTopic+"/stopComponent/nok/"+cpt.getName(), props);
			eventAdmin.postEvent(error);
			e.printStackTrace();
			return false;
		}		
	}

	public boolean executeWithText() {
		return OSGiCommandPrinter.executeWithText(this);
	}
	
	/*public int getPriority(){
		return 7;
	}*/


	@Override
	public void setTopic(String topic) {
		rootTopic = topic;
		
	}

	@Override
	public void setHelper(Helper helper) {
		this.helper = helper;		
	}
}

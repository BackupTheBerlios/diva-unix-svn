package eu.diva.runtime.causallink.osgi;

import java.util.Map;

import org.apache.log4j.Logger;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceImpl;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceReference;

import art.ArtPackage;
import art.distrib.Node;
import art.implem.OSGiType;
import art.instance.ComponentInstance;
import art.type.AbstractPort;
import eu.diva.osgi.component.DiVAComponent;
import eu.diva.osgi.component.DiVAComponentOSGi;
import fr.irisa.triskell.eclipse.emf.EMFRegistryHelper;

/**
 * Class used by command processor and commands to get access to DiVA
 * components.
 * 
 * @author Brice Morin
 */
public final class Helper {

	private static Logger logger = Logger.getLogger(Helper.class.getName());
	
	private static BundleContext context;
	public static void setContext(BundleContext context) {
		Helper.context = context;
	}

	private Map<DiVAComponent, ComponentInstance> map2;

	
	public void setMap2(Map<DiVAComponent, ComponentInstance> map2) {
		this.map2 = map2;
	}

	Helper(){}
	
	/**
	 * Gets the runtime component associated with the ART component cpt
	 * @param cpt
	 * @return
	 */
	public Object getComponent(ComponentInstance cpt){
		Object o = null;
		
		//if the runtime component is an OSGi bundle
		if(cpt.getType().getImplem() == null || ((OSGiType)cpt.getType().getImplem()).getGenerateInstanceBundle()){
			o = getOSGiComponent(cpt);
		}

		//the runtime component is not an OSGi bundle
		else{
			o = getRuntimeComponent(cpt);
		}
		return o;
	}
	
	public Object getService(ComponentInstance cpt, AbstractPort p) {
		StringBuilder builder = new StringBuilder();
		builder.append("(&(objectClass=").append(p.getService().getName()).append(")");
		builder.append("(").append("InstanceName=").append(cpt.getName()).append(")");
		builder.append("(").append("PortName=").append(p.getName()).append(")");
		Node n = getNodeOfComponent(cpt);
		if (n != null )
			builder.append("(").append("nodeId=").append(n.getName()).append(")");
		builder.append(")");
		try {
			ServiceReference[] references = context.getAllServiceReferences(null, builder.toString());
			if( null == references || references.length == 0 )
				return null;
			else
			{
				return context.getService(references[0]);
			}
		}
		catch (InvalidSyntaxException e) {
			logger.error("InvalidSyntax", e);
		}
		catch (java.lang.IllegalStateException e) {
			if (e.getMessage().equals("BundleContext is no longer valid")) {
				logger.error("Could not load service "+p.getService().getName()+" because BundleContext is no longer valid. The bundle is probably stopped or uninstalled.");
			} else{
				logger.error("IllegalStateException", e);
			}
		}
		catch (Exception e) {
			logger.error("Exception", e);
		}
		return null;
	}
	
	public static Node getNodeOfComponent(ComponentInstance comp) {
		ComponentInstance current = comp;
		ComponentInstance parent = comp.getSuperComponent();
        while(parent != null){
        	current = parent;
            parent = current.getSuperComponent();
        }
        Object n = current.eContainer();
        if( n != null && n instanceof Node )
        	return (Node)n;
        else
        	return null;
	}

	private static Object getOSGiComponent(ComponentInstance cpt){
		Object o = null;
		try {
			if(cpt.getImplem() == null) {
				throw new Exception("Instance:" + cpt.getName() + " of component " + cpt.getType().getName() + " must have an implementation class specified in model.");
			}

			ServiceReference[] refs;
			//String filter = "(&(objectClass="+((OSGiComponentImpl)cpt.getImplem()).getImplementingClass()+")"+"(InstanceName="+cpt.getName()+"))";
			String filter = "(&(objectClass="+DiVAComponentOSGi.class.getName()+")"+"(InstanceName="+cpt.getName()+")";
			Node n = getNodeOfComponent(cpt);
			if (n != null )
				filter = filter + "(nodeId=" + n.getName() + ")";
			filter = filter + ")";

			refs = context.getAllServiceReferences(null, filter);
			
			//cannot find the runtime component
			if(refs == null){
				for(Bundle b : context.getBundles()){
					if(b.getSymbolicName().equals(cpt.getName()) && b.getState()!=Bundle.ACTIVE){
						return null;
						//b.start();
					}
				}
				refs = context.getAllServiceReferences(null, filter);
			}

			//runtime component found
			if(refs != null){
				o =  context.getService(refs[0]);
			} else {
				logger.error("Could not load component "+cpt.getName());
			}

		}
		catch (InvalidSyntaxException e) {
			logger.error("InvalidSyntax", e);
		}
		catch (java.lang.IllegalStateException e) {
			if (e.getMessage().equals("BundleContext is no longer valid")) {
				logger.error("Could not load component "+cpt.getName()+" because BundleContext is no longer valid. The bundle is probably stopped or uninstalled.");
			} else{
				logger.error("IllegalStateException", e);
			}
		}
		catch (Exception e) {
			logger.error("Exception", e);
		}
		return o;
	}
	
	private Object getRuntimeComponent(ComponentInstance cpt){
		Object o;
		DiVAComponent c = null;
		synchronized(map2){
			for(DiVAComponent c2 : map2.keySet()){
				if(c2.getInstanceName().equals(cpt.getName())){
					c = c2;
					break;
				}
			}
		}
		o = c;
		return o;
	}
	
	
	/**
	 * Starts the DiVA component corresponding to the ART component cpt
	 * @param cpt
	 * @throws Exception
	 */
	public void startComponent(ComponentInstance cpt) throws Exception {
		DiVAComponent c = (DiVAComponent) getComponent(cpt);
		if(c == null) {
			throw new Exception("Couldn't get component:" + cpt.getName());
		} else {
			c.start();
		}
	}

	/**
	 * Stops the DiVA component corresponding to the ART component cpt
	 * @param cpt
	 * @throws Exception
	 */
	public void stopComponent(ComponentInstance cpt) throws Exception{
		DiVAComponent c = (DiVAComponent) getComponent(cpt);
		if(c == null) {
			//logger.error("Couldn't get component: " + cpt.getName(), new Exception("Couldn't get component: " + cpt.getName()+" It is probably already stopped or uninstalled.").getStackTrace()[0]);
			logger.error("Couldn't get component: " + cpt.getName(), new Exception("Couldn't get component: " + cpt.getName()+" It is probably already stopped or uninstalled."));
			//throw new Exception("Couldn't get component: " + cpt.getName()+" It is probably already stopped or uninstalled.");
		} else {
			c.stop();
		}
	}
	
	/**
	 * Loads an ART model from an URI
	 * @param modelURI
	 * @return
	 * @throws Exception
	 */
	public static art.System loadUpdateModel(String modelURI) throws Exception {
		logger.info("CausallinkOSGi::Loading an update model by URI: "+modelURI);

		URI ecoreFileURI = URI.createFileURI(modelURI);

		if (!ecoreFileURI.isFile()){
			throw new Exception("CausallinkOSGi::EcoreURI:\"" + ecoreFileURI + "\" is not a file and can not be loaded.");
		}

		Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
		Map<String,Object> m = reg.getExtensionToFactoryMap();
		m.put("xmi", new XMIResourceFactoryImpl());

		EMFRegistryHelper.safeRegisterPackages(EPackage.Registry.INSTANCE, ArtPackage.eINSTANCE);
		//System.out.println("registered: "+EMFRegistryHelper.isRegistered("http://art"));

		Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put
		("art",
				new XMIResourceFactoryImpl()
		{
			public Resource createResource(URI uri)
			{
				return new XMIResourceImpl(uri);
			}
		});

		ResourceSet rs = new ResourceSetImpl();


		//System.out.println(ecoreFileURI.path());


		Resource res = rs.getResource(ecoreFileURI, true);
		return (art.System)res.getContents().get(0);
	}
}

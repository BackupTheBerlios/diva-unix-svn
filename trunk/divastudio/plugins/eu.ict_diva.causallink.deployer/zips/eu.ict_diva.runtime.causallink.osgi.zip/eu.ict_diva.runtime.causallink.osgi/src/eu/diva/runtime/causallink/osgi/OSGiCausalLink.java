package eu.diva.runtime.causallink.osgi;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceEvent;
import org.osgi.framework.ServiceListener;
import org.osgi.framework.ServiceReference;
import org.osgi.framework.ServiceRegistration;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventAdmin;
import org.osgi.service.event.EventConstants;
import org.osgi.service.event.EventHandler;

import art.ArtFactory;
import art.NamedElement;
import art.distrib.Node;
import art.group.InstanceGroup;
import art.impl.ArtFactoryImpl;
import art.instance.ComponentInstance;
import art.instance.TransmissionBinding;
import art.type.AbstractPort;
import art.type.Port;
import eu.diva.divastudio.services.runtime.CausalLink;
import eu.diva.divastudio.services.runtime.IChecker;
import eu.diva.osgi.component.DiVAComponentOSGi;
import eu.diva.runtime.causallink.ConfigurationComparator;
import eu.diva.runtime.causallink.command.osgi.AddBindingOSGi;
import eu.diva.runtime.causallink.command.osgi.AddComponentOSGi;
import eu.diva.runtime.causallink.command.osgi.CommandPlanner;
import eu.diva.runtime.causallink.command.osgi.RemoveComponentOSGi;
import eu.diva.runtime.causallink.command.osgi.StartComponentOSGi;
import eu.diva.runtime.causallink.command.osgi.StopComponentOSGi;
import eu.diva.runtime.command.CommandFactory;
import eu.diva.runtime.command.CommandProcessor;
import eu.diva.runtime.command.GenericCommandFactory;
import eu.diva.runtime.command.PlatformCommand;
import eu.diva.runtime.command.RemoveBinding;
import eu.diva.runtime.command.StopComponent;

/**
 * OSGi implementation of the DiVA {@linkplain CausalLink} interface.
 * 
 * @author Brice Morin - IRISA Rennes / Equipe-Projet INRIA Triskell
 * @author Vincent Girard-Reydet - ThereSIS, Thales Services SA
 */
public class OSGiCausalLink 
	implements DiVAComponentOSGi, CausalLink, EventHandler 
{

	private static Logger logger = Logger.getLogger(OSGiCausalLink.class.getName());
	private static final String CLASSFILTER = "(" + Constants.OBJECTCLASS + "=";

	private String instanceName;
	private BundleContext context;

	// Ordered list of configuration commands - stored because 
	// reconfiguration might be delayed
	private List<PlatformCommand> commands;
	private CommandPlanner planner;

	// Causally connected models
	private art.System system; //the reference model
	private art.System updateModel;//a new model to switch to
	private IChecker checker;
	private ConfigurationComparator comparator;
	private CommandAcknowledger acknowledger;

	// TODO: VGR - I assume for now that the reference is wired by the DiVA Bootstrap.
	// Maybe we need to get it by service reference ?
	protected CommandProcessor commandProcessor;
	protected CommandFactory factory;
	protected Map<String, NamedElement> qName2model;

	private boolean standby;
	private EventAdmin eventAdmin;
	private List<ServiceRegistration> regs;

	public OSGiCausalLink()
	{
		regs = new ArrayList<ServiceRegistration>();
		planner = new CommandPlanner();
		commands = Collections.synchronizedList(new ArrayList<PlatformCommand>());
		qName2model = /*Collections.synchronizedMap(*/new Hashtable<String, NamedElement>()/*)*/;

		comparator = new ConfigurationComparator();

		//factory = new OSGiCommandFactory();
		//factory.setqNames(qName2model);
		factory = new GenericCommandFactory();
		acknowledger = new CommandAcknowledger();
		acknowledger.setQnames(qName2model);

		comparator.setCommandFactory(factory);

		standby = false;

		initSystem();
	}

	//
	// DiVAComponentOSGi interface
	//
	
	public void start()
	{
		logger.info("Starting CausalLink[name:" + instanceName + "]");

		/**
		 * registering as an event handler
		 */
		String[] topics = new String[] {
				instanceName+"/binding/*", 
				instanceName+"/unbinding/*", 
				instanceName+"/addComponent/*", 
				instanceName+"/removeComponent/*",
				instanceName+"/startComponent/*",
				instanceName+"/stopComponent/*",
				instanceName+"/setAttribute/*",
				"diva/component/*",
				"diva/node/*"
		};
		Dictionary<Object,Object> ht = new Hashtable<Object,Object>();
		ht.put(EventConstants.EVENT_TOPIC, topics);
		regs.add(context.registerService(EventHandler.class.getName(), this, ht));

		if(!instanceName.equals("root"))
		{
			regs.add(context.registerService(CausalLink.class.getName(), this, null));
		}

		Helper.setContext(context);
		getEventAdmin();
		updateReferences();
	}

	public void stop() {
		for( ServiceRegistration reg : regs ){
			reg.unregister();
		}
	}

	@Override
	public String getInstanceName() {
		return instanceName;
	}


	@Override
	public void setInstanceName(String name) {
		this.instanceName = name;
	}
	
	@Override
	public BundleContext getContext() {
		return context;
	}

	@Override
	public void setContext(BundleContext context) {
		this.context = context;
	}

	//
	// CausalLink interface
	//
	
	@Override
	public int reconfigureInMemory(art.System system){
		updateModel = system;
		return reconfigure();
	}

	/**
	 * Loads a modified runtime model, analyzes this model and 
	 * modifies the platform
	 * @param updateModelPath: path of a modified runtime model
	 */
	@Override
	public int  reconfigureByModelURI(String modelURI) {
		try {

			loadUpdateModel(modelURI);
			return reconfigure(/*false*/);

		} catch (Exception e) {

			logger.error("Exception", e);
			return -4;
		}

	}

	/**
	 * Saves the current model (representing the current running system)
	 * to the path specified in parameter.
	 */
	@Override
	public void saveModel(String xmiFilePathToSave) {
		logger.info("Saving current model to:" + xmiFilePathToSave);

		java.io.File xmiFile = new java.io.File(xmiFilePathToSave);

		// Create a resource set.
		ResourceSet resourceSet = new ResourceSetImpl();

		// Register the default resource factory -- only needed for stand-alone!
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap()
		.put(Resource.Factory.Registry.DEFAULT_EXTENSION,
				new XMIResourceFactoryImpl());

		// Get the URI of the model file.
		URI fileURI = URI.createFileURI(xmiFile.getAbsolutePath());

		// Create a resource for this file.
		Resource resource = resourceSet.createResource(fileURI);

		// Add the system to the contents.
		resource.getContents().add(system);

		// Save the contents of the resource to the file system.
		try {
			resource.save(null/*Collections.EMPTY_MAP*/);
		} catch (IOException e) {
			logger.error("IOException", e);
		}
	}

	@Override
	public List<String> getGroup(String qName)
	{
		ComponentInstance cpt = (ComponentInstance)qName2model.get(qName);
		if( null == cpt )
			return new ArrayList<String>();

		return getGroup(cpt);
	}
	
	//
	// EventListener interface
	//
	/**
	 * Handles reconfiguration events (ok or nok) generated when atomic
	 * reconfiguration are successful (ok) or not (nok)
	 * When an atomic reconfiguration is ok, the corresponding command is acknowledged
	 */
	@Override
	public void handleEvent(Event event) 
	{
		if (event.getTopic().startsWith(instanceName+"/binding/nok/")){
			TransmissionBinding b = (TransmissionBinding)event.getProperty("binding");
			logger.warn("Problem when binding "+b);
		}

		else if (event.getTopic().startsWith(instanceName+"/unbinding/nok/")){
			TransmissionBinding b = (TransmissionBinding)event.getProperty("binding");
			logger.warn("Problem when unbinding "+b);
		}

		else if (event.getTopic().startsWith(instanceName+"/addComponent/nok")){
			ComponentInstance ci = (ComponentInstance)event.getProperty("component");
			logger.warn("Problem when adding component "+ci);
		}

		else if (event.getTopic().startsWith(instanceName+"/removeComponent/nok")){
			ComponentInstance ci = (ComponentInstance)event.getProperty("component");
			logger.warn("Problem when removing component "+ci);
		}

		else if (event.getTopic().startsWith(instanceName+"/startComponent/nok")){
			ComponentInstance ci = (ComponentInstance)event.getProperty("component");
			logger.warn("Problem when starting component "+ci);
		}

		else if (event.getTopic().startsWith(instanceName+"/stopComponent/nok")){
			ComponentInstance ci = (ComponentInstance)event.getProperty("component");
			logger.warn("Problem when stopping component "+ci);
		}

		else if (event.getTopic().startsWith(instanceName+"/setAttribute/nok")){
			logger.warn("Problem when setting an attribute");
		}
		
		else if (event.getTopic().startsWith("diva/node/added")){
			
		}

		else if (event.getTopic().startsWith("diva/node/removed")){
			
		}

		else if (event.getTopic().startsWith("diva/component/added")){
			
		}

		else if (event.getTopic().startsWith("diva/component/removed")){
			
		}

		else if (event.getTopic().startsWith("diva/component/start")){
			
		}

		else if (event.getTopic().startsWith("diva/component/stop")){
			
		}
}

	//
	// Other public methods
	//

	public void initSystem() {

		logger.info("Initializing System");

		ArtFactory emfRuntimeFactory = new ArtFactoryImpl();
		system = emfRuntimeFactory.createSystem();

		// TODO: we should somehow initialize the list of nodes
		//       maybe using a ServiceListener on TopologyClient ? but then
		//       it would be impossible to use this CausalLink without a topology management
	}

	public void loadUpdateModel(art.System updateModel){
		logger.info("CausallinkOSGi::Loading an update model by passing the root model element itself: "+updateModel);
		this.updateModel = updateModel;
	}

	public void loadUpdateModel(String modelURI) throws Exception {
		this.updateModel = Helper.loadUpdateModel(modelURI);
	}

	public int reconfigure(){
		int status = 0;

		logger.info("CausallinkOSGi::Reconfiguring the running system from a previously loaded update model");
		if (commands.size() > 0) {
			Event e = new Event(instanceName+RECONFIGURATION_NOK_EVENT,  (Dictionary<Object,Object>)new Properties());
			eventAdmin.postEvent(e);
			logger.warn("CausallinkOSGi::Some reconfiguration commands (from a previous reconfiguration) have not been ack yet. Please clean the commands before, or wait for the ack.");
		}	
		else {
			synchronized (commands) {
				if (checker.check(updateModel)){
					status = 1;
					logger.info("CausallinkOSGi::Update model is valid");

					Event e = new Event(instanceName+"/configuration/check/ok", (Dictionary<Object,Object>)new Properties());
					eventAdmin.postEvent(e);

					comparator.matchSystems(system, updateModel);

					if(checkServices()) {
						standby = false;
						doReconfigure();
					} else {
						standby = true;
						Event er = new Event(instanceName+NOT_VALID_CONFIG_EVENT,  (Dictionary<Object,Object>)new Properties());
						eventAdmin.postEvent(er);
						logger.error("CausallinkOSGi::All services needed not present. Reconf aborted. Standby.");
						status = -3;
					}
				} else {
					Event e = new Event(instanceName+NOT_VALID_CONFIG_EVENT,  (Dictionary<Object,Object>)new Properties());
					eventAdmin.postEvent(e);
					logger.warn("CausallinkOSGi::Update model is not valid");
					status = -2;
				}
			}
		}
		return status;
	}

	// Connected by the boostrap
	public void setChecker(IChecker checker){
		this.checker = checker;
	}
	
	// Connected by the bootstrap
	public void setCommandProcessor(CommandProcessor processor){
		commandProcessor = processor;
	}

	//
	// Private Helpers
	//
	
	private void getEventAdmin()
	{
		final ServiceReference ref = context.getServiceReference(EventAdmin.class.getName());
		if(ref != null){
			eventAdmin = (EventAdmin) context.getService(ref);
		}
		else{
			logger.warn("CausallinkOSGi::Couldn't find an EventAdmin service.");
		}		
		// Register a service listener so that we can handle the service disappearing
		try {
			context.addServiceListener(new ServiceListener() {
				public void serviceChanged(ServiceEvent event) {

					//gets the service if local attribute is null
					if(OSGiCausalLink.this.eventAdmin == null && event.getType() == ServiceEvent.REGISTERED) {

						OSGiCausalLink.this.eventAdmin = (EventAdmin)OSGiCausalLink.this.context.getService(event.getServiceReference());
						updateReferences();
						logger.info(OSGiCausalLink.this.context.getBundle().getSymbolicName() + ":: EventAdmin service registered");

						// removes the reference if the service is unregistering
					} else if( OSGiCausalLink.this.eventAdmin != null && event.getType() == ServiceEvent.UNREGISTERING ){

						OSGiCausalLink.this.eventAdmin = null;
						updateReferences();
						logger.warn(OSGiCausalLink.this.context.getBundle().getSymbolicName() + ":: EventAdmin service unregistered");
					}

					if(standby) {
						reconfigure(/*false*/);
					}
				}
			}, CLASSFILTER + EventAdmin.class.getName() + ")");
		} catch (InvalidSyntaxException e) {
			logger.error("InvalidSyntax", e);
		}
	}
	
	private List<String> getGroup(ComponentInstance ci){
		List<String> result = new ArrayList<String>();
		for(InstanceGroup ig : ci.getGroups()){
			EObject parent = ig;
			String hi = null;
			while(parent != null && InstanceGroup.class.isAssignableFrom(parent.getClass())){
				hi = "/" + ((InstanceGroup)parent).getName() + hi;
				parent = parent.eContainer();
			}
			if(hi != null){
				result.add(hi);
			}
		}
		return result;
	}

	private void updateReferences() {
		StartComponentOSGi.setEventAdmin(eventAdmin);
		StopComponentOSGi.setEventAdmin(eventAdmin);
		AddComponentOSGi.setEventAdmin(eventAdmin);
		RemoveComponentOSGi.setEventAdmin(eventAdmin);
		BindingMethod.setEventAdmin(eventAdmin);

		AddComponentOSGi.setContext(context);
		AddBindingOSGi.setContext(context);
	}

	private boolean checkServices() {
		return eventAdmin != null && commandProcessor != null;
	}

	private int doReconfigure(){
		int status = 1;

		logger.info("Starting Reconfiguration");
		commands.clear();

		logger.debug("Calling Planner for " + commands.size() + " commands");

		planner.getCmd().clear();
		planner.getCmd().addAll(comparator.getCommands());
		planner.plan();

		commands.addAll(planner.getCmd());
		logger.debug("Planning done. Result " + commands.size() + " commands");

		final CommandProcessor.ExecutionResult result = commandProcessor.executeCommands(commands);
		for( int i = 0; i < result.nbOkCommands; ++i )
		{
			// Configure the command so it has the correct qName map
			PlatformCommand cmd = commands.get(i);
			acknowledger.ackCommand(cmd);
		}
		status = generateReport(result);

		logger.info("Reconfiguration done.");
		return status;
	}

	private int generateReport(CommandProcessor.ExecutionResult result) {
		logger.info("Reconfiguration Report");

		if (result.indexKoCommand == -1){
			logger.info("No command in error");
			commands.clear();
			Event e = new Event(instanceName+RECONFIGURATION_OK_EVENT,  (Dictionary<Object,Object>)new Properties());
			eventAdmin.postEvent(e);
		} else {
			logger.warn("A command is in error: "+commands.get(result.indexKoCommand));
			StringBuffer commandListBuffer = new StringBuffer();
			commandListBuffer.append("The following commands have been ignored\n");
			for(int i=result.indexKoCommand+1; i<commands.size(); ++i){
				commandListBuffer.append(commands.get(i).toString() + "\n");
			}
			logger.warn(commandListBuffer.toString());
			Event e = new Event(instanceName+RECONFIGURATION_NOK_EVENT,  (Dictionary<Object,Object>)new Properties());
			eventAdmin.postEvent(e);
		}
		logger.info("End of Report");

		return result.indexKoCommand == -1 ? 1 : -1;
	}

	/**
	 * [1..1] port
	 * Stop the client component ci if cpt is the unique mandatory server
	 */
	private void check1to1Ports(ComponentInstance ci, TransmissionBinding b, List<PlatformCommand> cmds){
		if(b.getClient() instanceof Port){
			if(((Port)b.getClient()).getLower()==1){
				if(((Port)b.getClient()).getUpper()==1){
					logger.debug("Stopping "+ci.getName());
					StopComponent cmd = factory.createStopComponent(ci);
					cmds.add(cmd);
				}						
			}
		}
	}

	/**
	 * [1..N] port
	 * Stop the client component ci if there is no other mandatory component
	 * In other words, do not stop the client if there exists another server different from cpt
	 */
	private void checkCollectionPorts(ComponentInstance ci, ComponentInstance cpt, List<PlatformCommand> cmds){
		for(AbstractPort p : ci.getType().getPort()){
			if(p instanceof Port){
				if (p.getRole().equals("client") && ((Port)p).getUpper()==-1 && ((Port)p).getLower()==1){
					boolean stop = true;
					for(TransmissionBinding b : ci.getBinding()){
						if (b.getClient() == p){
							if(b.getServerInstance() != cpt){
								stop = false;
							}
						}
					}
					if (stop)
					{
						logger.debug("Stopping "+ci.getName());
						StopComponent cmd = factory.createStopComponent(ci);
						cmds.add(cmd);
					}
				}
			}
		}
	}

	/**
	 * TODO: invoke this method when unexpected component removal happens
	 * 
	 * Removes all the bindings b of the system such as
	 * b.getServerInstance() == cpt
	 * @param cpt
	 */
	public void removeAllDanglingBindings(ComponentInstance cpt){
		// TODO: move this to the causal link
		logger.debug("removeAllDanglingBindings "+cpt);
		List<PlatformCommand> cmds = new LinkedList<PlatformCommand>();

		for(Node n: system.getNodes()) {
			for(ComponentInstance ci : n.getComponents()){
				logger.debug("  Component "+ci);
	
				for(TransmissionBinding b : ci.getBinding()){
					logger.debug("    Binding "+b+" -> "+b.getServerInstance());
					if (b.getServerInstance() == cpt)
					{
						logger.debug("binding to remove "+b); 
						//toRemove.add(b);
						RemoveBinding cmd = factory.createRemoveBinding(b);
						cmds.add(cmd);
	
						//
						// [1..1] port
						// Stop the client component ci if cpt is the unique mandatory server
						check1to1Ports(ci, b, cmds);
					}
				}
	
				//
				// [1..N] port
				// Stop the client component ci if there is no other mandatory component
				// In other words, do not stop the client if there exists another server different from cpt
				//
				checkCollectionPorts(ci, cpt, cmds);
				//ci.getBinding().removeAll(toRemove);
			}
		}

		commandProcessor.executeCommands(cmds);
	}
}

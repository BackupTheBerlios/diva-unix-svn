package eu.diva.runtime.causallink.osgi;

import java.util.Set;

import eu.diva.osgi.component.DiVAComponent;

/**
 * Helper class to have an easyly configured local causal link.
 * <p>
 * This class might be optimized by avoiding to create first a generic command,
 * and then a platform-specific command.
 * 
 * @author Vincent Girard-Reydet - ThereSIS, Thales Services SA
 */
public class LocalOSGiCausalLink 
	extends OSGiCausalLink 
{
	public LocalOSGiCausalLink()
	{
		super();
		commandProcessor = new OSGiCommandProcessor();

		// TODO: see how we can setup an OSGi observer that will generate events when bundles are installed, removed, etc.
	}

	/**
	 * 
	 * @return the set of POJO components managed by this causal link
	 */
	public Set<DiVAComponent> getPOJOs()
	{
		return ((OSGiCommandProcessor)commandProcessor).getPOJOs();
	}
}

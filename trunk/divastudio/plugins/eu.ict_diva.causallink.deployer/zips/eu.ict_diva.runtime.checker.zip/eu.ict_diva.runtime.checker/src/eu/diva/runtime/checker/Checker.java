package eu.diva.runtime.checker;


import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.osgi.framework.BundleContext;

import art.DataType;
import art.distrib.Node;
import art.implem.OSGiComponent;
import art.implem.OSGiType;
import art.instance.ComponentInstance;
import art.instance.TransmissionBinding;
import art.type.AbstractPort;
import art.type.ComponentType;
import art.type.Port;
import eu.diva.divastudio.services.runtime.IChecker;
import eu.diva.osgi.component.DiVAComponentOSGi;


public class Checker implements IChecker, DiVAComponentOSGi {
	
	private static Logger logger = Logger.getLogger(Checker.class.getName());

	private List<String> datatypes;
	
	private String instanceName;

	private BundleContext context;

	@Override
	public BundleContext getContext() {
		return context;
	}

	@Override
	public void setContext(BundleContext context) {
		this.context = context;
	}
	
	public Checker(){
		datatypes = new ArrayList<String>();
		datatypes.add("Integer");
		datatypes.add("int");
		datatypes.add("Boolean");
		datatypes.add("boolean");
		datatypes.add("Real");
		datatypes.add("real");
		datatypes.add("Float");
		datatypes.add("float");
		datatypes.add("Double");
		datatypes.add("double");
		datatypes.add("String");
		datatypes.add("Color");
		datatypes.add("Character");
		datatypes.add("char");
		datatypes.add("Byte");
		datatypes.add("byte");
		datatypes.add("Long");
		datatypes.add("long");
	}

	/**
	 * Check all the invariants of a configuration
	 * TO be replaced by the invariants written in Kermeta and compiled into Java
	 * @param system 
	 * @return
	 */
	public boolean check(art.System system){
		boolean check = true;
		for(Node n : system.getNodes()){
			for(ComponentInstance ci : n.getComponents()){
				if(!"OFF".equals(ci.getState())){
					check = checkPorts(ci);
				}
	
				if (!check){
					logger.warn("One mandatory client port is not bound for component "+ci.getName());
					return check;
				}
	
				check &= (ci.getImplem() instanceof OSGiComponent);
	
				if (!check){
					logger.warn("The implementation of "+ci.getName()+" is null or not an OSGi implementation");
					return check;
				}
	
			}
		}

		for(ComponentType type : system.getTypes()){
			if(type.getImplem() != null){
				check &= (type.getImplem() instanceof OSGiType);
				if (!check){
					logger.warn("The implementation of component type"+type.getName()+" is not an OSGi implementation");
					return check;
				}
			}
		}

		for(DataType type : system.getDataTypes()){
			check &= datatypes.contains(type.getName());
			if (!check){
				logger.warn("Invalid (not supported) datatype: "+type.getName());
				return check;
			}
		}

		return check;
	}
	
	private boolean checkPorts(ComponentInstance ci){
		boolean check = true;
		for(AbstractPort clientPort : ci.getType().getPort()){
			if(clientPort instanceof Port){
				if (clientPort.getRole().equals("client") && ((Port)clientPort).getLower()==1){
					boolean existBinding = false;
					loop: for(TransmissionBinding b : ci.getBinding()){
						existBinding = (b.getClient() == clientPort);
						if (existBinding){
							break loop;
						}
					}
					check = existBinding;
					if (! check){
						logger.warn("One mandatory client port is not bound for component "+ci.getName());
					}
				}
			}
		}
		return check;
	}
	
	@Override
	public String getInstanceName() {
		return instanceName;
	}

	@Override
	public void setInstanceName(String name) {
		this.instanceName = name;
	}

	@Override
	public void start() {
		// TODO Auto-generated method stub

	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub

	}
}

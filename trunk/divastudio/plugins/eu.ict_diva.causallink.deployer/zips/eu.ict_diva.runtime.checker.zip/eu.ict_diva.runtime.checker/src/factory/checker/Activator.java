package factory.checker;

import java.util.Properties;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

import eu.diva.factoryinstdiva.Factory;

public class Activator implements BundleActivator{

	//public static BundleContext context;
	
	public void start(BundleContext context) {
		//this.context = context;
		Properties props = new Properties();
		props.put("Factory", "Checker");
		context.registerService(
				Factory.class.getName(), factory.checker.Factory.getFact(), props);
	}

	
	public void stop(BundleContext context) {

	}

}

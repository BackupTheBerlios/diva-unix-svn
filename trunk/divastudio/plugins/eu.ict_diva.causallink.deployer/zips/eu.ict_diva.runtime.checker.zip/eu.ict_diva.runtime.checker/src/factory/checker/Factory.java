package factory.checker;

import eu.diva.divastudio.services.runtime.IChecker;
import eu.diva.runtime.checker.Checker;

public class Factory implements eu.diva.factoryinstdiva.Factory<IChecker>{

	private static Factory fact = new Factory();

	public static Factory getFact() {
		return fact;
	}

	public static void setFact(Factory fact) {
		Factory.fact = fact;
	}

	
	public IChecker createComponent() {
		return new Checker();
		
	}	
	
	
	public IChecker createComponent(String implementingClass) {
			return createComponent();
	}

	public boolean check(String implementingClass) {
		return false;
	}
}

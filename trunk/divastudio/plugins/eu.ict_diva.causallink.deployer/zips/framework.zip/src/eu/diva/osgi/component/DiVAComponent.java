package eu.diva.osgi.component;


public interface DiVAComponent {
	
	public void start();
	public void stop();
	
	public void setInstanceName(String name);
	public String getInstanceName();

}

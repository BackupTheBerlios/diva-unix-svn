package eu.diva.factoryinstdiva;

public interface Factory<T> {

	/**
	 * 
	 * @return the default implementation of the component
	 */
	public T createComponent();
	
	/**
	 * 
	 * @param implementingClass: a String describing the qualified name of the 
	 * implementing class of the component to be created
	 * @return
	 */
	public T createComponent(String implementingClass);
	
	/**
	 * 
	 * @param implementingClass
	 * @return true iff the implementingClass is a sub-class of T
	 */
	public boolean check(String implementingClass);
}

package org.kermeta.osgi.bundlefactory.service;

import java.io.IOException;
import java.util.List;

import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;

public interface DoBundleService {

	public long InstallBundle(String uri, BundleContext bc)
			throws BundleException;

	public void doBundle(String srcfile, List<String> libs,
			String outputclassDir, String outputjar, String metainf,
			List<String> resources, String path) throws Exception;
	public void deleteRecursive(String dir) throws IOException;
}
package org.kermeta.osgi.bundlefactory.util;

import java.io.File;
import java.util.List;

public class CompileJava {

	private String listLibs(List<String> libs){
		StringBuffer s = new StringBuffer();
		for (String lib : libs){
			
			s.append(lib + File.pathSeparator);
		}
		//s.delete(s.length()-1, s.length());
		s.append("rt.jar");
		return s.toString();
	}
	
	public void compile( List<String> files ,List<String> libs, String outputdir){
		
		files.add(0, this.listLibs(libs));
		files.add(0, "-classpath");
		files.add(0, "1.5");
		files.add(0, "-target");
		files.add(0,"-1.5");
		files.add(0,"-nowarn");
		files.add(0,"-noExit");
		
		files.add(0,outputdir);
		
		files.add(0,"-d");
		
		org.eclipse.jdt.internal.compiler.batch.Main.main(files.toArray(new String[files.size()]));
		
	}

}

package org.kermeta.osgi.bundlefactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.kermeta.osgi.bundlefactory.service.DoBundleService;
import org.kermeta.osgi.bundlefactory.util.DoBundle;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

import fr.irisa.triskell.utility.FileUtilities;


public class DoBundleActivator implements BundleActivator {

	private static File osgiLib;
	
	private static Logger logger = Logger.getLogger(DoBundleActivator.class.getName());

	/**
	 * @param args
	 */
	public DoBundleActivator() {



	}


	BundleContext bc;

	
	public void start(BundleContext arg0) throws Exception {
		bc = arg0;
		DoBundleService d = new DoBundle();
		Properties props = new Properties();
		//props.put("Dobundle", "Dobundle");
		bc.registerService(
				DoBundleService.class.getName(), d, props);

		deployOsgiLib();

	}

	private void deployOsgiLib() {
		osgiLib = FileUtilities.getPersistentFile(bc, "osgi.jar");
		
		if(osgiLib == null) {
			
			osgiLib = FileUtilities.createPersistentFile(bc, "lib", "osgi.jar");
		
			try {
				
				InputStream is = bc.getBundle().getEntry("lib/osgi.jar").openStream();
				OutputStream os = new FileOutputStream(osgiLib);
				FileUtilities.copyFile(is, os);
				logger.info("OSGi lib copied to " + osgiLib.getAbsolutePath());
				
			} catch (IOException e) {
				logger.error("IOException",e);
			}

		} else {
			logger.info("File already exists\n" + "OsgiLibLocation: " + osgiLib.getAbsolutePath());
		}
	}

	public static File getOsgiLib() {
		return osgiLib;
	}

	
	public void stop(BundleContext arg0) throws Exception {


	}



}

package org.kermeta.osgi.bundlefactory.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.kermeta.osgi.bundlefactory.DoBundleActivator;
import org.kermeta.osgi.bundlefactory.service.DoBundleService;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;


public class DoBundle implements DoBundleService {

	List<String> files = new ArrayList<String>();

	public long InstallBundle(String uri,BundleContext bc) throws BundleException{
		Bundle b = bc.installBundle(uri);
		return b.getBundleId();
	}


	public void doBundle(String srcDir, List<String> libs,
			String classDir, String outputjar, String metainf,
			List<String> resources, String workingDir) throws Exception {

		this.files.clear();

		//adds the osgi lib
		libs.add(DoBundleActivator.getOsgiLib().getAbsolutePath());

		this.listFile(new File(srcDir), "java");
		CompileJava compilateur = new CompileJava();
		compilateur.compile(this.files, libs, classDir);
		this.files.clear();
		if (!new File(classDir).exists())
			new File(classDir).createNewFile();
		this.listFile(new File(classDir), "class");

		File fmeta = new File(metainf);
		this.files.add(fmeta.getAbsolutePath());

		/*
		for (String resource :resources) {
			File orig = new File(resource);
			if (orig.isDirectory()) {
				new File(classDir + orig.getAbsolutePath().replace(workingDir.replace("/","\\"),"")).mkdirs();

			} else {
				File dest = new File(classDir + orig.getAbsolutePath().replace(workingDir.replace("/","\\"),""));
				dest.getParentFile().mkdirs();
				this.copyFile(orig, dest);
				this.files.add(classDir + orig.getAbsolutePath().replace(workingDir.replace("/","\\"),""));
			}
		}
		 */

		this.doZip(this.files.toArray(new String[this.files.size()]),
				outputjar, classDir + File.separator);
		this.deleteRecursive(classDir);
	}

	public void deleteRecursive(String dir) throws IOException {
		this.files.clear();
		this.listFile(new File(dir), null);
		for (String f : this.files) {
			new File(f).delete();
		}
		new File(dir).delete();
	}

	private void listFile(File directory, String ext) throws IOException {
		this.listFile(directory, directory, ext);

	}

	private void listFile(File directory, File origDirectory, String ext)
	throws IOException {
		for (File f : directory.listFiles()) {

			if (f.isDirectory()) {
				this.listFile(f, origDirectory, ext);
				if (ext == null)
					files.add(f.getCanonicalPath().toString().replace(
							origDirectory.getCanonicalPath().toString(),
							origDirectory.toString()));
			} else if (ext == null)
				files.add(f.getCanonicalPath().toString().replace(
						origDirectory.getCanonicalPath().toString(),
						origDirectory.toString()));

			else if (f.getName().toLowerCase().endsWith("." + ext))
				files.add(f.getCanonicalPath().toString().replace(
						origDirectory.getCanonicalPath().toString(),
						origDirectory.toString()));
		}

	}

	private String formatZipFileName(final String fileName, String path) {
		String fn = new String(fileName);
		fn = fn.replace(path, "") //to get relativePaths
		.replace("" + File.separator  + "", "/"); //to avoid \\
		if(fn.startsWith("/"))
			fn = fn.substring(1);
		return fn;

	}

	private void doZip(String[] filenames, String outFilename, String path) {
		// These are the files to include in the ZIP file
		// String[] filenames = new String[]{"filename1", "filename2"};

		// Create a buffer for reading the files
		byte[] buf = new byte[1024];

		try {

			ZipOutputStream out = new ZipOutputStream(new FileOutputStream(
					outFilename));

			// Compress the files
			for (int i = 0; i < filenames.length; i++) {
				FileInputStream in = new FileInputStream(filenames[i]);

				// Add ZIP entry to output stream.
				out.putNextEntry(new ZipEntry(formatZipFileName(filenames[i], path)));

				// Transfer bytes from the file to the ZIP file
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}

				// Complete the entry
				out.closeEntry();
				in.close();
			}

			// Complete the ZIP file
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
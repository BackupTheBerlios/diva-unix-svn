package eu.diva.osgi.component;

import org.osgi.framework.BundleContext;


public interface DiVAComponentOSGi extends DiVAComponent{
	
	void setContext(BundleContext context);
	BundleContext getContext();

}

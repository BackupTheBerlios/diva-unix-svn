package eu.diva.factoryinstdiva;

public interface Factory<T> {

	String FACTORY_PROPERTY_KEY = "Factory";
	
	/**
	 * 
	 * @return the default implementation of the component
	 */
	T createComponent();
	
	/**
	 * 
	 * @param implementingClass: a String describing the qualified name of the 
	 * implementing class of the component to be created
	 * @return
	 */
	T createComponent(String implementingClass);
	
	/**
	 * 
	 * @param implementingClass
	 * @return true iff the implementingClass is a sub-class of T
	 */
	boolean check(String implementingClass);
}

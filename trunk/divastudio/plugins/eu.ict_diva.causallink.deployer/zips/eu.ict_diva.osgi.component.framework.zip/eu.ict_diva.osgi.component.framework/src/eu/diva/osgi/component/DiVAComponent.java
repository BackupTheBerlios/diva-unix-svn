package eu.diva.osgi.component;


public interface DiVAComponent {
	
	void start();
	void stop();
	
	void setInstanceName(String name);
	String getInstanceName();

}

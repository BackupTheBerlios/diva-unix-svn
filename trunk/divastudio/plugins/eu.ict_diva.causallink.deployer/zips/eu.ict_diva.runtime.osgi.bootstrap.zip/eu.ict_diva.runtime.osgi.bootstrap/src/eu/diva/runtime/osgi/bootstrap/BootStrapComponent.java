package eu.diva.runtime.osgi.bootstrap;

import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JFrame;

import org.osgi.framework.BundleContext;

import eu.diva.divastudio.services.runtime.CausalLink;
import eu.diva.divastudio.services.runtime.IChecker;
import eu.diva.runtime.causallink.osgi.OSGiCausalLink;
import eu.diva.runtime.causallink.osgi.OSGiCommandProcessor;
import eu.diva.runtime.command.CommandProcessor;
import factory.causallink.CommandProcessorFactory;
import factory.causallink.Factory;

public class BootStrapComponent {
	
	public BootStrapComponent(BundleContext context){
		
		File model = null;
		String parameterModelUri = System.getProperty("diva.bootstrap.model.uri");
		if(parameterModelUri != null)
			model = new File(parameterModelUri);
		else
			model = chooseBootStrapModel();

		String modelURI = null;
		if(model != null)
			modelURI = model.getAbsolutePath();
		
		factory.checker.Factory checkerFactory = new factory.checker.Factory();
		IChecker checker = checkerFactory.createComponent();
		
		Factory causalLinkFactory = new Factory();
		CausalLink link = causalLinkFactory.createComponent();
		
		CommandProcessorFactory cmdProcFactory = new CommandProcessorFactory();
		CommandProcessor processor = cmdProcFactory.createComponent();
		((OSGiCommandProcessor)processor).setInstanceName("root");
		((OSGiCommandProcessor)processor).setContext(context);
		((OSGiCommandProcessor)processor).start();
		
		((OSGiCausalLink)link).setChecker(checker);
		((OSGiCausalLink)link).setCommandProcessor(processor);
		((OSGiCausalLink)link).setInstanceName("root");
		((OSGiCausalLink)link).setContext(context);
		((OSGiCausalLink)link).start();//Start is not automatically called, since we directly instantiate the component...
		link.reconfigureByModelURI(modelURI);
	}

	private File chooseBootStrapModel(){
		JFileChooser fileChooser = new JFileChooser();
		File model = null;
		
		fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		int status = fileChooser.showOpenDialog(new JFrame());
		File f = null;
		if(status == JFileChooser.APPROVE_OPTION){
			f = fileChooser.getSelectedFile();
			if(f.getAbsolutePath().contains(".art")){
				model = f;
			}
		}
		return model;
	}
	
}

package eu.diva.runtime.distribution;

import eu.diva.runtime.command.PlatformCommand;

/**
 * @author Vincent Girard-Reydet - ThereSIS, Thales Services SA
 */
public interface TopologyClient {
	/**
	 * Remotely execute a command on a node.
	 * TODO: we should be able to execute more than 1 command in parallel
	 * @param command the command to execute
	 */
	boolean sendCommand(PlatformCommand command);
	
	boolean execute(byte[] serializedCommand);

}

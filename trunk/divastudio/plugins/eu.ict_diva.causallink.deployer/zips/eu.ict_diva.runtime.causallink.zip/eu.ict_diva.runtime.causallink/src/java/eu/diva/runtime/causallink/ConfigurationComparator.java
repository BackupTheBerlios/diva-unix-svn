package eu.diva.runtime.causallink;

import java.util.Collections;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.log4j.Logger;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;

import art.distrib.Node;
import art.instance.AttributeInstance;
import art.instance.ComponentInstance;
import art.instance.CompositeInstance;
import art.instance.DefaultEntry;
import art.instance.DelegationBinding;
import art.instance.DictionaryValuedAttribute;
import art.instance.Entry;
import art.instance.OtherEntry;
import art.instance.TransmissionBinding;
import art.instance.ValuedAttribute;
import art.type.Attribute;
import art.type.ComponentType;
import art.type.Port;
import eu.diva.runtime.command.CommandComparator;
import eu.diva.runtime.command.CommandFactory;
import eu.diva.runtime.command.PlatformCommand;

public class ConfigurationComparator {

	private static Logger logger = Logger.getLogger(ConfigurationComparator.class.getName());

	//Attributes related to model comparison
	private Map<Node,Node> matchNodes = new Hashtable<Node,Node>();
	private Set<Node> removedNodes = new HashSet<Node>();
	private Set<Node> addedNodes = new HashSet<Node>();

	private Map<ComponentInstance,ComponentInstance> matchComponents = new Hashtable<ComponentInstance,ComponentInstance>();
	private Set<ComponentInstance> removedComponents = new HashSet<ComponentInstance>();
	private Set<ComponentInstance> addedComponents = new HashSet<ComponentInstance>();

	private Map<TransmissionBinding,TransmissionBinding> matchBindings = new Hashtable<TransmissionBinding,TransmissionBinding>();
	private Set<TransmissionBinding> removedBindings = new HashSet<TransmissionBinding>();
	private Set<TransmissionBinding> addedBindings = new HashSet<TransmissionBinding>();

	private Map<DelegationBinding,DelegationBinding> matchExports = new Hashtable<DelegationBinding,DelegationBinding>();
	private Set<DelegationBinding> removedExports = new HashSet<DelegationBinding>();
	private Set<DelegationBinding> addedExports = new HashSet<DelegationBinding>();

	private Map<ComponentType, ComponentType> matchTypes = new Hashtable<ComponentType, ComponentType>();
	private Set<ComponentType> removedTypes = new HashSet<ComponentType>();
	private Set<ComponentType> addedTypes = new HashSet<ComponentType>();;

	private SortedSet<PlatformCommand> commands = Collections.synchronizedSortedSet(new TreeSet<PlatformCommand>(new CommandComparator()));
	private CommandFactory commandFactory;
	
	public SortedSet<PlatformCommand> getCommands(){
		return commands;
	}
	
	public void setCommandFactory(CommandFactory commandFactory){
		this.commandFactory = commandFactory;
	}

	public void matchSystems(art.System systemModel1, art.System systemModel2) {
		logger.debug("matchSystems");
		long start = System.nanoTime();
		clean();
		matchTypes(systemModel1, systemModel2);
		boolean match = false;
		for( Node n1: systemModel1.getNodes())
		{
			secondloop:{ for(Node n2 : systemModel2.getNodes()){
				match = n1.getName().equals(n2.getName()); 
				if(match){
					logger.debug("Match: Node "+n2.getName());
					matchNodes.put(n1,n2);
					matchComponents(n1, n2);
					break secondloop;
				}
			}}
			if (!match){
				removeNode(n1);
			}
			match = false;
		}
		EList<Node> temp = new BasicEList<Node>();
		temp.addAll(systemModel2.getNodes());
		temp.removeAll(matchNodes.values());
	
		for(Node n : temp)
			addNode(n);

		long duration = System.nanoTime() - start;

		String time = duration+" ns";
		if(duration>=1000000000){
			time = duration/((float)1000000000)+" s";
		}
		else if(duration>=1000000){
			time = duration/((float)1000000)+" ms";
		}
		else if(duration>=1000) {
			time = duration+"µs";
		}

		logger.info("Comparison duration: "+time);
		System.gc();
	}

	public void matchTypes(art.System systemModel1, art.System systemModel2) {
		boolean match = false;
		/**
		 * Diff and Match on component types
		 */
		for(ComponentType t1 : systemModel1.getTypes()){
			secondTypeloop:{ for(ComponentType t2 : systemModel2.getTypes()){
				match = t1.getName().equals(t2.getName());
				if (match){
					matchTypes.put(t1,t2);
					break secondTypeloop;
				}
			}
		}
		if (!match){
			removedTypes.add(t1);
		}
		match = false;		
		}
	
		EList<ComponentType> tempTypes = new BasicEList<ComponentType>();
		tempTypes.addAll(systemModel2.getTypes());
		tempTypes.removeAll(matchTypes.values());
		addedTypes.addAll(tempTypes);			
	}

	public void matchDelegationBindings(CompositeInstance c1, CompositeInstance c2){
		/**
		 * Update Delegation bindings
		 */
		boolean match = false;
		for(DelegationBinding b1 : c1.getDelegation()){
			secondloop:{ for(DelegationBinding b2 : c2.getDelegation()){
				match = b1.getSource().getName().equals(b2.getSource().getName()) 
				&& b1.getExported().getName().equals(b2.getExported().getName())
				&& b2.getServerInstance().getName().equals(b1.getServerInstance().getName());
				if (match){
					matchExports.put(b1, b2);
					break secondloop;
				}
			}
		}
		if (!match){
			removedExports.add(b1);
			commands.add(commandFactory.createRemoveBinding(b1));
		}
		match = false;
		}
		EList<DelegationBinding> temp = new BasicEList<DelegationBinding>();
		temp.addAll(c2.getDelegation());
		temp.removeAll(matchExports.values());
	
		for(DelegationBinding b : temp){
			addedExports.add(b);
			commands.add(commandFactory.createAddBinding(b));
		}			
	}

	private void clean() {
		commands.clear();

		addedComponents.clear();
		removedComponents.clear();
		matchComponents.clear();

		addedBindings.clear();
		removedBindings.clear();
		matchBindings.clear();

		matchTypes.clear();
		removedTypes.clear();
		addedTypes.clear();

		addedExports.clear();
		removedExports.clear();
		matchExports.clear();		
	}

	private void matchComponents(ComponentInstance c1, ComponentInstance c2) {
		logger.debug("Match: Component "+c2.getQualifiedName());
		matchComponents.put(c1,c2);


		/**
		 * Update component state
		 */
		if("ON".equals(c1.getState()) && "OFF".equals(c2.getState())){
			logger.debug("Update: Component "+c2.getQualifiedName()+" has been stopped");
			commands.add(commandFactory.createStopComponent(c1));
		}
		else if ("OFF".equals(c1.getState()) && "ON".equals(c2.getState())){
			logger.debug("Update: Component "+c2.getQualifiedName()+" has been started");
			commands.add(commandFactory.createStartComponent(c1));
		}

		updateAttributes(c1, c2);
		matchBindings(c1, c2);
	}

	private void matchComponents(Node c1, Node c2) {
		//matchComponents((ComponentInstance)c1, (ComponentInstance)c2);
		boolean match = false;
	
		match = false;
		for(ComponentInstance subC1 : c1.getComponents()){
			secondloop:{ for(ComponentInstance subC2 : c2.getComponents()){
				match = subC1.getName().equals(subC2.getName()); 
				if(match){
					if(subC1 instanceof CompositeInstance && subC2 instanceof CompositeInstance){
						matchComponents((CompositeInstance)subC1, (CompositeInstance)subC2);
					}
					else{
						matchComponents(subC1, subC2);
					}
					break secondloop;
				}
			}
		}
	
		if (!match){
			if(subC1 instanceof CompositeInstance){
				removeComponent((CompositeInstance)subC1);
			}
			else{
				removeComponent(subC1);
			}
		}
		match = false;
		}
	
		EList<ComponentInstance> temp = new BasicEList<ComponentInstance>();
		temp.addAll(c2.getComponents());
		temp.removeAll(matchComponents.values());
	
		for(ComponentInstance c : temp){
			if(c instanceof CompositeInstance){
				addComponent((CompositeInstance)c);
			}
			else{
				addComponent(c);
			}
		}
	
		//matchDelegationBindings(c1, c2);	
	}

	private void matchBindings(ComponentInstance c1, ComponentInstance c2) {
		boolean match = false;
		for(TransmissionBinding b1 : c1.getBinding()){
			secondloop:{ for(TransmissionBinding b2 : c2.getBinding()){
				match = b1.getClient().getName().equals(b2.getClient().getName()) 
				&& b1.getServer().getName().equals(b2.getServer().getName())
				&& b2.getServerInstance().getName().equals(b1.getServerInstance().getName());
				if (match){
					logger.debug("Match: Binding "+b2.getId());
					matchBindings.put(b1, b2);
					break secondloop;
				}
			}
		}
		if (!match){
			removeBinding(b1, c1);
		}
		match = false;
		}
		EList<TransmissionBinding> temp = new BasicEList<TransmissionBinding>();
		temp.addAll(c2.getBinding());
		temp.removeAll(matchBindings.values());

		for(TransmissionBinding b : temp){
			logger.debug("Added: Binding "+b.getId());
			addedBindings.add(b);
			commands.add(commandFactory.createAddBinding(b));
		}			
	}

	private void removeBinding(TransmissionBinding b1, ComponentInstance c1){
		logger.debug("Removed: Binding "+b1.getId());
		removedBindings.add(b1);
		commands.add(commandFactory.createRemoveBinding(b1));
		if(b1.getClient() instanceof Port){
			if(((Port)b1.getClient()).getLower()==1 && ((Port)b1.getClient()).getUpper()==1){
				commands.add(commandFactory.createStopComponent(c1));
			}

			Port p = (Port)b1.getClient();
			if (p.getUpper()==-1 && p.getLower()==1){
				boolean stop = true;
				for(TransmissionBinding b : c1.getBinding()){
					if (b != b1 && b.getClient() == p){
						stop = false;
					}
				}
				if(stop){
					commands.add(commandFactory.createStopComponent(c1));
				}
			}	
		}		
	}

	private AttributeInstance getAttributeInstance(Attribute t, ComponentInstance c){
		boolean isValuedInC = false;
		AttributeInstance v = null;
		for(AttributeInstance va1 : c.getAttribute()){

			if(va1 instanceof ValuedAttribute){
				isValuedInC = ((ValuedAttribute)va1).getAttribute().getName().equals(t.getName())
				&& ((ValuedAttribute) va1).getAttribute().getType().getName().equals(t.getType().getName());
			}
			else if (va1 instanceof DictionaryValuedAttribute){//TODO
				isValuedInC = ((DictionaryValuedAttribute)va1).getAttribute().getName().equals(t.getName())
				&& ((DictionaryValuedAttribute) va1).getAttribute().getType().getName().equals(t.getType().getName());								
			}

			if(isValuedInC){
				v = va1;
				break;
			}
		}
		return v;
	}

	private void updateAttributes(ComponentInstance c1, ComponentInstance c2){
		/**
		 * Update attributes
		 */
		for(Attribute t : c1.getType().getAttribute()){
			AttributeInstance v1 = getAttributeInstance(t, c1);
			AttributeInstance v2 = getAttributeInstance(t, c2);

			if(v2!=null && v1==null){
				logger.debug("Updated: Attribute "+v2);
				commands.add(commandFactory.createUpdateAttribute(v2));
			}
			else if(v1!=null && v2!=null){
				update(v1,v2);
			}
		}		
	}

	private void update(AttributeInstance v1, AttributeInstance v2){
		logger.debug("Calling update(AttributeInstance, AttributeInstance)...");
		if(v1 instanceof ValuedAttribute && v2 instanceof ValuedAttribute){
			update((ValuedAttribute)v1, (ValuedAttribute)v2);
		}
		else if(v1 instanceof DictionaryValuedAttribute && v2 instanceof DictionaryValuedAttribute){
			update((DictionaryValuedAttribute)v1, (DictionaryValuedAttribute)v2);
		}
	}

	private void update(ValuedAttribute v1, ValuedAttribute v2){
		if(!((ValuedAttribute) v1).getValue().equals(((ValuedAttribute) v2).getValue())){
			logger.debug("Updated: Attribute "+((ValuedAttribute) v2).getAttribute().getName()+" = "+((ValuedAttribute) v2).getValue());
			commands.add(commandFactory.createUpdateAttribute(v2));
		}
	}

	private void update(DictionaryValuedAttribute v1, DictionaryValuedAttribute v2){
		DictionaryValuedAttribute d1 = (DictionaryValuedAttribute)v1;
		DictionaryValuedAttribute d2 = (DictionaryValuedAttribute)v2;


		//TODO: verifier ajout/retrait de cles
		firstloop:for(Entry e1 : d1.getEntries()){
			for(Entry e2 : d2.getEntries()){
				if (updateEntry(e1,e2,d2)){
					break firstloop;
				}
			}
		}
	}

	private boolean updateEntry(Entry e1, Entry e2, DictionaryValuedAttribute d2){
		logger.debug("Calling updateEntry(Entry, Entry)...");
		if (e1 instanceof DefaultEntry && e2 instanceof DefaultEntry){
			return updateEnty((DefaultEntry)e1, (DefaultEntry)e2, d2);
		}
		else if (e1 instanceof OtherEntry && e2 instanceof OtherEntry){
			return updateEnty((OtherEntry)e1, (OtherEntry)e2, d2);
		}
		return false;
	}

	private boolean updateEnty(DefaultEntry e1, DefaultEntry e2, DictionaryValuedAttribute d2){
		if(((DefaultEntry)e1).getKey().getKey().equals(((DefaultEntry)e2).getKey().getKey()) && !e1.getValue().equals(e2.getValue())){
			logger.debug("Updated: Dictionary "+d2);
			commands.add(commandFactory.createUpdateAttribute(d2));
			return true;
		}
		return false;
	}

	private boolean updateEnty(OtherEntry e1, OtherEntry e2, DictionaryValuedAttribute d2){
		if(((OtherEntry)e1).getKey().equals(((OtherEntry)e2).getKey()) && !e1.getValue().equals(e2.getValue())){
			logger.debug("Updated: Dictionary "+d2);
			commands.add(commandFactory.createUpdateAttribute(d2));
			return true;
		}
		return false;
	}

	private void addComponent(ComponentInstance c) {
		logger.debug("Added: Component "+c.getQualifiedName());
		addedComponents.add(c);
		commands.add(commandFactory.createAddComponent(c));
		for(TransmissionBinding b : c.getBinding()){
			logger.debug("Added: Binding "+b.getId());
			addedBindings.add(b);
			commands.add(commandFactory.createAddBinding(b));
		}

		for(AttributeInstance v : c.getAttribute()){
			commands.add(commandFactory.createUpdateAttribute(v));
		}
		if(!"OFF".equals(c.getState())){
			logger.debug("Started: Component "+c.getQualifiedName());
			commands.add(commandFactory.createStartComponent(c));
		}
	}

	private void addComponent(CompositeInstance c){
		addComponent((ComponentInstance)c);
		for(DelegationBinding b : c.getDelegation()){
			addedExports.add(b);
			commands.add(commandFactory.createAddBinding(b));
		}
	}

	private void addNode(Node n){
		logger.debug("Added: Node "+n.getName());
		addedNodes.add(n);
		commands.add(commandFactory.createAddNode(n));
		for(ComponentInstance c: n.getComponents()) {
			if(c instanceof CompositeInstance)
				addComponent((CompositeInstance)c);
			else
				addComponent(c);
		}
	}

	private void removeComponent(ComponentInstance c) {
		logger.debug("Removed: Component "+c.getQualifiedName());
		removedComponents.add(c);
		commands.add(commandFactory.createRemoveComponent(c));

		removedBindings.addAll(c.getBinding());
		for(TransmissionBinding b : c.getBinding()){
			logger.debug("Removed: Binding "+b.getId());
			commands.add(commandFactory.createRemoveBinding(b));
		}
		logger.debug("Stopped: Component "+c.getQualifiedName());
		commands.add(commandFactory.createStopComponent(c));
	}

	private void removeComponent(CompositeInstance c){
		removeComponent((ComponentInstance)c);
		for(DelegationBinding b : c.getDelegation()){
			removedExports.add(b);
			commands.add(commandFactory.createRemoveBinding(b));
		}
	}

	private void removeNode(Node c){
		logger.debug("Removed: Node "+c.getName());
		removedNodes.add(c);
		commands.add(commandFactory.createRemoveNode(c));
	}
}
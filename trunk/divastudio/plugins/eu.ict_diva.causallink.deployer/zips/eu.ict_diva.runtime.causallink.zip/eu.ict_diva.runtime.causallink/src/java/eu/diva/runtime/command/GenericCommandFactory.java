package eu.diva.runtime.command;

import art.distrib.Node;
import art.instance.AttributeInstance;
import art.instance.Binding;
import art.instance.ComponentInstance;
import art.instance.TransmissionBinding;

/**
 * 
 * @author Vincent Girard-Reydet - ThereSIS, Thales Services
 *
 */
public class GenericCommandFactory 
	implements CommandFactory 
{

	@Override
	public AddBinding createAddBinding(Binding b) {
		if (b instanceof TransmissionBinding){
			AddBinding cmd = new AddBinding();
			cmd.setB((TransmissionBinding)b);
			cmd.setNodeId( getNodeId((TransmissionBinding)b));
			return cmd;
		}
		return null;
	}

	@Override
	public AddComponent createAddComponent(ComponentInstance cpt) {
		AddComponent cmd = new AddComponent();
		cmd.setCpt(cpt);
		cmd.setNodeId(getNodeId(cpt));
		return cmd;
	}

	@Override
	public RemoveBinding createRemoveBinding(Binding b) {
		if(b instanceof TransmissionBinding){
			RemoveBinding cmd = new RemoveBinding();
			cmd.setB((TransmissionBinding)b);
			cmd.setNodeId(getNodeId((TransmissionBinding)b));
			return cmd;
		}
		return null;
	}

	@Override
	public RemoveComponent createRemoveComponent(ComponentInstance cpt) {
		RemoveComponent cmd = new RemoveComponent();
		cmd.setCpt(cpt);
		cmd.setNodeId(getNodeId(cpt));
		return cmd;
	}

	@Override
	public StartComponent createStartComponent(ComponentInstance cpt) {
		StartComponent cmd = new StartComponent();
		cmd.setCpt(cpt);
		cmd.setNodeId(getNodeId(cpt));
		return cmd;
	}

	@Override
	public StopComponent createStopComponent(ComponentInstance cpt) {
		StopComponent cmd = new StopComponent();
		cmd.setCpt(cpt);
		cmd.setNodeId(getNodeId(cpt));
		return cmd;
	}

	@Override
	public UpdateAttribute createUpdateAttribute(AttributeInstance att) {
		UpdateAttribute cmd = new UpdateAttribute();
		cmd.setVa(att);
		cmd.setNodeId(getNodeId(att));
		return cmd;
	}
	
	@Override
	public AddNode createAddNode(Node n) {
		AddNode cmd = new AddNode();
		cmd.setNode(n);
		cmd.setNodeId(n.getName());
		return cmd;
	}

	@Override
	public RemoveNode createRemoveNode(Node n) {
		RemoveNode cmd = new RemoveNode();
		cmd.setNode(n);
		cmd.setNodeId(n.getName());
		return cmd;
	}
	
	private String getNodeId( TransmissionBinding b ) {
		ComponentInstance c = (ComponentInstance)b.eContainer();
		return getNodeId(c);
	}
	
	private String getNodeId(ComponentInstance c) {
		return ((Node)c.eContainer()).getName();
	}

	private String getNodeId(AttributeInstance c) {
		ComponentInstance cpt = (ComponentInstance)c.eContainer();
		return getNodeId(cpt);
	}

}

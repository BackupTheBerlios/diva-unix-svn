package eu.diva.runtime.command;

public abstract class AddComposite extends AddComponent {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2398833512039668376L;

}

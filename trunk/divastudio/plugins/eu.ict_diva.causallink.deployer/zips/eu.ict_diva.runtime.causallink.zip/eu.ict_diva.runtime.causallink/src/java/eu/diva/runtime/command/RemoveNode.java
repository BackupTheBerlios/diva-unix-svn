package eu.diva.runtime.command;

import art.distrib.Node;

public class RemoveNode extends RemoveCommand {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1101560115461512916L;

	protected Node node;

	public RemoveNode(){
		priority = 5;
	}

	public void setNode(Node node) {
		this.node = node;
	}
	public Node getNode() {
		return node;
	}

}

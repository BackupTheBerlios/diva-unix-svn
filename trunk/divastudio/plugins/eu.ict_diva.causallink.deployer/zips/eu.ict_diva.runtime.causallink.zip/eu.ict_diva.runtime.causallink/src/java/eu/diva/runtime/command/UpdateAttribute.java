package eu.diva.runtime.command;

import art.instance.AttributeInstance;

public class UpdateAttribute extends PlatformCommand {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6612841006978684388L;
	protected AttributeInstance va;

	public UpdateAttribute(){
		priority = 1;
	}

	public void setVa(AttributeInstance va) {
		this.va = va;
	}
	public AttributeInstance getVa() {
		return va;
	}

}

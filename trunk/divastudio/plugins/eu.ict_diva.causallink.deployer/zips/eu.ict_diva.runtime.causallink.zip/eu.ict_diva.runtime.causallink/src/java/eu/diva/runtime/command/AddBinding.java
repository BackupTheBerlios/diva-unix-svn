package eu.diva.runtime.command;

import art.instance.ComponentInstance;
import art.instance.TransmissionBinding;

public class AddBinding extends AddCommand {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8461042212286377761L;
	protected TransmissionBinding b;
	protected ComponentInstance container; // must be saved for serialization

	public AddBinding(){
		priority = 1;
	}
	public void setB(TransmissionBinding b) {
		this.b = b;
		container = (ComponentInstance)b.eContainer();
	}
	public TransmissionBinding getB() {
		return b;
	}
	public ComponentInstance getContainer() {
		return container;
	}
}

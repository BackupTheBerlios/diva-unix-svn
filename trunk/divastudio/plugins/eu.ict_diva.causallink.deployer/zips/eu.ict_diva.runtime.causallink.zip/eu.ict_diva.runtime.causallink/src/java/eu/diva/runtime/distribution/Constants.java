package eu.diva.runtime.distribution;

public interface Constants {
	public static final String COMPONENT_START = "diva/component/start";
	public static final String COMPONENT_STOP = "diva/component/stop";
	public static final String COMPONENT_ADDED = "diva/component/added";
	public static final String COMPONENT_REMOVED = "diva/component/removed";
	public static final String NODE_ADDED= "diva/node/added";
	public static final String NODE_REMOVED= "diva/node/removed";
	
	/**
	 * Property name for the qualified name of an event target (might be
	 * a node, a component, a binding or a type).
	 */
	public static final String QUALIFIED_NAME = "qName";
	public static final String NODE_ID = "nodeId";
}

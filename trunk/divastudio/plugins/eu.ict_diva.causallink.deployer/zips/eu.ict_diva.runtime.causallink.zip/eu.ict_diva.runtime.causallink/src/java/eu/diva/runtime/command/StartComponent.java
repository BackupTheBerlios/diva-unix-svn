package eu.diva.runtime.command;

import art.instance.ComponentInstance;

public class StartComponent extends AddCommand{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4137028571487794430L;

	protected ComponentInstance cpt;
	public void setCpt( ComponentInstance cpt ) {
		this.cpt = cpt;
	}
	public ComponentInstance getCpt() {
		return cpt;
	}

	public StartComponent(){
		priority = 0;
	}
}

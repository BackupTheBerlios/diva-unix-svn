package eu.diva.runtime.command;

import art.instance.ComponentInstance;

public class StopComponent extends RemoveCommand {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7169806982328871321L;

	protected ComponentInstance cpt;
	public void setCpt(ComponentInstance cpt) {
		this.cpt = cpt;
	}
	public ComponentInstance getCpt() {
		return cpt;
	}

	public StopComponent(){
		priority = 8;
	}
}

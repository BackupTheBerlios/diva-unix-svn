package eu.diva.runtime.distribution;

import java.util.Dictionary;

public interface TopologyManager {
	void notifyEvent( String eventType, Dictionary properties);
}

package eu.diva.runtime.command;

import art.instance.ComponentInstance;

public class RemoveComponent extends RemoveCommand {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1101560115461512916L;
	protected ComponentInstance cpt;

	public RemoveComponent(){
		priority = 6;
	}
	
	public void setCpt(ComponentInstance cpt) {
		this.cpt = cpt;
	}
	public ComponentInstance getCpt() {
		return cpt;
	}
}

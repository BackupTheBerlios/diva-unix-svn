package eu.diva.runtime.command;

import java.io.Serializable;

import art.distrib.Node;
import art.instance.ComponentInstance;

public class PlatformCommand implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 949437361583184838L;
	protected boolean ack = false;	
	protected float priority;
	protected String nodeId;
	
	public String getNodeId() {
		return nodeId;
	}
	
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	
	public float  getPriority(){
		return priority;
	}	
	public void setPriority(float i){
		priority = i;
	}
	
	public void changePriority(float i){
		if(i < 1){
			setPriority(getPriority()+i);
		}
	}
	
	protected Node getNodeOfComponent(ComponentInstance comp) {
		ComponentInstance current = comp;
		ComponentInstance parent = comp.getSuperComponent();
        while(parent != null){
        	current = parent;
            parent = current.getSuperComponent();
        }
        Object n = current.eContainer();
        if( n != null && n instanceof Node )
        	return (Node)n;
        else
        	return null;
	}
	
}

package eu.diva.runtime.command;

import art.instance.ComponentInstance;

public class AddComponent extends AddCommand {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3952753938148917521L;

	protected ComponentInstance cpt;
	protected String nodeName;
	protected String nodeUri;

	public void setCpt(ComponentInstance cpt) {
		this.cpt = cpt;
		//We must store it to have a correct serialization
		this.nodeName = getNodeOfComponent(cpt).getName();
		this.nodeUri = getNodeOfComponent(cpt).getUri();
	}

	public String getNodeName() {
		return nodeName;
	}
	public String getNodeUri() {
		return nodeUri;
	}
	public ComponentInstance getCpt() {
		return cpt;
	}
	
	public AddComponent(){
		priority = 3;
	}
}

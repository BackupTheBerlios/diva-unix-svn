package eu.diva.runtime.command;

public abstract class RemoveCommand extends PlatformCommand {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3373429566418889307L;
	
}

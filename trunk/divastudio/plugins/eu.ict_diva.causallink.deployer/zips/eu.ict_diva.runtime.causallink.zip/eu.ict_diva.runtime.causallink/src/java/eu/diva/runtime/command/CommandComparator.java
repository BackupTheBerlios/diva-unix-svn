package eu.diva.runtime.command;

import java.lang.reflect.Field;
import java.util.Comparator;


/**
 * 
 * @author Brice MORIN
 * IRISA Rennes / Equipe-Projet INRIA Triskell
 * Comparator for PlatformCommand
 */
public class CommandComparator implements Comparator<PlatformCommand> {

	/*
	 * Order:
	 * remove bindings < remove instances < remove types <
	 * add types < add instances < add bindings
	 */
	public int compare(PlatformCommand cmd0, PlatformCommand cmd1) {
		if(cmd0 == null && cmd1 == null){
			return 1;
		}
		boolean isDifferent = (cmd1.getPriority() != cmd0.getPriority());
		//commands with different priority are always different
		if(!isDifferent){//if different priority
			isDifferent = checkField(cmd0, cmd1);
		}
		//System.err.println(isDifferent);
		if (isDifferent){
			if(cmd1.getPriority() > cmd0.getPriority()){
				return 1;
			}
			else if (cmd1.getPriority() < cmd0.getPriority()){
				return -1;
			}
			else{
				return 1;
			}
			//return ((cmd1.getPriority())-(cmd0.getPriority()))*2+1;
		}
		else{
			return 0;
		}
	}

	private boolean checkField(PlatformCommand cmd0, PlatformCommand cmd1){
		boolean isDifferent = false;
		try{
			for(Field f0 : cmd0.getClass().getDeclaredFields()){
				for(Field f1 : cmd1.getClass().getDeclaredFields()){
					if (f0.getName().equals(f1.getName())){
						//System.err.println(f0.getName()+": "+f0.get(cmd0)+", "+f1.getName()+": "+f1.get(cmd1));
						isDifferent = isDifferent || (f0.get(cmd0) != f1.get(cmd1));
					}
					if (isDifferent){
						break;
					}
				}
				if (isDifferent){
					break;
				}
			}
		} catch (IllegalAccessException e){
			isDifferent = true;
		}
		return isDifferent;
	}
}

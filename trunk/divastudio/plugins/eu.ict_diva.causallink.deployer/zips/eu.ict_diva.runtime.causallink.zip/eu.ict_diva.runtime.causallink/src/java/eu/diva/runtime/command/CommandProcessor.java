package eu.diva.runtime.command;

import java.util.List;

public interface CommandProcessor {

	class ExecutionResult
	{
		public int nbOkCommands = 0;
		public int indexKoCommand = -1;
	}
	
	ExecutionResult executeCommands( List<PlatformCommand> commands );
}

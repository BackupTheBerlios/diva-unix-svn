package eu.diva.runtime.command;

import art.instance.ComponentInstance;
import art.instance.TransmissionBinding;

public class RemoveBinding extends RemoveCommand {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7067706734610473676L;

	protected TransmissionBinding b;
	protected ComponentInstance container;
	
	public RemoveBinding(){
		priority = 7;
	}

	public void setB(TransmissionBinding b) {
		this.b = b;
		container = (ComponentInstance)b.eContainer();
	}
	public TransmissionBinding getB() {
		return b;
	}
	public ComponentInstance getContainer() {
		return container;
	}

}

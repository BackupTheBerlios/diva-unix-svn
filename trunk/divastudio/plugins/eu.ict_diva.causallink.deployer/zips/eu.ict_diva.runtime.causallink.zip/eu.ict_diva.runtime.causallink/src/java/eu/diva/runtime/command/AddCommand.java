package eu.diva.runtime.command;


public abstract class AddCommand extends PlatformCommand {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8625977919514448820L;

}

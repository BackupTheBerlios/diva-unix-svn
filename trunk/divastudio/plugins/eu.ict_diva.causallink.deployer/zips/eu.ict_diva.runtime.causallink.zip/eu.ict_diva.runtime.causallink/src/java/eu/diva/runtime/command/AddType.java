package eu.diva.runtime.command;

public abstract class AddType extends AddCommand {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 371505109649761234L;

	public AddType(){
		priority = 3;
	}
}

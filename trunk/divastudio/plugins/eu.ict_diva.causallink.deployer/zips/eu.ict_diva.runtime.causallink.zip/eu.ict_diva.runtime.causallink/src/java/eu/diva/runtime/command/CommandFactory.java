package eu.diva.runtime.command;

import art.distrib.Node;
import art.instance.AttributeInstance;
import art.instance.Binding;
import art.instance.ComponentInstance;

public interface CommandFactory {
	AddNode createAddNode(Node n);
	RemoveNode createRemoveNode(Node n);

	AddComponent createAddComponent(ComponentInstance cpt);
	RemoveComponent createRemoveComponent(ComponentInstance cpt);
	
	AddBinding createAddBinding(Binding b);
	RemoveBinding createRemoveBinding(Binding b);
	
	StopComponent createStopComponent(ComponentInstance cpt);
	StartComponent createStartComponent(ComponentInstance cpt);
	
	UpdateAttribute createUpdateAttribute(AttributeInstance att);
}

package eu.diva.runtime.command;

import art.distrib.Node;

public class AddNode extends AddCommand {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3609692715792378355L;
	protected Node node;

	public AddNode(){
		priority = 4;
	}
	
	public void setNode(Node node) {
		this.node = node;
	}
	public Node getNode() {
		return node;
	}

}

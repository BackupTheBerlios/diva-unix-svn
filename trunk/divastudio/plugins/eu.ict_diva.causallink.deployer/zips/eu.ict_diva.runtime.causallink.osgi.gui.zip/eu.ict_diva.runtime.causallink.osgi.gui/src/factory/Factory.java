package factory;

import eu.diva.divastudio.services.runtime.IReconfigurationGUI;
import eu.diva.runtime.causallink.gui.ReconfigurationGUI;

public class Factory implements eu.diva.factoryinstdiva.Factory<IReconfigurationGUI>{

	private static Factory fact = new Factory();

	public static Factory getFact() {
		return fact;
	}

	public static void setFact(Factory fact) {
		Factory.fact = fact;
	}

	
	public IReconfigurationGUI createComponent() {
		return new ReconfigurationGUI();
		
	}	
	
	
	public IReconfigurationGUI createComponent(String implementingClass) {
			return createComponent();
	}

	public boolean check(String implementingClass) {
		return false;
	}
}

package eu.diva.runtime.causallink.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Hashtable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.osgi.framework.BundleContext;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventConstants;
import org.osgi.service.event.EventHandler;

import eu.diva.divastudio.services.runtime.CausalLink;
import eu.diva.divastudio.services.runtime.IReconfigurationGUI;
import eu.diva.osgi.component.DiVAComponent;
import eu.diva.osgi.component.DiVAComponentOSGi;

public class ReconfigurationGUI implements DiVAComponentOSGi, ActionListener, KeyListener, EventHandler, IReconfigurationGUI{

	private JFrame frame; 
	private /*JComboBox*/ JTextField screen;
	private JButton submit;
	private JButton clean;
	private JButton save;
	//public static JCheckBox forceRebuild = null;
	private JPanel top, center, left;
	private JPanel bottom;

	//private Collection<File> architectures;
	
	private CausalLink link;
	
	
	
	public void setLink(CausalLink link){
		this.link = link;
		
		/**
		 * registering as an event handler
		 * Topics depend on the link connected to the GUI,
		 * this is why we extend the setter
		 */
		String[] topics = new String[] {EventConstants.EVENT_TOPIC, 
				((DiVAComponent)link).getInstanceName()+"/configuration/*", 
				((DiVAComponent)link).getInstanceName()+"/reconfiguration/*"};
		Hashtable<String, String[]> ht = new Hashtable<String, String[]>();
		ht.put(EventConstants.EVENT_TOPIC, topics);
		context.registerService(EventHandler.class.getName(), this, ht);
	}
	
	private BundleContext context;
	private String instanceName;
	
	@Override
	public BundleContext getContext() {
		return context;
	}

	@Override
	public void setContext(BundleContext context) {
		this.context = context;
	}
	
	public ReconfigurationGUI() {
		//System.err.println(getInstanceName());
		
		
		//this.context = Activator.context;
		/*ServiceReference ref;
		ref = context.getServiceReference(CausalLink.class.getName());
		if(ref != null)
			link = (CausalLink) context.getService(ref);
		else
			System.err.println("Couldn't find a Causal Link service.");
		*/
		init();		
	}
	
	
	public void init() {
		
		//architectures = new ArrayList<File>();
		//copyTempArchiFiles();
		
		initUiComponents();
		layoutComponents();
				
	}

/*	public void copyTempArchiFiles() {
		List<String> filenameAll = Collections.list(context.getBundle().getEntryPaths("archi/"));
		List<String> fileNames = new ArrayList<String>();
		for (String filename : filenameAll){
			if (filename.endsWith(".art")){
				fileNames.add(filename.replace("archi/", ""));
			}
		}
		for(String fileName : fileNames) {
			File tmp = FileUtilities.createTempFile("archi", fileName);
			try {
				
				InputStream is = context.getBundle().getEntry("archi/" + fileName).openStream();
				OutputStream os = new FileOutputStream(tmp);
				FileUtilities.copyFile(is, os);
				architectures.add(tmp);
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
*/	
	/* (non-Javadoc)
	 * @see eu.diva.runtime.causallink.gui.IReconfigurationGUI#setInvalid()
	 */
	public void setInvalid() {
		left.setBackground(new Color(255, 0, 0));
		frame.setTitle("Reconfiguration Console: Invalid Configuration");
	}

	/* (non-Javadoc)
	 * @see eu.diva.runtime.causallink.gui.IReconfigurationGUI#setValid()
	 */
	public void setValid() {
		left.setBackground(new Color(0, 255, 0));
		frame.setTitle("Reconfiguration Console: Valid Configuration");
	}

	/* (non-Javadoc)
	 * @see eu.diva.runtime.causallink.gui.IReconfigurationGUI#setWarning()
	 */
	public void setWarning() {
		left.setBackground(new Color(255, 150, 50));
		frame.setTitle("Reconfiguration Console: Invalid Configuration");
	}

	/* (non-Javadoc)
	 * @see eu.diva.runtime.causallink.gui.IReconfigurationGUI#setNormal()
	 */
	public void setNormal() {
		left.setBackground(new Color(125, 125, 125));
	}

	private void initUiComponents() {
		frame = new JFrame("Reconfiguration Console"); 
		screen = new JTextField(30);//JComboBox(architectures.toArray());
		submit = new JButton("reconfigure");
		clean = new JButton("clean");
		save = new JButton("save");
		//forceRebuild = new JCheckBox();
		top = new JPanel();
		left = new JPanel();
		center = new JPanel();
		bottom = new JPanel();
		
		screen.setEnabled(true);
		screen.setEditable(true);
		submit.addActionListener(this);
		clean.addActionListener(this);
		save.addActionListener(this);
		screen.addKeyListener(this);
		//forceRebuild.setText("Force Rebuild");
		//forceRebuild.setSelected(false);
		JLabel spacer = new JLabel(" ");
		spacer.setOpaque(false);
		spacer.setPreferredSize(new Dimension(100,50));
		left.add(spacer);
	}
	
	private void layoutComponents() {
		
		top.add(screen);
		//top.add(forceRebuild);
		bottom.add(submit);
		bottom.add(clean);
		bottom.add(save);

		center.setLayout(new BorderLayout());
		center.add(top, BorderLayout.NORTH);
		center.add(bottom, BorderLayout.SOUTH);
		
		frame.getContentPane().setLayout(new BorderLayout());
		frame.add(center, BorderLayout.CENTER);
		frame.add(left,BorderLayout.WEST);

		frame.setPreferredSize(new Dimension(900,100));
		frame.pack();

		frame.setVisible(true);
	}


	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == submit)
			link.reconfigureByModelURI(screen.getText()/*getSelectedItem().toString()*/);
		else if (arg0.getSource() == clean){
			//link.cleanCommands();
		}
		else if (arg0.getSource() == save){
			link.saveModel(screen.getText()/*getSelectedItem().toString()*/);
		}
	}

	/* (non-Javadoc)
	 * @see eu.diva.runtime.causallink.gui.IReconfigurationGUI#stopSubmit()
	 */
	public void stopSubmit() {
		submit.setEnabled(false);
	}

	/* (non-Javadoc)
	 * @see eu.diva.runtime.causallink.gui.IReconfigurationGUI#startSubmit()
	 */
	public void startSubmit() {
		submit.setEnabled(true);
	}

	/* (non-Javadoc)
	 * @see eu.diva.runtime.causallink.gui.IReconfigurationGUI#stopClean()
	 */
	public void stopClean() {
		clean.setEnabled(false);
	}

	/* (non-Javadoc)
	 * @see eu.diva.runtime.causallink.gui.IReconfigurationGUI#startClean()
	 */
	public void startClean() {
		clean.setEnabled(true);
	}	
	
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ENTER){
			//if(screen.getSelectedIndex()!= -1) {
				submit.doClick(200);
			//}
		}		
	}

	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void keyTyped(KeyEvent e) {
	
	}

	public void start() {

	}

	public void stop() {
		// TODO Auto-generated method stub
		
	}

	public void handleEvent(Event event) {
		if (event.getTopic().startsWith(((DiVAComponent)link).getInstanceName()+"/configuration/check/ok")){
			this.setValid();
			//System.out.println("VALID");
		}
		else if (event.getTopic().startsWith(((DiVAComponent)link).getInstanceName()+"/configuration/check/nok")){
			this.setInvalid();
			//System.out.println("INVALID");
		}
		else if (event.getTopic().startsWith(((DiVAComponent)link).getInstanceName()+"/reconfiguration/ok")){
			this.setValid();
			this.stopClean();
			this.startSubmit();
			//System.out.println("VALID");
		}
		else if (event.getTopic().startsWith(((DiVAComponent)link).getInstanceName()+"/reconfiguration/nok")){
			this.setWarning();
			this.stopSubmit();
			this.startClean();
			//System.out.println("WARNING");
		}
		
	}


	@Override
	public String getInstanceName() {
		return instanceName;
	}


	@Override
	public void setInstanceName(String name) {
		this.instanceName = name;
		
	}
}

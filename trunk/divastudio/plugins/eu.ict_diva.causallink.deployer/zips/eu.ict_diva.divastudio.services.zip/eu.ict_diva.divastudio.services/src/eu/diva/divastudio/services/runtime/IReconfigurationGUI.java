package eu.diva.divastudio.services.runtime;

public interface IReconfigurationGUI {

	void setInvalid();

	void setValid();

	void setWarning();

	void setNormal();

	void stopSubmit();

	void startSubmit();

	void stopClean();

	void startClean();

}
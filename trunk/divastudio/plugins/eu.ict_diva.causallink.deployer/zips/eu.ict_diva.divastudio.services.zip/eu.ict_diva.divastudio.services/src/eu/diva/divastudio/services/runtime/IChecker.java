package eu.diva.divastudio.services.runtime;

public interface IChecker {
	
	/**
	 * Checks invariant on an ART model
	 * @param system: the system to check
	 * @return
	 */
	boolean check(art.System system);
}

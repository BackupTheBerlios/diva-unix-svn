package eu.diva.divastudio.services.runtime;

import java.util.List;

public interface CausalLink {
	
	String VALID_CONFIG_EVENT = "/configuration/check/ok";
	String NOT_VALID_CONFIG_EVENT = "/configuration/check/nok";
	String RECONFIGURATION_OK_EVENT = "/configuration/apply/ok";
	String RECONFIGURATION_NOK_EVENT = "/configuration/apply/nok";
	
	/**
	 * Reconfigure the running system using a serialized update model
	 * @param modelURI: the URI of the ART update model
	 * @return reconfiguration status
	 */
	int reconfigureByModelURI(String modelURI);

	/**
	 * Reconfigure the running system using an in-memroy update model
	 * @param system: the update system
	 * @return reconfiguration status
	 */
	int reconfigureInMemory(art.System system);
	
	/**
	 * Saves the current reflection model
	 * @param modelURI
	 */
	void saveModel(String modelURI);
	
	List<String> getGroup(String qName);
}

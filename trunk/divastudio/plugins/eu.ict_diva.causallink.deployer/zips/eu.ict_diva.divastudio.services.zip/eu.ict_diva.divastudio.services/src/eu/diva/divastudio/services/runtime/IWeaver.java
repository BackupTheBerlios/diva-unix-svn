package eu.diva.divastudio.services.runtime;


public interface IWeaver {

	/**
	 * Produce the ART configuration corresponding to a selection of variant
	 * @param wp2ConfigurationURI: URI to a serialized model representing the list
	 * of variants to weave.
	 */
	void produceConfiguration(String wp2ConfigurationURI);

}

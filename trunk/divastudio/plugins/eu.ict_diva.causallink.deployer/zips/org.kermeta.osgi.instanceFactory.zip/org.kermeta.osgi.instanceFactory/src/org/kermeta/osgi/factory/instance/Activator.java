package org.kermeta.osgi.factory.instance;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.kermeta.osgi.bundlefactory.service.DoBundleService;
import org.kermeta.osgi.factory.instance.impl.GenerateInstanceBundle;
import org.kermeta.osgi.factory.instance.service.GenerateInstanceService;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceEvent;
import org.osgi.framework.ServiceListener;
import org.osgi.framework.ServiceReference;
import org.osgi.framework.ServiceRegistration;

import fr.irisa.triskell.utility.FileUtilities;


public class Activator implements BundleActivator{


	private ServiceReference doBundleServRef;
	private ServiceRegistration ref = null;
	private static BundleContext context;
	private static Map<String, String> templates = new Hashtable<String, String>();

	public static final BundleContext getContext() {
		return context;
	}

	public static final void setContext(BundleContext context) {
		Activator.context = context;
	}

	public static final Map<String, String> getTemplates() {
		return templates;
	}

	private static Logger logger = Logger.getLogger(Activator.class.getName());

	public void start(BundleContext context)  {

		setContext(context);
		try {
			logger.info("InstanceFactory Starting");

			File activ = FileUtilities.createTempFile("Activator.st");

			FileUtilities.copyFile(getClass().getResourceAsStream("/template/Activator.st"), new FileOutputStream(activ));

			getTemplates().put("Activator.st", activ.getAbsolutePath());


			File activ2 = FileUtilities.createTempFile("MANIFEST.st");
			FileUtilities.copyFile(getClass().getResourceAsStream("/template/MANIFEST.st"), new FileOutputStream(activ2));
			getTemplates().put("MANIFEST.st", activ2.getAbsolutePath());

			doBundleServRef = context.getServiceReference(
					DoBundleService.class.getName());

			context.addServiceListener(new ServiceListener() {
				public void serviceChanged(ServiceEvent event) {

					//gets the service if local attribute is null
					if(ref == null) {
						register();

						// removes the reference if the service is unregistering
					} else {
						unregister();
					}
				}
			}, "(objectclass=" + DoBundleService.class.getName() + ")");

			register();
		} catch (FileNotFoundException e) {
			// Auto-generated catch block
			logger.error("FileNotFoundException", e);
		} catch (IOException e) {
			// Auto-generated catch block
			logger.error("IOException", e);
		} catch (InvalidSyntaxException e) {
			// Auto-generated catch block
			logger.error("InvalidSyntaxException", e);
		}

	}

	private void unregister() {
		doBundleServRef = null;
		ref.unregister();
		ref = null;
	}

	private void register() {
		doBundleServRef = context.getServiceReference(
				DoBundleService.class.getName());
		if(doBundleServRef != null) {
			GenerateInstanceService s = new GenerateInstanceBundle(context, doBundleServRef);

			Properties props = new Properties();

			ref = context.registerService(
					GenerateInstanceService.class.getName(),s, props);

			logger.info("InstanceFactory Started");
		}
	}

	public void stop(BundleContext context) {
		if (ref != null)
			ref.unregister();
		ref = null;
	}



}

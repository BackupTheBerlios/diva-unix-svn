package org.kermeta.osgi.factory.instance.service;

import java.util.Dictionary;

public interface GenerateInstanceService {
	/**
	 * The name of the component type as defined in the model. Type: String
	 */
	public static final String COMPONENT_TYPE_NAME = "componentTypeName";
	/**
	 * The name of the class implementing the component type. Type: String
	 */
	public static final String COMPONENT_TYPE_CLASS = "componentTypeClass";
	/**
	 * The symbolic name to give to the generated bundle (must ne unique). Type: String
	 */
	public static final String BUNDLE_SYMBOLIC_NAME = "bundleSymbolicName";
	/**
	 * The name of the component instance. Type: String
	 */
	public static final String INSTANCE_NAME = "instanceName";
	/**
	 * The name of the node to which the component instance belongs. Type: String
	 */
	public static final String NODE_ID = "nodeId";
	/**
	 * The names of the service interfaces to export. Type: String[]
	 */
	public static final String SERVICE_INTERFACES = "serviceInterfaces";
	
	/**
	 * Generates a new bundle, instance of a component.
	 * @param properties The properties customizing the generated bundle.
	 * @param forceCreation If true, erases already existing files and rebuilt all (longer). If false, just uses existing files without regenerating.
	 * @return The bundleId of the new created/deployed bundle/component instance.
	 * @throws Exception
	 */
	public long generateInstanceBundle(
			Dictionary properties,
			boolean forceCreation)
			throws Exception;

}
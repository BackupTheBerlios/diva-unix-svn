package org.kermeta.osgi.factory.instance.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Dictionary;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.kermeta.osgi.bundlefactory.service.DoBundleService;
import org.kermeta.osgi.factory.instance.service.GenerateInstanceService;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import fr.irisa.triskell.utility.FileUtilities;




public class GenerateInstanceBundle implements GenerateInstanceService{

	private static Logger logger = Logger.getLogger(GenerateInstanceBundle.class.getName());

	//Name of the working directory, kind ok 'root namespace'
	private static String baseLocationDir = "genWorkingDir";

	/**
	 * Permanent directory where the Jar/bundle will be created.
	 */
	private String workingDirName;
	private String srcDirName;
	private String classDirName;
	private String packageDirName;
	private String manifestDirName;
	private static String outputDirName;
	private static String outputDirRelLoc;

	/**
	 * The OSGi BundleContext
	 */
	private BundleContext context;

	/**
	 * Reference to the service offering BundleGeneration
	 */
	private ServiceReference ref;

	public GenerateInstanceBundle(BundleContext context,ServiceReference ref) throws IllegalArgumentException {
		super();

		if(context == null || ref == null) {
			throw new IllegalArgumentException("Context and ServiceReference can not be null.");
		}

		this.context = context;
		this.ref=ref;

		//define location of specific dirs in root working dir.
		outputDirRelLoc = baseLocationDir + "/" + outputDirName;		
	}

	private void generateActivator(Dictionary properties) {
		File factoryClass = FileUtilities.createPersistentFile(context,packageDirName, "Activator.java");
		FileOutputStream fo = null;
		try {

			fo = new FileOutputStream(factoryClass);
			fo.write(this.createFactoryInst(properties).getBytes());

		} catch (FileNotFoundException e) {
			// Auto-generated catch block
			logger.error("FileNotFoundException", e);
		} catch (IOException e) {
			// Auto-generated catch block
			logger.error("IOException", e);
		} finally {
			try {
				if( fo != null) {
					fo.close();
				}
			} catch (IOException e) {
				logger.error("IOException", e);
			}
		}
	}

	private File generateManifest(Dictionary properties) {
		String instanceName = (String)properties.get(INSTANCE_NAME);
		String componentTypeJavaClass = (String)properties.get(COMPONENT_TYPE_CLASS);
		String componentTypeName = (String)properties.get(COMPONENT_TYPE_NAME);
		Object services = properties.get(SERVICE_INTERFACES);
		List<String> objectNames = new ArrayList<String>();
		if( null != services )
			objectNames.addAll(Arrays.asList((String[])services));
		objectNames.add(componentTypeJavaClass);
		
		//Used in manifest creation.
		List<String> packageNames = new ArrayList<String>();
		//String packagename = "";
		for( String typeName : objectNames ) {
			if (typeName.contains(".")) { 
				packageNames.add( typeName.substring(0, typeName.lastIndexOf(".")) );
			} 
		}

		//creation of the manifest using the template
		File manifest = FileUtilities.createPersistentFile(context,manifestDirName, "MANIFEST.MF");  
		FileOutputStream fom = null; 
		try {
			fom = new FileOutputStream(manifest);
			String s = this.createManifest(packageNames,instanceName,componentTypeName) +"\n\n"; 
			fom.write(s.getBytes());
		} catch (FileNotFoundException e) {
			// Auto-generated catch block
			logger.error("FileNotFoundException", e);
		} catch (IOException e) {
			// Auto-generated catch block
			logger.error("IOException", e);
		} finally {
			try {
				if( fom != null) {
					fom.close();
				}
			} catch (IOException e) {
				logger.error("IOException", e);
			}
		}
		return manifest;
	}


	public long generateInstanceBundle(
			Dictionary properties,
			boolean forceCreation) throws Exception {

		// TODO: check for nullity
		String instanceName = (String)properties.get(INSTANCE_NAME);
		//Creation of the bundleJar in the persistent outputDir
		String bundleTypeSymbolicName = (String)properties.get(BUNDLE_SYMBOLIC_NAME);
		File jar = FileUtilities.getPersistentFile(context, outputDirRelLoc + "/" + instanceName + ".jar");

		DoBundleService db = (DoBundleService) context.getService(ref);

		if (jar == null || forceCreation){
			//System.out.println("Generating, compiling and packaging a component...");

			jar = FileUtilities.createPersistentFile(context, outputDirRelLoc, instanceName+".jar");

			workingDirName = instanceName;
			srcDirName = workingDirName + "/src";
			classDirName = workingDirName + "/bin";
			packageDirName = srcDirName + "/diva/instance";
			manifestDirName = classDirName + "/META-INF";



			File workingDir = FileUtilities.createPersistentDir(context, workingDirName);

			File srcDir = FileUtilities.createPersistentDir(context, srcDirName);
			File classDir = FileUtilities.createPersistentDir(context, classDirName);

			//creates the package directory
			FileUtilities.createPersistentDir(context, packageDirName);

			//creates the manifest directory
			FileUtilities.createPersistentDir(context, manifestDirName);

			//creation of the activator using the template
			generateActivator(properties);


			//Retreives the package name of the component to be created, for it to be exported by the bundle.


			File manifest = generateManifest(properties);



			List<String> libs = new ArrayList<String>();

			for (Bundle b :context.getBundles()){
				if(!b.getLocation().equals("System Bundle")){
					String libAddr = FileUtilities.anyStrangePathToAbsolute(context,b.getBundleId(), b.getLocation());

					if(!libAddr.endsWith(".jar") && !libAddr.endsWith("bin")) {
						libAddr = FileUtilities.unifyPath(libAddr + "/bin");
						libs.add(libAddr);
					} else if (b.getSymbolicName().equals("eu.ict.diva.framework") || b.getSymbolicName().equals("eu.ict_diva.osgi.component.framework")) {
						logger.debug("Diva ComponentFramework Found");
						libs.add(libAddr);
					} else if (b.getSymbolicName().equals("eu.ict.diva.services") || b.getSymbolicName().equals("eu.ict_diva.divastudio.services")) {
						logger.debug("Diva Services Found");
						libs.add(libAddr);
					} else if (b.getSymbolicName().equals("eu.ict-diva.runtime.causallink") || b.getSymbolicName().equals("eu.ict_diva.runtime.causallink.osgi")) {
						logger.debug("Diva Services Found");
						libs.add(libAddr);
					}else if (b.getSymbolicName().equals(bundleTypeSymbolicName)) {
						logger.debug("ComponentType Found");
						libs.add(libAddr);
					}
				}

			}

			db.doBundle(srcDir.getAbsolutePath(), libs, classDir.getAbsolutePath(), jar.getAbsolutePath(), manifest.getAbsolutePath(), new ArrayList<String>(), workingDir.getAbsolutePath());  
			//db.deleteRecursive(workingDir.getAbsolutePath());
		} else {
			logger.debug("Reusing an already generated, compiled and packaged component");
		}

		return db.InstallBundle("file:" + jar.getAbsolutePath(),context);

	}

	public String createManifest(List<String> packageNames, String instanceName, String componentTypeName) {

		/*
		StringTemplateGroup group = new StringTemplateGroup("myGroup"); //$NON-NLS-1$
		String absPathManifest = Activator.getTemplates().get("MANIFEST.st");
		logger.debug(absPathManifest.substring(0,absPathManifest.length()-3));
		StringTemplate manifest = group.getInstanceOf("file:" + absPathManifest.substring(0,absPathManifest.length()-3)); //$NON-NLS-1$
		//StringTemplate manifest = group.getInstanceOf("classpath:file:template/MANIFEST"); //$NON-NLS-1$
		manifest.setAttribute("ComponentTypePackageName", componentTypePackageName); //$NON-NLS-1$
		manifest.setAttribute("InstanceName", instanceName); //$NON-NLS-1$
		manifest.setAttribute("ComponentTypeName", componentTypeName); //$NON-NLS-1$
		 */

		StringBuffer manifest = new StringBuffer();

		manifest.append("Manifest-Version: 1.0").append("\n");
		manifest.append("Bundle-ManifestVersion: 2").append("\n");
		manifest.append("Bundle-Name: ").append(instanceName).append("\n");
		manifest.append("Bundle-SymbolicName: ").append(instanceName).append("\n");
		manifest.append("Bundle-Version: 1.0.0").append("\n");
		manifest.append("Bundle-ClassPath: .").append("\n");
		manifest.append("Bundle-Activator: diva.instance.Activator").append("\n");
		final Set<String> imports = new HashSet<String>();
		imports.add("org.osgi.framework");
		imports.add("eu.diva.factoryinstdiva");
		imports.add("eu.diva.osgi.component");
		imports.add("eu.diva.runtime.causallink.distribution.osgi");
		imports.add("eu.diva.divastudio.services.runtime");
		for( String s: packageNames )
			imports.add(s);
		manifest.append("Import-Package:");
		int i = 0;
		for( String name: imports ){
			manifest.append(" ").append(name);
			if(i < imports.size() - 1)
				manifest.append(",");
			manifest.append("\n");
			++i;
		}

		manifest.append("\n");//mandatory

		if(logger.isDebugEnabled())
			logger.debug(manifest);

		return manifest.toString();
	}

	public String createFactoryInst(Dictionary properties) {
		String instanceName = (String)properties.get(INSTANCE_NAME);
		String nodeId = (String)properties.get(NODE_ID);
		String componentTypeJavaClass = (String)properties.get(COMPONENT_TYPE_CLASS);
		String componentTypeName = (String)properties.get(COMPONENT_TYPE_NAME);
		Object rawServices = properties.get(SERVICE_INTERFACES);
		String[] services = null;
		if(null != rawServices)
			services = (String[])rawServices;

		/*
		StringTemplateGroup group = new StringTemplateGroup("myGroup"); //$NON-NLS-1$
		String absPathActiv = Activator.getTemplates().get("Activator.st");
		logger.debug(absPathActiv.substring(0,absPathActiv.length()-3));
		StringTemplate factory = group.getInstanceOf("file:" + absPathActiv.substring(0,absPathActiv.length()-3));
		//StringTemplate factory = group.getInstanceOf("classpath:file:template/Activator");
		factory.setAttribute("ComponentTypeName", componentTypeName); //$NON-NLS-1$
		factory.setAttribute("ComponentTypeJavaClass", componentTypeJavaClass); //$NON-NLS-1$
		factory.setAttribute("InstanceName", instanceName); //$NON-NLS-1$
		 */

		StringBuffer factory = new StringBuffer();

		factory.append("package diva.instance;").append("\n");
		factory.append("\n");
		factory.append("import java.util.Properties;").append("\n");
		factory.append("\n");
		factory.append("import eu.diva.osgi.component.DiVAComponentOSGi;").append("\n");
		factory.append("import eu.diva.runtime.causallink.distribution.osgi.ServiceExportationSupport;").append("\n");
		factory.append("import org.osgi.framework.BundleActivator;").append("\n");
		factory.append("import org.osgi.framework.BundleContext;").append("\n");
		factory.append("import org.osgi.framework.ServiceReference;").append("\n");
		factory.append("import org.osgi.framework.InvalidSyntaxException;").append("\n");
		/*for( String service: services ) {
			factory.append("import ").append(service).append(";").append("\n");
		}*/
		factory.append("\n");
		factory.append("public class Activator implements BundleActivator{").append("\n");
		factory.append("\n");
		factory.append("	ServiceReference ref = null;").append("\n");
		factory.append("	eu.diva.osgi.component.DiVAComponentOSGi cpt;").append("\n");
		factory.append("	eu.diva.runtime.causallink.distribution.osgi.ServiceExportationSupport exp = null;").append("\n");
		factory.append("\n");
		factory.append("	public void start(BundleContext context) {").append("\n");
		factory.append("	  try {").append("\n");
		factory.append("		ServiceReference[] refs = context.getServiceReferences(").append("\n");
		factory.append("				eu.diva.factoryinstdiva.Factory.class.getName(), \"(Factory=").append(componentTypeName).append(")\");").append("\n");
		factory.append("		ref = refs[0];").append("\n");
		factory.append("		eu.diva.factoryinstdiva.Factory<?> fact = (eu.diva.factoryinstdiva.Factory<?>) context.getService(ref);").append("\n");
		factory.append("		cpt = (eu.diva.osgi.component.DiVAComponentOSGi) fact.createComponent(\"").append(componentTypeJavaClass).append("\");").append("\n");
		factory.append("        exp = new ServiceExportationSupport( context, cpt );").append("\n");
		factory.append("		Properties props = new Properties();").append("\n");
		factory.append("        props.put(\"InstanceName\", \"").append(instanceName).append("\");").append("\n");
		factory.append("        props.put(\"nodeId\", \"").append(nodeId).append("\");").append("\n");
		factory.append("        context.registerService( exp.getClass().getName(), exp, props);").append("\n");
		factory.append("        props.put(\"service.exported.interfaces\", \"*\");").append("\n");
		// TODO: use a custom property to get the value of the property
		factory.append("        props.put(\"service.exported.configs\", \"org.apache.cxf.ws\");").append("\n");
		// TODO: use a custom property to get the name of the property
		// TODO: use metamodel port info to get the hostname and the port
		String port = System.getProperty("diva.distribution.port");
		if( null == port )
			port = "9090";
		factory.append("        props.put(\"org.apache.cxf.ws.address\", \"http://localhost:")
					.append(port)
					.append("/").append( componentTypeName )
					.append("/").append(instanceName)
					.append("\");").append("\n");
		factory.append("        context.registerService( \"eu.diva.osgi.component.DiVAComponentOSGi\", cpt, props);").append("\n");
		//factory.append("        context.registerService( cpt.getClass().getName(), cpt, props);").append("\n");
		factory.append("        cpt.setInstanceName(\"").append(instanceName).append("\");").append("\n");
		factory.append("        cpt.setContext(context);").append("\n");
		factory.append("\n");
		factory.append("      } catch(InvalidSyntaxException e){}").append("\n");
		factory.append("	}").append("\n");
		factory.append("\n");
		factory.append("	public void stop(BundleContext context) {").append("\n");
		factory.append("		if (ref != null)").append("\n");
		factory.append("			context.ungetService(ref);").append("\n");
		factory.append("		ref = null;").append("\n");
		factory.append("\n");
		factory.append("		cpt.stop();").append("\n");
		factory.append("	}").append("\n");
		factory.append("\n");
		factory.append("}").append("\n");

		if(logger.isDebugEnabled())
			logger.debug(factory);

		return factory.toString();

	}
}
